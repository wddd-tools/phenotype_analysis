#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <list>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
    string name1 = argv[1];
    string lngfile = argv[2];
    string opfile = argv[3];

    int ttt[180];
    for (int i = 0; i < 180; i++)
        ttt[i] = 0;

    ifstream lng;
    lng.open(lngfile.c_str());
    list<int> tt;
    int t, pid, cid, p1t, cp1 = 0;
    double p1x = 0.0, p1y = 0.0, p1z = 0.0;
    double abx = 0.0, aby = 0.0, abz = 0.0;
    double x, y, z, sp, vol;
    string name, div;
    while (lng >> t >> pid >> cid >> x >> y >> z >> name >> sp >> vol >> div) {
        if (!strcmp(name.c_str(), "AB") && !strcmp(div.c_str(), "N")) {
            int t1 = t;
            tt.push_back(t1);
            ttt[t]++;
        } else if (!strcmp(name.c_str(), "P1") && !strcmp(div.c_str(), "N")) {
            ttt[t]++;
        }
    }

    int tttt = 0;
    for (int i = 0; i < 180; i++) {
        if (ttt[i] == 2) {
//            tttt = i - 1;
          	tttt = i;
            break;
        }
    }

//    list<int>::iterator p;
//    for (p = tt.begin(); p != tt.end(); p++) {
//        cout << (*p) << " ";
//    }
//    cout << endl;

//    ifstream op;
//    op.open(opfile.c_str());
    double opx, opy, opz;
//    op >> opx >> opy >> opz;

//    cerr << tttt << endl;

    ifstream lng3;
    lng3.open(lngfile.c_str());
    while (lng3 >> t >> pid >> cid >> x >> y >> z >> name >> sp >> vol >> div) {
        if (t == tttt && !strcmp(name.c_str(), "AB")) {
            abx = x;
            aby = y;
            abz = z;
        } else if (t == tttt && !strcmp(name.c_str(), "P1")) {
            p1x = x;
            p1y = y;
            p1z = z;
        }
    }

    opx = (abx + p1x) / 2.0;
    opy = (aby + p1y) / 2.0;
    opz = (abz + p1z) / 2.0;

//    cerr << opx << " " << opy << " " << opz << endl;
    list<double> dd, dd2;
    list<int>::iterator p;
    ifstream lng2;
    double tmp_x, tmp_y, tmp_z;
    lng2.open(lngfile.c_str());
    int flag = 0, sflag = 0;
    while (lng2 >> t >> pid >> cid >> x >> y >> z >> name >> sp >> vol >> div) {
        for (p = tt.begin(); p != tt.end(); p++) {
            if ((*p) == t) {
                flag = 1;
            }
        }

        if (flag == 1 && !strcmp(name.c_str(), "AB")) {
            double x1 = x;
            double y1 = y;
            double z1 = z;

            double dis = sqrt((x1 - opx) * (x1 - opx) + (y1 - opy) * (y1 - opy) + (z1 - opz) * (z1 - opz));
            dd.push_back(dis);

            if (sflag == 0) {
                tmp_x = x;
                tmp_y = y;
                tmp_z = z;
                sflag = 1;
            } else if (sflag == 1) {
                double dis2 = sqrt((x - tmp_x) * (x - tmp_x) + (y - tmp_y) * (y - tmp_y) + (z - tmp_z) * (z - tmp_z));
                dd2.push_back(dis2);
                tmp_x = x;
                tmp_y = y;
                tmp_z = z;
            }

        }

        flag = 0;
    }

    double td = 0.0;
    list<double>::iterator r;
    for (r = dd.begin(); r != dd.end(); r++) {
        td = td + (*r);
    }

    double td2 = 0.0;
    int count = 0;
    for (r = dd.begin(); r != dd.end(); r++) {
        count++;
        if (count == 24) {
            td2 = (*r);
            break;
        }
        td2 = (*r);
    }

    double td3 = 0.0;
    int count2 = 0;
    for (r = dd2.begin(); r != dd2.end(); r++) {
        count2++;
        if (count2 == 24) {
            td3 = td3 + (*r);
            break;
        }
        td3 = td3 + (*r);
    }

    double td4 = 0.0;
    int count3 = 0;
    for (r = dd.begin(); r != dd.end(); r++) {
        count3++;
        td4 = (*r);
    }


    if (dd.size() == 0) {
      cout << name1 << " -1000 -1000" << endl;
        exit(1);
    }

    td = td / (double) dd.size();

    cout << name1 << " " << td2 << " " << td4 << endl;

    return 0;
}
