#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
using namespace std;

int main(int argc, char* argv[])
{
    string name = argv[1];
    string input = argv[2];

    ifstream in;
    in.open(input.c_str());

    int t;
    double x, y, z;
    double d;

    double minx = 5000.0;
    double miny = 5000.0;
    double minz = 5000.0;
    double mind = 5000.0;

    while (in >> t >> x >> y >> z >> d) {
        if (x < minx) {
            minx = x;
        }
	if (y < miny) {
	  miny = y;
	}
	if (z < minz) {
	  minz = z;
	}
        if (d < mind) {
            mind = d;
        }
    }

    cout << name << " ";
    if (minx == 5000.0) {
      cout << "-1000 ";
    } else {
      cout << minx << " ";
    }

    if (miny == 5000.0) {
      cout << "-1000 ";
    } else {
      cout << miny << " ";
    }

    if (minz == 5000.0) {
      cout << "-1000 ";
    } else {
      cout << minz << " ";
    }

    if (mind == 5000.0) {
      cout << "-1000" << endl;
    } else {
      cout << mind << endl;
    }

    //    if (min == 5000.0) {
    //	if (mind == 5000.0) {
    //       		cout << name << "\t" << 0 << "\t" << 0 << endl;
    //	} else {
    //		cout << name << "\t" << 0 << "\t" << mind << endl;	
    //	}
    //    } else {
    //	if (mind == 5000.0) {
    //		cout << name << "\t" << min << "\t" << 0 << endl;
    //	} else {
    //		cout << name << "\t" << min << "\t" << mind << endl;
    //	}
    //    }

    return 0;
}
