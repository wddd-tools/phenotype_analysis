#include <iostream>
#include <cstring>
#include <fstream>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
  string plngfile = argv[1];
  string clngfile = argv[2];

  int t, pid, cid;
  double x, y, z, sph, vol;
  string name, div;
  int t2, pid2, cid2;
  double x2, y2, z2;
  double d;
  string name2;
  ifstream plng;
  plng.open(plngfile.c_str(), ios::in);
  ifstream clng;
  clng.open(clngfile.c_str(), ios::in);
  while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div, clng >> t2 >> pid2 >> cid2 >> x2 >> y2 >> z2 >> name2) {
    if (!strcmp(name.c_str(), "P0") && !strcmp(div.c_str(), "N")) {
      d = sqrt(x2 * x2 + y2 * y2 + z2 * z2);
      cout << t2 << "\t" << x2 << "\t" << y2 << "\t" << z2 << "\t" << d << endl;
    }
  }
  clng.close();
  plng.close();

  return 0;
}
