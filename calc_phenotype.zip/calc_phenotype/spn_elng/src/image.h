//
// image.h (ipl2mroi)
// 2005-05-02 kyoda@so.bio.keio.ac.jp
//

#ifndef _IMAGE_H_
#define _IMAGE_H_

#include "common.h"

class image {
    bool mallocated;
    COLORREF **imageData;
    bool epymallocated;
    double **epyData;
    uint x;
    uint y;
    uint epyx;
    uint epyy;

public:
    image();
    ~image();

    bool setEpy(uint, uint, double); 
    bool setPixel(uint, uint, COLORREF);
    void free();
    COLORREF getPixel(int, int);
    double getEpy(int, int);
    int getPixelI(int, int);
    int getPixelR(int, int);
    int getPixelG(int, int);
    int getPixelB(int, int);
    uint getX();
    uint getY();
    bool setSize(uint, uint);
    bool setEpySize(int, int);
};

#endif // _IMAGE_H_
