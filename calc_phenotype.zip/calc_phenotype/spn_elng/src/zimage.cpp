#include "zimage.h"
using namespace std;

zimage::zimage()
{

}

zimage::~zimage()
{

}

void zimage::set(int sz, image tmp_img)
{
    z = sz;

    img.setSize(tmp_img.getX(), tmp_img.getY());
    for (uint x = 0; x < tmp_img.getX(); x++) {
        for (uint y = 0; y < tmp_img.getY(); y++) {
            img.setPixel(x, y, MAXINTENSITY);
        }
    }

    for (uint x = 0; x < tmp_img.getX(); x++) {
        for (uint y = 0; y < tmp_img.getY(); y++) {
            img.setPixel(x, y, tmp_img.getPixel(x, y));
        }
    }

}

image zimage::getImg()
{
    return img;
}

int zimage::getZ()
{
    return z;
}
