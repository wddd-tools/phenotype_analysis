#include <stdio.h>
#include <math.h>
#define NDIM 101

class ev_jacobi {
  double a[NDIM][NDIM], aa, ev[NDIM], evec[NDIM][NDIM], vec[NDIM][NDIM];
  int ndim, l_sort, p[NDIM], l_matsize;
public:
  void set_matrix(int, double [][NDIM], int, int);
  void get_eigenvalue(double []);
  void get_eigenvector(double [][NDIM]);
  void sort_eigenpair(int);
private:
  void compute_eigenpair(int);
  void matrix_update(void);
  void get_p(void);
  void print_matrix(void);
};
