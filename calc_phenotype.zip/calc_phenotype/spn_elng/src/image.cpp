//
// image.cpp (ipl2mroi)
// 2005-05-02 kyoda@so.bio.keio.ac.jp
//

#include <iostream>
#include "image.h"
using namespace std;

image::image()
{
    imageData = NULL;
    mallocated = false;
    epyData = NULL;
    epymallocated = false;
}

image::~image()
{
//    delete [] imageData;
//    free();
}

bool image::setEpy(uint i, uint j, double c)
{
    if ((i >= epyx) || (j >= epyy))
        return false;
    epyData[i][j] = c;

    return true;
}

bool image::setPixel(uint i, uint j, COLORREF c)
{
    if ((i >= x) || (j >= y))
        return false;
    imageData[i][j] = c;

    return true;
}

COLORREF image::getPixel(int i, int j) {
    if (i < 0)
        i = 0;
    if (j < 0)
        j = 0;
    if (i >= (int) x)
        return i = (int) x - 1;
    if (j >= (int) y)
        return j = (int) y - 1;

    return imageData[i][j];
}

double image::getEpy(int i, int j) {
    if (i < 0)
        i = 0;
    if (j < 0)
        j = 0;
    if (i >= (int) epyx)
        return i = (int) epyx - 1;
    if (j >= (int) epyy)
        return j = (int) epyy - 1;

    return epyData[i][j];
}

int image::getPixelI(int x, int y)
{
    return getPixel(x, y);
}

int image::getPixelR(int x, int y)
{
    return getPixel(x, y);
}

int image::getPixelG(int x, int y)
{
    return getPixel(x, y);
}

int image::getPixelB(int x, int y)
{
    return getPixel(x, y);
}

bool image::setEpySize(int i, int j)
{
    if (epymallocated) {
        if ((i == epyx) && (j == epyy))
            return true;
        free();
    }

    epyx = i;
    epyy = j;
    epyData = new double * [i];

    for (uint k = 0; k < i; k++)
        epyData[k] = new double[j];
    epymallocated = true;

    return true;
}

bool image::setSize(uint i, uint j)
{
    if (mallocated) {
        if ((i == x) && (j == y))
            return true;
        free();
    }

    x = i;
    y = j;
    imageData = new COLORREF * [i];

    for (uint k = 0; k < i; k++)
        imageData[k] = new COLORREF[j];
    mallocated = true;

    return true;
}

void image::free()
{
    if (mallocated) {
        for (int i = 0; i < (int) x; i++)
            delete[] imageData[i];
        delete[] imageData;
        imageData = NULL;
        mallocated = false;
    }

    if (epymallocated) {
        epymallocated = false;
        for (int i = 0; i < (int) epyx; i++)
            delete[] epyData[i];
        delete[] epyData;
        epyData = NULL;
    }
}

uint image::getX()
{
    return x;
}

uint image::getY()
{
    return y;
}
