#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include "eigenVec.h"
#include "ccImg.h"
#include "ccConv.h"
#include "imageIO.h"
using namespace std;

int main(int argc, char* argv[])
{
    string name1 = argv[1];
    string lngfile = argv[2];
    string roifile = argv[3];
    string cell0 = argv[4];
    string cell1 = argv[5];
    string cell2 = argv[6];

    ifstream lng;
    lng.open(lngfile.c_str());
    int t, pid, cid;
    double x, y, z, sp, vol;
    string name, div;

    list<int> tt;
    int p1f = 0, abf = 0, p0n = 0;
    int t1 = -1;
    int nab = 0, np1 = 0;
    int fff = 0;
    int f1 = 0;
    int f2 = 0;
    int cid0 = 0, cid1 = 0, cid2 = 0;

    while (lng >> t >> pid >> cid >> x >> y >> z >> name >> sp >> vol >> div) {
      if (!strcmp(name.c_str(), cell0.c_str())) {
	cid0 = cid;
      }

        if (!strcmp(name.c_str(), cell1.c_str()) && !strcmp(div.c_str(), "D") && nab == 0) {
            t1 = t;
        } else if (!strcmp(name.c_str(), cell2.c_str()) && !strcmp(div.c_str(), "D") && np1 == 0) {
            t1 = t;
        } else if (!strcmp(name.c_str(), cell1.c_str()) && !strcmp(div.c_str(), "N")) {
            nab = 1;
        } else if (!strcmp(name.c_str(), cell2.c_str()) && !strcmp(div.c_str(), "N")) {
            np1 = 1;
        }

	if (!strcmp(cell1.c_str(), "AB") && !strcmp(name.c_str(), "AB") && !strcmp(div.c_str(), "N") && f1 == 0) {
	  f1 = 1;
	  fff++;
	} else if (!strcmp(cell1.c_str(), "AB") && !strcmp(name.c_str(), "P1") && !strcmp(div.c_str(), "N") && f2 == 0) {
	  f2 = 1;
	  fff++;
	}

	if (!strcmp(cell1.c_str(), "ABa") && !strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "N") && f1 == 0) {
	  f1 = 1;
	  fff++;
	} else if (!strcmp(cell1.c_str(), "ABa") && !strcmp(name.c_str(), "ABp") && !strcmp(div.c_str(), "N") && f2 == 0) {
	  f2 = 1;
	  fff++;
	}

	if (!strcmp(cell1.c_str(), "EMS") && !strcmp(name.c_str(), "EMS") && !strcmp(div.c_str(), "N") && f1 == 0) {
	  f1 = 1;
	  fff++;
	} else if (!strcmp(cell1.c_str(), "EMS") && !strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "N") && f2 == 0) {
	  f2 = 1;
	  fff++;
	}

	if (!strcmp(cell1.c_str(), "ABal") && !strcmp(name.c_str(), "ABal") && !strcmp(div.c_str(), "N") && f1 == 0) {
	  f1 = 1;
	  fff++;
	} else if (!strcmp(cell1.c_str(), "ABal") && !strcmp(name.c_str(), "ABar") && !strcmp(div.c_str(), "N") && f2 == 0) {
	  f2 = 1;
	  fff++;
	}

	if (!strcmp(cell1.c_str(), "ABpl") && !strcmp(name.c_str(), "ABpl") && !strcmp(div.c_str(), "N") && f1 == 0) {
	  f1 = 1;
	  fff++;
	} else if (!strcmp(cell1.c_str(), "ABpl") && !strcmp(name.c_str(), "ABpr") && !strcmp(div.c_str(), "N") && f2 == 0) {
	  f2 = 1;
	  fff++;
	}

	if (!strcmp(cell1.c_str(), "E") && !strcmp(name.c_str(), "E") && !strcmp(div.c_str(), "N") && f1 == 0) {
	  f1 = 1;
	  fff++;
	} else if (!strcmp(cell1.c_str(), "E") && !strcmp(name.c_str(), "MS") && !strcmp(div.c_str(), "N") && f2 == 0) {
	  f2 = 1;
	  fff++;
	}

	if (!strcmp(cell1.c_str(), "C") && !strcmp(name.c_str(), "C") && !strcmp(div.c_str(), "N") && f1 == 0) {
	  f1 = 1;
	  fff++;
	} else if (!strcmp(cell1.c_str(), "C") && !strcmp(name.c_str(), "P3") && !strcmp(div.c_str(), "N") && f2 == 0) {
	  f2 = 1;
	  fff++;
	}

    }

    if (fff != 2) {
      cout << name1 << " -1000 -1000 -1000" << endl;
      exit(-1);
    }

    if (f1 == 0 | f2 == 0) {
      cout << name1 << " -1000 -1000 -1000" << endl;
    }

    //    cerr << t1 << endl;
    tt.push_back(t1);
//    tt.unique();

    ifstream lng3;
    lng3.open(lngfile.c_str());
    if (t1 != -1) {
      while (lng3 >> t >> pid >> cid >> x >> y >> z >> name >> sp >> vol >> div) {
	if (t1 == t && !strcmp(name.c_str(), cell1.c_str())) {
	  cid1 = cid;
	} else if (t1 == t && !strcmp(name.c_str(), cell2.c_str())) {
	  cid2 = cid;
	}
      }
    }



//    last_p0n = last_p0n + 8;

//    cerr << last_p0n << endl;

//    if (!strcmp(name1.c_str(), "wt(N2)030224_01")) {
//	cerr << "hoge" << endl;
//    } else if (!strcmp(name1.c_str(), "wt(N2)030116_02")) {
//	cerr << "hoge" << endl;
//    }

    eigenVec eiv;
    ccImg ci;
    ccConv ccc;
    imageIO imgIO;
    list<zimage> zimgl;
    int tmp_t = 0;

    ifstream roi;
    roi.open(roifile.c_str());
    string f;
    int sx, sy, sz, on = 0;
    string crackcode;
    zimage *tmp_zimg;

    list<xyz> xyzl;

//    cerr << name1 << endl;

    while (roi >> f) {
        if (!strcmp(f.c_str(), "G")) {
            roi >> t >> pid >> cid >> x >> y >> z;

            if (zimgl.size() != 0 && tmp_t != t) {
                xyz xyz0;
                xyz xyz1;
                xyz xyz2;

                eiv.out2(xyz0, xyz1, xyz2, zimgl);
//                cerr << zimgl.size() << endl;
                zimgl.clear();

                // processing
//                cout << t - 1 << "\t";
                cout << name1 << "\t";
                ccc.rotate(xyz0, xyz1, xyz2, xyzl);
                xyzl.clear();
            }


            list<int>::iterator u;
            on = 0;
	    if (t1 == -1 && cid == cid0) {
	      on = 1;
	    }

            for (u = tt.begin(); u != tt.end(); u++) {
	      if ((*u) == t && (cid == cid1 | cid == cid2)) {
                    on = 1;
//                    cerr << t << endl;
//cerr << t << endl;
                }
            }

        } else if (!strcmp(f.c_str(), "R")) {
            roi >> sx >> sy >> sz >> t >> crackcode;
            if (on == 1) {
                image tmp_img;
                tmp_t = t;
                tmp_img.setSize(600, 600);
                ci.convert(tmp_img, sx, sy, crackcode);
                ccc.convert(xyzl, sx, sy, sz, crackcode);

                tmp_zimg = new zimage();
                tmp_zimg->set(sz, tmp_img);
                zimgl.push_back(*tmp_zimg);
                delete tmp_zimg;
            }
        }
    }
/*
    xyz xyz0;
    xyz xyz1;
    xyz xyz2;

    eiv.out2(xyz0, xyz1, xyz2, zimgl);
    zimgl.clear();

    // processing
    ccc.rotate(xyz0, xyz1, xyz2, xyzl);
*/
    return 0;
}
