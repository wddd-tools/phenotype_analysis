#include "image.h"
using namespace std;

class backOut {

public:
    backOut();
    ~backOut();

    void recsetBG(int, int, image &);
    void setBG(image &);
};
