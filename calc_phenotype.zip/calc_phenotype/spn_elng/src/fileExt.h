//
// fileExt.h (ipl2mroi)
// 2005-05-02 kyoda@so.bio.keio.ac.jp
//

#include <string>
using namespace std;

class fileExt {
public:
    fileExt();
    ~fileExt();

    int chkExtension(const string &, int &);
    void getExtension(const string &, string &);
};
