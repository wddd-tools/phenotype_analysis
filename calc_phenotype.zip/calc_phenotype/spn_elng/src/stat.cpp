#include <iostream>
#include <fstream>
using namespace std;

int main(int argc, char* argv[])
{
    string wtfile = argv[1];
    string rnaifile = argv[2];

    double ww[3][100];
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 100; j++)
            ww[i][j] = 0.0;

    double ms[3][2];
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 2; j++)
            ms[i][j] = 0.0;

    ifstream wt;
    wt.open(wtfile.c_str());
    string name;
    double x1, y1, z1;

    int c = 0;
    while (wt >> name >> x1 >> y1 >> z1) {
        ww[0][c] = x1;
        ww[1][c] = y1;
        ww[2][c] = z1;
        c++;
    }

    double s1, s2, n, x;
    for (int i = 0; i < 3; i++) {
        s1 = s2 = n = x = 0;
        for (int j = 0; j < 100; j++) {
            if (ww[i][j] != 0.0) {
                n = n + 1;
                x = ww[i][j];
                x -= s1;
                s1 += x / n;
                s2 += (n - 1.0) * x * x / n;
            }
        }
        s2 = sqrt(s2 / (n - 1.0));
        ms[i][0] = s1;
        ms[i][1] = s2;
    }

    ifstream rnai;
    rnai.open(rnaifile.c_str());
    double xx;

    while (rnai >> name >> x1 >> y1 >> z1) {
        cout << name << "\t";
        if (x1 == 0) {
            cout << 0 << "\t";
        } else if (abs(x1 - ms[0][0]) > 2.0 * ms[0][1]) {
            xx = x1 - ms[0][0];
            cout << xx / ms[0][1] << "\t";
        } else {
            cout << 0 << "\t";
        }

        if (y1 == 0) {
            cout << 0 << "\t";
        } else if (abs(y1 - ms[1][0]) > 2.0 * ms[1][1]) {
            xx = y1 - ms[1][0];
            cout << xx / ms[1][1] << "\t";
        } else {
            cout << 0 << "\t";
        }

        if (z1 == 0) {
            cout << 0 << "\t";
        } else if (abs(z1 - ms[2][0]) > 2.0 * ms[2][1]) {
            xx = z1 - ms[2][0];
            cout << xx / ms[2][1] << "\t";
        } else {
            cout << 0 << "\t";
        }

        cout << endl;
    }

    return 0;
}
