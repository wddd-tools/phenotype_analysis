#include <iostream>
#include <string>
#include "imageIO.h"
#include "ccImg.h"
#include "backOut.h"
using namespace std;

ccImg::ccImg()
{

}

ccImg::~ccImg()
{

}

void ccImg::convert(image &img, int x, int y, string cc)
{
    backOut bo;

    for (uint i = 0; i < img.getX(); i++) {
        for (uint j = 0; j < img.getY(); j++) {
            img.setPixel(i, j, MAXINTENSITY);
        }
    }

    string::iterator s = cc.begin();
    char prev = (*s);
    img.setPixel(x, y, MININTENSITY);
    s++;
    for (; s != cc.end(); s++) {
//        cerr << (*s);
        switch((*s)) {
        case '0':
            if (prev == '0') {
                y = y - 1;
                img.setPixel(x, y, MININTENSITY);
            } else if (prev == '1') {
                x = x - 1;
                y = y - 1;
                img.setPixel(x, y, MININTENSITY);
            }
            prev = '0';
            break;
        case '1':
            if (prev == '1') {
                x = x - 1;
                img.setPixel(x, y, MININTENSITY);
            } else if (prev == '2') {
                x = x - 1;
                y = y + 1;
                img.setPixel(x, y, MININTENSITY);
            }
            prev = '1';
            break;
        case '2':
            if (prev == '2') {
                y = y + 1;
                img.setPixel(x, y, MININTENSITY);
            } else if (prev == '3') {
                x = x + 1;
                y = y + 1;
                img.setPixel(x, y, MININTENSITY);
            }
            prev = '2';
            break;
        case '3':
            if (prev == '0') {
                x = x + 1;
                y = y - 1;
                img.setPixel(x, y, MININTENSITY);
            } else if (prev == '3') {
                x = x + 1;
                img.setPixel(x, y, MININTENSITY);
            }
            prev = '3';
            break;
        }
    }

//    imageIO imgIO;
//    string out2 = "hahaha.tif";
//    imgIO.write(img, out2);


    bo.setBG(img);

    for (uint i = 0; i < img.getX(); i++) {
        for (uint j = 0; j < img.getY(); j++) {
            if (img.getPixel(i, j) == BGINTENSITY) {
                img.setPixel(i, j, MAXINTENSITY);
            } else {
                img.setPixel(i, j, MININTENSITY);
            }
        }
    }


}
