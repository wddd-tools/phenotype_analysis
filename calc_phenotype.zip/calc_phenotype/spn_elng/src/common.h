#ifndef _COMMON_H_
#define _COMMON_H_

#define OK 1
#define NG 0

#define uint unsigned int
#define ushort unsigned short

#define BYTE 0
#define SHORT 1
#define LONG 2
#define FLOAT 3
#define COLOR16 4
#define COLOR24 5
#define UNSIGNED16 6

#define TIF 1000
#define JPG 1001

#define COLOR_DEPTH 256

#define MAXINTENSITY 0xff
#define MININTENSITY 0x00
#define BGINTENSITY 0x88

#define NOMARK 0
#define MARK 1
#define VISITED 2

#define UP 0
#define LEFT 1
#define DOWN 2
#define RIGHT 3
#define NIL 255

#define LU (1<<0+2)
#define RU (1<<1+2)
#define LD (1<<2+2)
#define RD (1<<3+2)

#define LARGE(a, b) (a)>(b)?(a):(b)
#define SMALL(a, b) (a)<(b)?(a):(b)

typedef unsigned char COLORREF;
typedef unsigned char byte;
typedef unsigned long ulong;

typedef struct IPLAB_HEADER {
    byte version[4];
    byte ipLabForm;
    byte type;
    byte width[4];
    byte height[4];
    byte reserved1[6];
    byte nFrames[2];
    byte reserved2[50];
    byte CLUT[2048];
} IPLAB_HEADER;

typedef union UX {
    ulong ldata;
    ushort sdata;
    unsigned char cdata[sizeof(long)];
    ushort hldata[2];
} UX;

#endif // _COMMON_H_
