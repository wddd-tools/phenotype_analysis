//
// fileTool.h (ipl2mroi)
// 2005-05-02 kyoda@so.bio.keio.ac.jp
//

#include <string>
using namespace std;

class fileTool {
  public:
    fileTool();
    ~fileTool();

    void input(string &, string &, string &);
    void org(string &, string &, string &, int, string &);
    void epydir(string &, string &, string &);
    void roidir(string &, string &, string &);
    void epy(string &, int, int, string &, string &, int, string &);
    void roi(string &, int, int, string &, string &, int, string &);

    void create(string &, string &, const string &, const int &);
};
