#include <iostream>
#include <string>
#include <list>
#include "xyz.h"
using namespace std;

class ccConv {

public:
    ccConv();
    ~ccConv();

    void convert(list<xyz> &, int, int, int, string);
    void rotate(xyz, xyz, xyz, list<xyz> &);
};
