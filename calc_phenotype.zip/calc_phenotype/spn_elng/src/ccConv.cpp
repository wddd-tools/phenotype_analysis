#include <iostream>
#include <cmath>
#include "ccConv.h"
using namespace std;

ccConv::ccConv()
{

}

ccConv::~ccConv()
{

}

void ccConv::convert(list<xyz> &xyzl, int x, int y, int sz, string cc)
{
    string::iterator s = cc.begin();
    char prev = (*s);
    s++;
    for (; s != cc.end(); s++) {
        xyz tmp_xyz;
        switch((*s)) {
        case '0':
            if (prev == '0') {
                y = y - 1;
                tmp_xyz.set(x, y, sz);
                xyzl.push_back(tmp_xyz);
            } else if (prev == '1') {
                x = x - 1;
                y = y - 1;
                tmp_xyz.set(x, y, sz);
                xyzl.push_back(tmp_xyz);
            }
            prev = '0';
            break;
        case '1':
            if (prev == '1') {
                x = x - 1;
                tmp_xyz.set(x, y, sz);
                xyzl.push_back(tmp_xyz);
            } else if (prev == '2') {
                x = x - 1;
                y = y + 1;
                tmp_xyz.set(x, y, sz);
                xyzl.push_back(tmp_xyz);
            }
            prev = '1';
            break;
        case '2':
            if (prev == '2') {
                y = y + 1;
                tmp_xyz.set(x, y, sz);
                xyzl.push_back(tmp_xyz);
            } else if (prev == '3') {
                x = x + 1;
                y = y + 1;
                tmp_xyz.set(x, y, sz);
                xyzl.push_back(tmp_xyz);
            }
            prev = '2';
            break;
        case '3':
            if (prev == '0') {
                x = x + 1;
                y = y - 1;
                tmp_xyz.set(x, y, sz);
                xyzl.push_back(tmp_xyz);
            } else if (prev == '3') {
                x = x + 1;
                tmp_xyz.set(x, y, sz);
                xyzl.push_back(tmp_xyz);
            }
            prev = '3';
            break;
        }
    }



}


void ccConv::rotate(xyz xyz0, xyz xyz1, xyz xyz2, list<xyz> &xyzl)
{
    double apx = xyz0.getX();
    double apy = xyz0.getY();
    double apz = xyz0.getZ();

    double lrx = xyz2.getX();
    double lry = xyz2.getY();
    double lrz = xyz2.getZ();

    double vx, vy;
    vx = apx / sqrt(apx * apx + apy * apy);
    vy = apy / sqrt(apx * apx + apy * apy);

    double tz = acos(vx);
    if (vy > 0)
        tz = - tz;

    double apx2, apy2, apz2, lrx2, lry2, lrz2;
    apx2 = apx * cos(tz) - apy * sin(tz);
    apy2 = apx * sin(tz) + apy * cos(tz);
    apz2 = apz;
    lrx2 = lrx * cos(tz) - lry * sin(tz);
    lry2 = lrx * sin(tz) + lry * cos(tz);
    lrz2 = lrz;

    double ty = acos(apx2);
    if (apz2 < 0)
        ty = - ty;

    double lrx3, lry3, lrz3;
    lrx3 = lrx2 * cos(ty) + lrz2 * sin(ty);
    lry3 = lry2;
    lrz3 = lrz2 * cos(ty) - lrx2 * sin(ty);

    double tx = acos(lrz3);
    if (lry3 < 0)
        tx = - tx;

    list<xyz> t_xyzl;
    list<xyz>::iterator r;
    for (r = xyzl.begin(); r != xyzl.end(); r++) {
//        cerr << (*r).getX() << " " << (*r).getY() << " " << (*r).getZ() << endl;
        double x, y, z;
        x = 0.105 * (*r).getX();
        y = 0.105 * (*r).getY();
        z = 0.5 * (*r).getZ();

        double x1, y1, z1;
        x1 = x * cos(tz) - y * sin(tz);
        y1 = x * sin(tz) + y * cos(tz);
        z1 = z;

        double x2, y2, z2;
        x2 = x1 * cos(ty) + z1 * sin(ty);
        y2 = y1;
        z2 = z1 * cos(ty) - x1 * sin(ty);

        double x3, y3, z3;
        x3 = x2;
        y3 = y2 * cos(tx) - z2 * sin(tx);
        z3 = y2 * sin(tx) + z2 * cos(tx);

        xyz t_xyz;
        t_xyz.set(x3, y3, z3);
        t_xyzl.push_back(t_xyz);
//        (*r).set(x3, y3, z3);
    }

    list<xyz>::iterator l;
    double minx = 1000000, miny = 1000000, minz = 1000000;
    double maxx = -1000000, maxy = -1000000, maxz = -1000000;
    for (l = t_xyzl.begin(); l != t_xyzl.end(); l++) {
        double x4, y4, z4;
        x4 = (*l).getX();
        y4 = (*l).getY();
        z4 = (*l).getZ();

        if (x4 < minx) {
            minx = x4;
        } else if (x4 > maxx) {
            maxx = x4;
        }

        if (y4 < miny) {
            miny = y4;
        } else if (y4 > maxy) {
            maxy = y4;
        }

        if (z4 < minz) {
            minz = z4;
        } else if (z4 > maxz) {
            maxz = z4;
        }
    }

    cout << maxx - minx << "\t" << maxy - miny << "\t" << maxz - minz << endl;

}
