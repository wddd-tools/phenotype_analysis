//
// fileTool.cpp (ipl2mroi)
// 2005-05-02 kyoda@so.bio.keio.ac.jp
//

#include <iostream>
#include <string>
#include <cstdio>
#include "common.h"
#include "fileTool.h"
using namespace std;

fileTool::fileTool()
{
}

fileTool::~fileTool()
{
}

void fileTool::input(string &inputpath, string &iplabfile, string &input)
{
    input = inputpath;
    input = input + iplabfile;
}

void fileTool::org(string &outputpath, string &dataset, string &iplabfile, int fr_count, string &org)
{
    org = outputpath + "ROI_" + dataset;
    string s = "/org/";
    org = org + s;

    string filename;
    filename = dataset + "-" + iplabfile + "-";

    char num[4];
    sprintf(num, "%03d.jpg", fr_count);
    filename.append(num);

    org = org + filename;
}

void fileTool::epydir(string &outputpath, string &dataset, string &epydir)
{
    epydir = outputpath + "ROI_" + dataset + "/epy/";
}

void fileTool::roidir(string &outputpath, string &dataset, string &roidir)
{
    roidir = outputpath + "ROI_" + dataset + "/roi/";
}

void fileTool::epy(string &epydir, int width, int height, string &dataset, string &iplabfile, int count, string &epyfile)
{
    char epywh[4];
    sprintf(epywh, "epy-%03dx%03d-", width, height);
    string tmp_epydir = epydir;
    tmp_epydir.append(epywh);

    char num[4];
    sprintf(num, "-%03d.tif", count);
    string tmp_iplabfile = iplabfile;
    tmp_iplabfile.append(num);

    epyfile = tmp_epydir + dataset + "-" + tmp_iplabfile;
}

void fileTool::roi(string &roidir, int width, int height, string &dataset, string &iplabfile, int count, string &roifile)
{
    char epywh[4];
    sprintf(epywh, "epy-%03dx%03d-", width, height);
    string tmp_roidir = roidir;
    tmp_roidir.append(epywh);

    char num[4];
    sprintf(num, "-%03d.roi", count);
    string tmp_iplabfile = iplabfile;
    tmp_iplabfile.append(num);

    roifile = tmp_roidir + dataset + "-" + tmp_iplabfile;
}

void fileTool::create(string &infile, string &outfile, const string &prefix, const int &width)
{
    string filename;
    string filedir;

    uint n = infile.rfind("/");
    if (string::npos != n) {
        filename = infile.substr(n + 1, string::npos);
        filedir = outfile;
    }
    else {
        filename = infile;
        filedir.erase();
    }

    n = filename.rfind(".raw");
    if (string::npos != n)
        filename.erase(n, string::npos);

    char number[4];
    if (!prefix.compare("epy")) {
        sprintf(number, "%s-%03dx%03d-", prefix.c_str(), width, width);
        filename.insert(0, number);
    }
    else {
        sprintf(number, "-%03d", width);
        filename.append(number);
    }

    outfile = filedir + filename;
}
