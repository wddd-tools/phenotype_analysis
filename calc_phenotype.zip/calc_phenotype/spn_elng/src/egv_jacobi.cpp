#include <cstdio>
#include <cmath>
#include "egv_jacobi.h"
using namespace std;

void ev_jacobi::set_matrix(int ndim0, double a0[][NDIM], int l_sort0, int l_print)
{
  ndim = ndim0;
  if (ndim < NDIM && ndim > 1)
    {
      l_matsize = 1;
      l_sort = l_sort0;
      for (int i=1; i<=ndim; ++i)
	for (int j=1; j<=ndim; ++j)
	  a[i][j] = a0[i][j];
      //
      aa = 0.0;
      for (int i=1; i<=ndim; ++i)
	for (int j=1; j<=i-1; ++j)
	  aa += a[i][j]*a[i][j];
      aa = sqrt(aa);
      //
      compute_eigenpair(l_print);
      get_p();
    }
  else
    {
      l_matsize = 0;
//      printf("ndim = %d\n", ndim);
//      printf("ndim must satisfy 1 < ndim < NDIM=%d\n", NDIM);
    }
}

void ev_jacobi::get_eigenvalue(double ev0[])
{
  for (int k=1; k<=ndim; ++k) ev0[k] = ev[p[k]];
}

void ev_jacobi::get_eigenvector(double evec0[][NDIM])
{
  for (int k=1; k<=ndim; ++k)
    for (int i=1; i<=ndim; ++i)
      evec0[k][i] = evec[p[k]][i];
}

void ev_jacobi::sort_eigenpair(int l_sort0)
{
  l_sort = l_sort0;
  get_p();
}

void ev_jacobi::compute_eigenpair(int l_print)
{
  if (l_matsize==1)
    {
      if (l_print==1)
	{
//	  printf("step %d\n", 0);
//	  print_matrix();
//	  printf("\n");
	}
      //
      double eps = 1.0e-15, epsa = eps * aa;
      int kend = 1000, l_conv = 0;
      //
      for (int i=1; i<=ndim; ++i)
	for (int j=1; j<=ndim; ++j)
	  vec[i][j] = 0.0;
      for (int i=1; i<=ndim; ++i)
	vec[i][i] = 1.0;
      //
      for (int k=1; k<=kend; ++k)
	{
	  matrix_update();
	  double a1 = 0.0;
	  for (int i=1; i<=ndim; ++i)
	    for (int j=1; j<=i-1; ++j)
	      a1 += a[i][j] * a[i][j];
	  a1 = sqrt(a1);
	  if (a1 < epsa)
	    {
	      if (l_print==1)
		{
//		  printf("converged at step %d\n", k);
//		  print_matrix();
//		  printf("\n");
		}
	      l_conv = 1;
	      break;
	    }
	  if (l_print==1)
	    if (k%10==0) 
	      {
//		printf("step %d\n", k);
//		print_matrix();
//		printf("\n");
	      }
	}
      //
      if (l_conv == 0) printf("Jacobi method not converged.\n");
      for (int k=1; k<=ndim; ++k) 
	{
	  ev[k] = a[k][k];
	  for (int i=1; i<=ndim; ++i) evec[k][i] = vec[i][k];
	}
    }
}

void ev_jacobi::print_matrix(void)
{
  for (int i=1; i<=ndim; ++i)
    {
      for (int j=1; j<=ndim; ++j) printf("%8.1e ",a[i][j]);
//      printf("\n");
    }
}

void ev_jacobi::matrix_update(void)
{
  double a_new[NDIM][NDIM], vec_new[NDIM][NDIM];
  //
  int p=2, q=1;
  double amax = fabs(a[p][q]);
  for (int i=3; i<=ndim; ++i)
    for (int j=1; j<=i-1; ++j)
      if (fabs(a[i][j]) > amax)
	{
	  p = i;
	  q = j;
	  amax = fabs(a[i][j]);
	}
	//
	// Givens' rotation by Rutishauser's rule
	//
	double z, t, c, s, u;
	z = (a[q][q]  - a[p][p]) / (2.0 * a[p][q]);
	t = fabs(z) + sqrt(1.0 + z*z);
	if (z < 0.0) t = - t;
	t = 1.0 / t;
	c = 1.0 / sqrt(1.0 + t*t);
	s = c * t;
	u = s / (1.0 + c);
	//
	for (int i=1; i<=ndim; ++i)
	  for (int j=1; j<=ndim; ++j)
	    a_new[i][j] = a[i][j];
	//
	a_new[p][p] = a[p][p] - t * a[p][q];
	a_new[q][q] = a[q][q] + t * a[p][q];
	a_new[p][q] = 0.0;
	a_new[q][p] = 0.0;
	for (int j=1; j<=ndim; ++j)
	  if (j!=p && j!=q)
	    {
	      a_new[p][j] = a[p][j] - s * (a[q][j] + u * a[p][j]);
	      a_new[j][p] = a_new[p][j];
	      a_new[q][j] = a[q][j] + s * (a[p][j] - u * a[q][j]);
	      a_new[j][q] = a_new[q][j];
	    }
	//
	for (int i=1; i<=ndim; ++i)
	  {
	    vec_new[i][p] = vec[i][p] * c - vec[i][q] * s;
	    vec_new[i][q] = vec[i][p] * s + vec[i][q] * c;
	    for (int j=1; j<=ndim; ++j)
	      if (j!=p && j!=q) vec_new[i][j] = vec[i][j];
	}
	//
	for (int i=1; i<=ndim; ++i)
	  for (int j=1; j<=ndim; ++j)
	    {
	      a[i][j] = a_new[i][j];
	      vec[i][j] = vec_new[i][j];
	    }
}

void ev_jacobi::get_p(void)
{
  for (int i=1; i<=ndim; ++i) p[i] = i;
  //
  if (l_sort==1)
    {
      for (int k=1; k<=ndim; ++k)
	{
	  double emax = ev[p[k]];
	  for (int i=k+1; i<=ndim; ++i)
	    {
	      if (emax < ev[p[i]])
		{
		  emax = ev[p[i]];
		  int pp = p[k];
		  p[k] = p[i];
		  p[i] = pp;
		}
	    }
	}
    }
  if (l_sort==0)
    {
      for (int k=1; k<=ndim; ++k)
	{
	  double emin = ev[p[k]];
	  for (int i=k+1; i<=ndim; ++i)
	    {
	      if (emin > ev[p[i]])
		{
		  emin = ev[p[i]];
		  int pp = p[k];
		  p[k] = p[i];
		  p[i] = pp;
		}
	    }
	}
    }
}
