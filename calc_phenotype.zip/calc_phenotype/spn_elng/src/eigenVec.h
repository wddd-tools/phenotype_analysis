#include <list>
#include "zimage.h"
#include "egv_jacobi.h"
#include "xyz.h"
using namespace std;

class eigenVec {

public:
    eigenVec();
    ~eigenVec();

    void out(list<zimage>);
    void out2(xyz &, xyz &, xyz &, list<zimage>);
    void exact_eigenvalue(int, double []);
    void check_eigenvector(int, double [][NDIM], double [], double [][NDIM]);
};
