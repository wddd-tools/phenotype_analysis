#include <iostream>
#include "xyz.h"
using namespace std;

xyz::xyz()
{

}

xyz::~xyz()
{

}

double xyz::getX()
{
    return x;
}

double xyz::getY()
{
    return y;
}

double xyz::getZ()
{
    return z;
}

void xyz::set(double x1, double y1, double z1)
{
    x = x1;
    y = y1;
    z = z1;
}
