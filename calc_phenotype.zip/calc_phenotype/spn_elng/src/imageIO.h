//
// imageIO.h (ipl2mroi)
// 2005-05-02 kyoda@so.bio.keio.ac.jp
//

#include <jerror.h>
#include <jpeglib.h>
#include <tiffio.h>

#include <string>
#include "image.h"
using namespace std;

class imageIO {
public:
    imageIO();
    ~imageIO();

    int read(image &, string &);
    int write(image &, string &);
    bool readjpg(image &, string &);
    bool writejpg(image &, string &);
    bool writejpg50(image &, string &);
    int readRaw(image &, char *&, int, int);
    bool readtiff(image &, string &);
    bool writetiff(image &, string &);
};
