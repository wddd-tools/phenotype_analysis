#include <iostream>
#include "image.h"
using namespace std;

class zimage {
    int z;
    image img;

public:
    zimage();
    ~zimage();

    void set(int, image);
    image getImg();
    int getZ();
};
