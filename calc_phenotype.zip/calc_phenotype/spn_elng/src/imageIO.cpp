//
// imageIO.cpp (ipl2mroi)
// 2005-05-02 kyoda@so.bio.keio.ac.jp
//

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include "imageIO.h"
#include "fileExt.h"
using namespace std;

imageIO::imageIO()
{

}

imageIO::~imageIO()
{

}

int imageIO::read(image &ic, string &file)
{
    fileExt fe;
    int type;

    fe.chkExtension(file, type);
    switch (type) {
    case TIF:
        readtiff(ic, file);
        break;
    case JPG:
        readjpg(ic, file);
        break;
    default:
        cerr << "unknown format (not tif or jpg)" << endl;
        exit(-1);
    }

    return OK;
}

bool imageIO::readjpg(image &image, string &filename)
{
    struct jpeg_decompress_struct cinfo;
    struct jpeg_error_mgr jerr;
    FILE *infile;
    JSAMPARRAY buffer;
    int row_stride;
    cinfo.err = jpeg_std_error(&jerr);

    jpeg_create_decompress(&cinfo);

    if ((infile = fopen(filename.c_str(), "rb")) == NULL) {
        fprintf(stderr, "cannot open %s\n", filename.c_str());
        return false;
    }
    jpeg_stdio_src(&cinfo, infile);
    jpeg_read_header(&cinfo, TRUE);
    jpeg_start_decompress(&cinfo);

    row_stride = cinfo.output_width * cinfo.output_components;

    buffer = (*cinfo.mem->alloc_sarray) ((j_common_ptr) &cinfo, JPOOL_IMAGE, row_stride, 1);

    image.setSize(cinfo.output_width, cinfo.output_height);
    while (cinfo.output_scanline < cinfo.output_height) {
        unsigned int y = cinfo.output_scanline;
        (void) jpeg_read_scanlines(&cinfo, buffer, 1);
        for (unsigned int x = 0; x < cinfo.output_width; x++) {
            COLORREF color;

            if (cinfo.output_components == 3) {
                color = (buffer[0][x * 3]) << 16 | ((buffer[0][x * 3 + 1]) << 8) | (buffer[0][x * 3 + 2]);
            }
            else {
                color = (buffer[0][x]) << 16 | ((buffer[0][x]) << 8) | (buffer[0][x]);
            }
            image.setPixel(x, y, color);
        }
    }

    jpeg_finish_decompress(&cinfo);
    jpeg_destroy_decompress(&cinfo);
    return true;
}

int imageIO::write(image &ic, string &file)
{
    fileExt fe;
    int type;

    fe.chkExtension(file, type);
    switch (type) {
    case TIF:
        writetiff(ic, file);
        break;
    case JPG:
        writejpg(ic, file);
        break;
    default:
        cerr << "unknown format (not tif or jpg)" << endl;
    }

    return OK;
}

bool imageIO::writejpg(image &ic, string &file)
{
    struct jpeg_compress_struct cinfo;
    struct jpeg_error_mgr jerr;
    FILE *outfile;
    JSAMPROW row_pointer[1];
    int row_stride;

    int image_width = ic.getX();
    int image_height = ic.getY();

    cinfo.err = jpeg_std_error(&jerr);
    jpeg_create_compress(&cinfo);

    if ((outfile = fopen(file.c_str(), "wb")) == NULL) {
        cerr << "cannot open " << file.c_str() << endl;
        return false;
    }
    jpeg_stdio_dest(&cinfo, outfile);

    cinfo.image_width = image_width;
    cinfo.image_height = image_height;
    cinfo.input_components = 3;
    cinfo.in_color_space = JCS_RGB;
    jpeg_set_defaults(&cinfo);
    jpeg_set_quality(&cinfo, 100, TRUE);

    jpeg_start_compress(&cinfo, TRUE);

    row_stride = image_width * 3;
    JSAMPLE *image_buffer = new JSAMPLE[image_height * row_stride];
    for (int y = 0; y < image_height; y++) {
        for (int x = 0; x < image_width; x++) {
            image_buffer[y * row_stride + x * 3] = ic.getPixelR(x, y);
            image_buffer[y * row_stride + x * 3 + 1] = ic.getPixelG(x, y);
            image_buffer[y * row_stride + x * 3 + 2] = ic.getPixelB(x, y);
        }
    }

    while (cinfo.next_scanline < cinfo.image_height) {
        row_pointer[0] = &image_buffer[cinfo.next_scanline * row_stride];
        (void) jpeg_write_scanlines(&cinfo, row_pointer, 1);
    }
    delete image_buffer;

    jpeg_finish_compress(&cinfo);
    fclose(outfile);
    jpeg_destroy_compress(&cinfo);

    return true;
}

bool imageIO::writejpg50(image &ic, string &file)
{
    struct jpeg_compress_struct cinfo;
    struct jpeg_error_mgr jerr;
    FILE *outfile;
    JSAMPROW row_pointer[1];
    int row_stride;

    int image_width = ic.getX();
    int image_height = ic.getY();

    cinfo.err = jpeg_std_error(&jerr);
    jpeg_create_compress(&cinfo);

    if ((outfile = fopen(file.c_str(), "wb")) == NULL) {
        cerr << "cannot open " << file.c_str() << endl;
        return false;
    }
    jpeg_stdio_dest(&cinfo, outfile);

    cinfo.image_width = image_width;
    cinfo.image_height = image_height;
    cinfo.input_components = 3;
    cinfo.in_color_space = JCS_RGB;
    jpeg_set_defaults(&cinfo);
    jpeg_set_quality(&cinfo, 50, TRUE);

    jpeg_start_compress(&cinfo, TRUE);

    row_stride = image_width * 3;
    JSAMPLE *image_buffer = new JSAMPLE[image_height * row_stride];
    for (int y = 0; y < image_height; y++) {
        for (int x = 0; x < image_width; x++) {
            image_buffer[y * row_stride + x * 3] = ic.getPixelR(x, y);
            image_buffer[y * row_stride + x * 3 + 1] = ic.getPixelG(x, y);
            image_buffer[y * row_stride + x * 3 + 2] = ic.getPixelB(x, y);
        }
    }

    while (cinfo.next_scanline < cinfo.image_height) {
        row_pointer[0] = &image_buffer[cinfo.next_scanline * row_stride];
        (void) jpeg_write_scanlines(&cinfo, row_pointer, 1);
    }
    delete image_buffer;

    jpeg_finish_compress(&cinfo);
    fclose(outfile);
    jpeg_destroy_compress(&cinfo);

    return true;
}

int imageIO::readRaw(image &ic, char *&raw_data, int width, int height)
{
    int img_size = width * height;

    ic.setSize(width, height);
    int x = 0, y = -1;
    for (int i = 0; i < img_size; i++) {
        char val = *(raw_data + i);
        if (i % width == 0) {
            y++;
        }
        x = i - width * y;
        ic.setPixel(x, y, val);
    }

    return OK;
}

bool imageIO::readtiff(image &ic, string &file)
{
    uint32 width, height;
    uint16 BitsPerSample, SamplesPerPixel, PhotoMetric;
    unsigned char *raster;
    TIFF *infile;
    int chk_IO;

    if ((infile = TIFFOpen(file.c_str(), "r")) == NULL) {
        fprintf(stderr, "could not open\n");
        exit(42);
    }

    TIFFGetField(infile, TIFFTAG_IMAGEWIDTH, &width);
    TIFFGetField(infile, TIFFTAG_IMAGELENGTH, &height);
    TIFFGetField(infile, TIFFTAG_BITSPERSAMPLE, &BitsPerSample);
    TIFFGetField(infile, TIFFTAG_SAMPLESPERPIXEL, &SamplesPerPixel);
    TIFFGetField(infile, TIFFTAG_PHOTOMETRIC, &PhotoMetric);

    if ((raster = (unsigned char *) _TIFFmalloc(width * height)) == NULL) {
        fprintf(stderr, "could not malloc\n");
        exit(42);
    }

    for (uint32 r = 0; r < height; r++) {
        chk_IO = TIFFReadScanline(infile, &raster[r * width], r, 1);
        if (chk_IO != 1) {
            fprintf(stderr, "could not read image\n");
            exit(42);
        }
    }

    int img_size = width * height;
    ic.setSize(width, height);
    int x = 0, y = -1;

    for (int i = 0; i < img_size; i++) {
        char val = *(raster + i);
        if (i % width == 0)
            y++;
        x = i - width * y;
        ic.setPixel(x, y, val);
    }

    _TIFFfree(raster);
    TIFFClose(infile);

    return true;
}

bool imageIO::writetiff(image &ic, string &file)
{
    uint32 width, height;
    uint16 BitsPerSample, SamplesPerPixel, PhotoMetric;
    unsigned char *raster;
    TIFF *outfile;
    int chk_IO;

    width = ic.getX();
    height = ic.getY();

    // setting for grayscale tiff image
    BitsPerSample = 8;
    SamplesPerPixel = 1;
    PhotoMetric = 1;

    if ((raster = (unsigned char *) _TIFFmalloc(width * height)) == NULL) {
        fprintf(stderr, "could not malloc\n");
        exit(42);
    }

    for (uint j = 0; j < height; j++)
        for (uint i = 0; i < width; i++)
            raster[j * width + i] = ic.getPixel(i, j);

    if ((outfile = TIFFOpen(file.c_str(), "w")) == NULL) {
        fprintf(stderr, "could not open output tiff file\n");
        exit(42);
    }

    TIFFSetField(outfile, TIFFTAG_IMAGEWIDTH, width);
    TIFFSetField(outfile, TIFFTAG_IMAGELENGTH, height);
    TIFFSetField(outfile, TIFFTAG_BITSPERSAMPLE, BitsPerSample);
    TIFFSetField(outfile, TIFFTAG_SAMPLESPERPIXEL, SamplesPerPixel);
    TIFFSetField(outfile, TIFFTAG_PHOTOMETRIC, PhotoMetric);
    TIFFSetField(outfile, TIFFTAG_PLANARCONFIG, 1);

    // for iplab 9bit/8bit tiff image
    TIFFSetField(outfile, TIFFTAG_XRESOLUTION, 72.0);
    TIFFSetField(outfile, TIFFTAG_YRESOLUTION, 72.0);


    for (uint32 r = 0; r < height; r++) {
        chk_IO = TIFFWriteScanline(outfile, &raster[r * width], r, 1);
        if (chk_IO != 1) {
            fprintf(stderr, "could not read image file\n");
            exit(42);
        }
    }

    _TIFFfree(raster);
    TIFFClose(outfile);

    return true;
}
