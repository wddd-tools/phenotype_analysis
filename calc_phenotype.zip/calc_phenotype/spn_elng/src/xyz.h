#include <iostream>
using namespace std;

#ifndef _XYZ_H
#define _XYZ_H

class xyz {
    double x;
    double y;
    double z;
public:
    xyz();
    ~xyz();

    double getX();
    double getY();
    double getZ();
    void set(double, double, double);
};

#endif
