#include <iostream>
#include "image.h"
#include "backOut.h"
#include "common.h"
using namespace std;

backOut::backOut()
{
}

backOut::~backOut()
{
}

void backOut::recsetBG(int x, int y, image &img)
{
    int min = x, max = x;

    if (x < 0 || x >= img.getX() || y < 0 || y >= img.getY())
        return;
    if (img.getPixel(x, y) != MAXINTENSITY)
        return;

    while (min >= 0 && img.getPixel(min, y) == MAXINTENSITY)
        min--;
    min++;

    while (max < img.getX() && img.getPixel(max, y) == MAXINTENSITY)
        max++;
    max--;

    for (int i = min; i <= max; i++)
        img.setPixel(i, y, BGINTENSITY);

    for (int j = min; j <= max; j++) {
        recsetBG(j, y - 1, img);
        recsetBG(j, y + 1, img);
    }
}

void backOut::setBG(image &img)
{
    for (int y = 0; y < img.getY(); y++)
        if (img.getPixel(0, y) == MAXINTENSITY)
            recsetBG(0, y, img);
}
