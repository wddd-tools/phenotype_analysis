//
// fileExt.cpp (ipl2mroi)
// 2005-05-02 kyoda@so.bio.keio.ac.jp
//

#include <iostream>
#include <string>
#include "common.h"
#include "fileExt.h"
using namespace std;

fileExt::fileExt()
{

}

fileExt::~fileExt()
{

}

int fileExt::chkExtension(const string &file, int &type)
{
    string ext;

    getExtension(file, ext);
    if (!ext.compare("tif") || !ext.compare("tiff") || !ext.compare("TIF")
        || !ext.compare("TIFF")) {
        type = TIF;
    } else if (!ext.compare("jpg") || !ext.compare("jpeg")
               || !ext.compare("JPG") || !ext.compare("JPEG")) {
        type = JPG;
    } else {
        cerr << "unknown file format (not tif or jpg)" << endl;
    }
    return OK;
}

void fileExt::getExtension(const string &file, string &ext)
{
    int n = file.rfind(".");
    ext = file.substr(n + 1, string::npos);
}
