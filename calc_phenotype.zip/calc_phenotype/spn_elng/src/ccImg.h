#include <string>
#include "image.h"
using namespace std;

class ccImg {

public:
    ccImg();
    ~ccImg();

    void convert(image &, int, int, string);
};
