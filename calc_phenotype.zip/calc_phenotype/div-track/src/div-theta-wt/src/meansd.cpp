#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
  string wtfile = argv[1];

  double data[33][21];
  for (int i = 0; i < 33; i++)
    for (int j = 0; j < 21; j++)
      data[i][j] = 0.0;

  double mean[1][21];
  double sd[1][21];
  for (int i = 0; i < 21; i++) {
    mean[0][i] = 0.0;
    sd[0][i] = 0.0;
  }


  ifstream wt;
  wt.open(wtfile.c_str(), ios::in);
  string name;
  double val;
  for (int i = 0; i < 33; i++) {
    wt >> name;
    for (int j = 0; j < 21; j++) {
      wt >> val;
      data[i][j] = val;
    }
  }
  wt.close();


  double s1, s2, n, x;
  for (int j = 0; j < 21; j++) {
    s1 = s2 = n = x = 0.0;
    for (int i = 0; i < 33; i++) {
      if (data[i][j] != 0) {
	n = n + 1;
	x = (double) data[i][j];
	x -= s1;
	s1 += x / n;
	s2 += (n - 1.0) * x * x / n;
      }
    }
    s2 = sqrt(s2 / (n - 1.0));
    mean[0][j] = s1;
    sd[0][j] = s2;
  }



  for (int i = 0; i < 21; i++) {
    cout << mean[0][i] << "\t";
  }
  cout << endl;
  for (int i = 0; i < 21; i++) {
    cout << sd[0][i] << "\t";
  }
  cout << endl;

  return 0;
}
