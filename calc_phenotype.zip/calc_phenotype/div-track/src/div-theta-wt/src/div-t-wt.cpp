#define PI 3.14159265

#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
  string wtfile = argv[1];
  string rnaifile = argv[2];

  double mp0x, mabx, mp1x, mabax, mabpx, memsx, mp2x;
  double mp0y, maby, mp1y, mabay, mabpy, memsy, mp2y;
  double mp0z, mabz, mp1z, mabaz, mabpz, memsz, mp2z;
  double sp0x, sabx, sp1x, sabax, sabpx, semsx, sp2x;
  double sp0y, saby, sp1y, sabay, sabpy, semsy, sp2y;
  double sp0z, sabz, sp1z, sabaz, sabpz, semsz, sp2z;

  ifstream wt;
  wt.open(wtfile.c_str());
  if (!wt) {
    cerr << "cannot open wt file" << endl;
    exit(-1);
  } else {
    wt >> mp0x >> mp0y >> mp0z >> mabx >> maby >> mabz >> mp1x >> mp1y >> mp1z >> mabax >> mabay >> mabaz >> mabpx >> mabpy >> mabpz >> memsx >> memsy >> memsz >> mp2x >> mp2y >> mp2z;
    wt >> sp0x >> sp0y >> sp0z >> sabx >> saby >> sabz >> sp1x >> sp1y >> sp1z >> sabax >> sabay >> sabaz >> sabpx >> sabpy >> sabpz >> semsx >> semsy >> semsz >> sp2x >> sp2y >> sp2z;
  }

  double dp0, dab, dp1, daba, dabp, dems, dp2;

  dp0 = sqrt(mp0x * mp0x + mp0y * mp0y + mp0z * mp0z);
  mp0x = mp0x / dp0;
  mp0y = mp0y / dp0;
  mp0z = mp0z / dp0;

  dab = sqrt(mabx * mabx + maby * maby + mabz * mabz);
  mabx = mabx / dab;
  maby = maby / dab;
  mabz = mabz / dab;

  dp1 = sqrt(mp1x * mp1x + mp1y * mp1y + mp1z * mp1z);
  mp1x = mp1x / dp1;
  mp1y = mp1y / dp1;
  mp1z = mp1z / dp1;

  daba = sqrt(mabax * mabax + mabay * mabay + mabaz * mabaz);
  mabax = mabax / daba;
  mabay = mabay / daba;
  mabaz = mabaz / daba;

  dabp = sqrt(mabpx * mabpx + mabpy * mabpy + mabpz * mabpz);
  mabpx = mabpx / dabp;
  mabpy = mabpy / dabp;
  mabpz = mabpz / dabp;

  dems = sqrt(memsx * memsx + memsy * memsy + memsz * memsz);
  memsx = memsx / dems;
  memsy = memsy / dems;
  memsz = memsz / dems;

  dp2 = sqrt(mp2x * mp2x + mp2y * mp2y + mp2z * mp2z);
  mp2x = mp2x / dp2;
  mp2y = mp2y / dp2;
  mp2z = mp2z / dp2;

  string gname;
  double p0x, abx, p1x, abax, abpx, emsx, p2x;
  double p0y, aby, p1y, abay, abpy, emsy, p2y;
  double p0z, abz, p1z, abaz, abpz, emsz, p2z;

  ifstream rnai;
  rnai.open(rnaifile.c_str());
  if (!rnai) {
    cerr << "cannot open rnai file" << endl;
    exit(-1);
  } else {
    while (rnai >> gname >> p0x >> p0y >> p0z >> abx >> aby >> abz >> p1x >> p1y >> p1z >> abax >> abay >> abaz >> abpx >> abpy >> abpz >> emsx >> emsy >> emsz >> p2x >> p2y >> p2z) {
      cout << gname << " ";

      if (p0x != -1000 && p0y != -1000 && p0z != -1000) {
	cout << acos(p0x * mp0x + p0y * mp0y + p0z * mp0z) / PI * 180.0 << " ";
      } else {
	cout << "-1000 ";
      }

      if (abx != -1000 && aby != -1000 && abz != -1000) {
	cout << acos(abx * mabx + aby * maby + abz * mabz) / PI * 180.0 << " ";
      } else {
	cout << "-1000 ";
      }

      if (p1x != -1000 && p1y != -1000 && p1z != -1000) {
	cout << acos(p1x * mp1x + p1y * mp1y + p1z * mp1z) / PI * 180.0 << " ";
      } else {
	cout << "-1000 ";
      }

      if (abax != -1000 && abay != -1000 && abaz != -1000) {
	cout << acos(abax * mabax + abay * mabay + abaz * mabaz) / PI * 180.0 << " ";	
      } else {
	cout << "-1000 ";
      }

      if (abpx != -1000 && abpy != -1000 && abpz != -1000) {
	cout << acos(abpx * mabpx + abpy * mabpy + abpz * mabpz) / PI * 180.0 << " ";
      } else {
	cout << "-1000 ";
      }

      if (emsx != -1000 && emsy != -1000 && emsz != -1000) {
	cout << acos(emsx * memsx + emsy * memsy + emsz * memsz) / PI * 180.0 << " ";
      } else {
	cout << "-1000 ";
      }

      if (p2x != -1000 && p2y != -1000 && p2z != -1000) {
	cout << acos(p2x * mp2x + p2y * mp2y + p2z * mp2z) / PI * 180.0 << endl;
      } else {
	cout << "-1000" << endl;
      }
    }
  }

  return 0;
}
