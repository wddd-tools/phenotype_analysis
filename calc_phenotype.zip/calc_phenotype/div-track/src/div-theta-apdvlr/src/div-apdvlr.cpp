#define PI 3.14159265358979

#include <iostream>
#include <cstring>
#include <fstream>
#include <cstdlib>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
  string vecfile = argv[1];

  string gname;

  double p0x, p0y, p0z;

  double abx, aby, abz;
  double p1x, p1y, p1z;

  double abax, abay, abaz;
  double abpx, abpy, abpz;
  double emsx, emsy, emsz;
  double p2x, p2y, p2z;

  ifstream vec;
  vec.open(vecfile.c_str());
  if (!vec) {
    cerr << "cannot open vec file" << endl;
    exit(-1);
  } else {
    while (vec >> gname >> p0x >> p0y >> p0z >> abx >> aby >> abz >> p1x >> p1y >> p1z >> abax >> abay >> abaz >> abpx >> abpy >> abpz >> emsx >> emsy >> emsz >> p2x >> p2y >> p2z) {

      cout << gname << " ";

      // P0

      if (p0x != -1000 && p0y != -1000 && p0z != -1000) {
	if (p0y > 0) {
	  cout << acos(p0x / sqrt(p0x * p0x + p0y * p0y)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(p0x / sqrt(p0x * p0x + p0y * p0y)) / PI * 180.0 << " ";
	}

	if (p0z > 0) {
	  cout << acos(p0y / sqrt(p0y * p0y + p0z * p0z)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(p0y / sqrt(p0y * p0y + p0z * p0z)) / PI * 180.0 << " ";
	}

	if (p0x > 0) {
	  cout << acos(p0z / sqrt(p0z * p0z + p0x * p0x)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(p0z / sqrt(p0z * p0z + p0x * p0x)) / PI * 180.0 << " ";
	}
      } else {
	cout << "-1000 -1000 -1000 ";
      }


      // AB

      if (abx != -1000 && aby != -1000 && abz != -1000) {
	if (aby > 0) {
	  cout << acos(abx / sqrt(abx * abx + aby * aby)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(abx / sqrt(abx * abx + aby * aby)) / PI * 180.0 << " ";
	}

	if (abz > 0) {
	  cout << acos(aby / sqrt(aby * aby + abz * abz)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(aby / sqrt(aby * aby + abz * abz)) / PI * 180.0 << " ";
	}

	if (abx > 0) {
	  cout << acos(abz / sqrt(abz * abz + abx * abx)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(abz / sqrt(abz * abz + abx * abx)) / PI * 180.0 << " ";
	}
      } else {
	cout << "-1000 -1000 -1000 ";
      }


      // P1

      if (p1x != -1000 && p1y != -1000 && p1z != -1000) {
	if (p1y > 0) {
	  cout << acos(p1x / sqrt(p1x * p1x + p1y * p1y)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(p1x / sqrt(p1x * p1x + p1y * p1y)) / PI * 180.0 << " ";
	}

	if (p1z > 0) {
	  cout << acos(p1y / sqrt(p1y * p1y + p1z * p1z)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(p1y / sqrt(p1y * p1y + p1z * p1z)) / PI * 180.0 << " ";
	}

	if (p1x > 0) {
	  cout << acos(p1z / sqrt(p1z * p1z + p1x * p1x)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(p1z / sqrt(p1z * p1z + p1x * p1x)) / PI * 180.0 << " ";
	}
      } else {
	cout << "-1000 -1000 -1000 ";
      }


      // ABa

      if (abax != -1000 && abay != -1000 && abaz != -1000) {
	if (abay > 0) {
	  cout << acos(abax / sqrt(abax * abax + abay * abay)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(abax / sqrt(abax * abax + abay * abay)) / PI * 180.0 << " ";
	}

	if (abaz > 0) {
	  cout << acos(abay / sqrt(abay * abay + abaz * abaz)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(abay / sqrt(abay * abay + abaz * abaz)) / PI * 180.0 << " ";
	}

	if (abax > 0) {
	  cout << acos(abaz / sqrt(abaz * abaz + abax * abax)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(abaz / sqrt(abaz * abaz + abax * abax)) / PI * 180.0 << " ";
	}
      } else {
	cout << "-1000 -1000 -1000 ";
      }


      // ABp

      if (abpx != -1000 && abpy != -1000 && abpz != -1000) {
	if (abpy > 0) {
	  cout << acos(abpx / sqrt(abpx * abpx + abpy * abpy)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(abpx / sqrt(abpx * abpx + abpy * abpy)) / PI * 180.0 << " ";
	}

	if (abpz > 0) {
	  cout << acos(abpy / sqrt(abpy * abpy + abpz * abpz)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(abpy / sqrt(abpy * abpy + abpz * abpz)) / PI * 180.0 << " ";
	}

	if (abpx > 0) {
	  cout << acos(abpz / sqrt(abpz * abpz + abpx * abpx)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(abpz / sqrt(abpz * abpz + abpx * abpx)) / PI * 180.0 << " ";
	}
      } else {
	cout << "-1000 -1000 -1000 ";
      }


      // EMS

      if (emsx != -1000 && emsy != -1000 && emsz != -1000) {
	if (emsy > 0) {
	  cout << acos(emsx / sqrt(emsx * emsx + emsy * emsy)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(emsx / sqrt(emsx * emsx + emsy * emsy)) / PI * 180.0 << " ";
	}

	if (emsz > 0) {
	  cout << acos(emsy / sqrt(emsy * emsy + emsz * emsz)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(emsy / sqrt(emsy * emsy + emsz * emsz)) / PI * 180.0 << " ";
	}

	if (emsx > 0) {
	  cout << acos(emsz / sqrt(emsz * emsz + emsx * emsx)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(emsz / sqrt(emsz * emsz + emsx * emsx)) / PI * 180.0 << " ";
	}
      } else {
	cout << "-1000 -1000 -1000 ";
      }


      // P2

      if (p2x != -1000 && p2y != -1000 && p2z != -1000) {
	if (p2y > 0) {
	  cout << acos(p2x / sqrt(p2x * p2x + p2y * p2y)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(p2x / sqrt(p2x * p2x + p2y * p2y)) / PI * 180.0 << " ";
	}

	if (p2z > 0) {
	  cout << acos(p2y / sqrt(p2y * p2y + p2z * p2z)) / PI * 180.0 << " ";
	} else {
	  cout << - acos(p2y / sqrt(p2y * p2y + p2z * p2z)) / PI * 180.0 << " ";
	}

	if (p2x > 0) {
	  cout << acos(p2z / sqrt(p2z * p2z + p2x * p2x)) / PI * 180.0 << endl;
	} else {
	  cout << - acos(p2z / sqrt(p2z * p2z + p2x * p2x)) / PI * 180.0 << endl;
	}

      } else {
	cout << "-1000 -1000 -1000" << endl;
      }

    }
  }

  return 0;
}
