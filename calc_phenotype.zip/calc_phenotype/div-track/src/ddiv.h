#ifndef _DDIV_H_
#define _DDIV_H_

class ddiv {
  double x;
  double y;
  double z;

 public:
  ddiv();
  ~ddiv();

  void setX(double);
  void setY(double);
  void setZ(double);
  double getX();
  double getY();
  double getZ();
};

#endif // _DDIV_H_
