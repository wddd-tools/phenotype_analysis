#define PI 3.14159265

#include <iostream>
#include <fstream>
#include <cmath>
#include <cstring>
#include <cstdlib>
using namespace std;

int main(int argc, char* argv[])
{
  string vecfile = argv[1];

  string gname;
  double p0x, p0y, p0z;
  double abx, aby, abz;
  double p1x, p1y, p1z;
  double abax, abay, abaz;
  double abpx, abpy, abpz;
  double emsx, emsy, emsz;
  double p2x, p2y, p2z;

  ifstream vec;
  vec.open(vecfile.c_str());
  if (!vec) {
    cerr << "cannot open vec file" << endl;
    exit(-1);
  } else {
    while (vec >> gname >> p0x >> p0y >> p0z >> abx >> aby >> abz >> p1x >> p1y >> p1z >> abax >> abay >> abaz >> abpx >> abpy >> abpz >> emsx >> emsy >> emsz >> p2x >> p2y >> p2z) {


      cout << gname << " ";
      if (p0x != -1000 && p0y != -1000 && p0z != -1000 && abx != -1000 && aby != -1000 && abz != -1000) {
	double p0ab = acos(p0x * abx + p0y * aby + p0z * abz) / PI * 180.0;
	cout << p0ab << " ";
      } else {
	cout << "-1000 ";
      }

      if (p0x != -1000 && p0y != -1000 && p0z != -1000 && p1x != -1000 && p1y != -1000 && p1z != -1000) {
	double p0p1 = acos(p0x * p1x + p0y * p1y + p0z * p1z) / PI * 180.0;
	cout << p0p1 << " ";
      } else {
	cout << "-1000 ";
      }

      if (p0x != -1000 && p0y != -1000 && p0z != -1000 && abax != -1000 && abay != -1000 && abaz != -1000) {
	double p0aba = acos(p0x * abax + p0y * abay + p0z * abaz) / PI * 180.0;
	cout << p0aba << " ";
      } else {
	cout << "-1000 ";
      }

      if (p0x != -1000 && p0y != -1000 && p0z != -1000 && abpx != -1000 && abpy != -1000 && abpz != -1000) {
	double p0abp = acos(p0x * abpx + p0y * abpy + p0z * abpz) / PI * 180.0;
	cout << p0abp << " ";
      } else {
	cout << "-1000 ";
      }

      if (p0x != -1000 && p0y != -1000 && p0z != -1000 && emsx != -1000 && emsy != -1000 && emsz != -1000) {
	double p0ems = acos(p0x * emsx + p0y * emsy + p0z * emsz) / PI * 180.0;
	cout << p0ems << " ";
      } else {
	cout << "-1000 ";
      }

      if (p0x != -1000 && p0y != -1000 && p0z != -1000 && p2x != -1000 && p2y != -1000 && p2z != -1000) {
	double p0p2 = acos(p0x * p2x + p0y * p2y + p0z * p2z) / PI * 180.0;
	cout << p0p2 << " ";
      } else {
	cout << "-1000 ";
      }

      if (abx != -1000 && aby != -1000 && abz != -1000 && p1x != -1000 && p1y != -1000 && p1z != -1000) {
	double abp1 = acos(abx * p1x + aby * p1y + abz * p1z) / PI * 180.0;
	cout << abp1 << " ";
      } else {
	cout << "-1000 ";
      }

      if (abx != -1000 && aby != -1000 && abz != -1000 && abax != -1000 && abay != -1000 && abaz != -1000) {
	double ababa = acos(abx * abax + aby * abay + abz * abaz) / PI * 180.0;
	cout << ababa << " ";
      } else {
	cout << "-1000 ";
      }

      if (abx != -1000 && aby != -1000 && abz != -1000 && abpx != -1000 && abpy != -1000 && abpz != -1000) {
	double ababp = acos(abx * abpx + aby * abpy + abz * abpz) / PI * 180.0;
	cout << ababp << " ";
      } else {
	cout << "-1000 ";
      }

      if (abx != -1000 && aby != -1000 && abz != -1000 && emsx != -1000 && emsy != -1000 && emsz != -1000) {
	double abems = acos(abx * emsx + aby * emsy + abz * emsz) / PI * 180.0;
	cout << abems << " ";
      } else {
	cout << "-1000 ";
      }

      if (abx != -1000 && aby != -1000 && abz != -1000 && p2x != -1000 && p2y != -1000 && p2z != -1000) {
	double abp2 = acos(abx * p2x + aby * p2y + abz * p2z) / PI * 180.0;
	cout << abp2 << " ";
      } else {
	cout << "-1000 ";
      }

      if (p1x != -1000 && p1y != -1000 && p1z != -1000 && abax != -1000 && abay != -1000 && abaz != -1000) {
	double p1aba = acos(p1x * abax + p1y * abay + p1z * abaz) / PI * 180.0;
	cout << p1aba << " ";
      } else {
	cout << "-1000 ";
      }

      if (p1x != -1000 && p1y != -1000 && p1z != -1000 && abpx != -1000 && abpy != -1000 && abpz != -1000) {
	double p1abp = acos(p1x * abpx + p1y * abpy + p1z * abpz) / PI * 180.0;
	cout << p1abp << " ";
      } else {
	cout << "-1000 ";
      }

      if (p1x != -1000 && p1y != -1000 && p1z != -1000 && emsx != -1000 && emsy != -1000 && emsz != -1000) {
	double p1ems = acos(p1x * emsx + p1y * emsy + p1z * emsz) / PI * 180.0;
	cout << p1ems << " ";
      } else {
	cout << "-1000 ";
      }

      if (p1x != -1000 && p1y != -1000 && p1z != -1000 && p2x != -1000 && p2y != -1000 && p2z != -1000) {
	double p1p2 = acos(p1x * p2x + p1y * p2y + p1z * p2z) / PI * 180.0;
	cout << p1p2 << " ";
      } else {
	cout << "-1000 ";
      }

      if (abax != -1000 && abay != -1000 && abaz != -1000 && abpx != -1000 && abpy != -1000 && abpz != -1000) {
	double abaabp = acos(abax * abpx + abay * abpy + abaz * abpz) / PI * 180.0;
	cout << abaabp << " ";
      } else {
	cout << "-1000 ";
      }

      if (abax != -1000 && abay != -1000 && abaz != -1000 && emsx != -1000 && emsy != -1000 && emsz != -1000) {
	double abaems = acos(abax * emsx + abay * emsy + abaz * emsz) / PI * 180.0;
	cout << abaems << " ";
      } else {
	cout << "-1000 ";
      }

      if (abax != -1000 && abay != -1000 && abaz != -1000 && p2x != -1000 && p2y != -1000 && p2z != -1000) {
	double abap2 = acos(abax * p2x + abay * p2y + abaz * p2z) / PI * 180.0;
	cout << abap2 << " ";
      } else {
	cout << "-1000 ";
      }

      if (abpx != -1000 && abpy != -1000 && abpz != -1000 && emsx != -1000 && emsy != -1000 && emsz != -1000) {
	double abpems = acos(abpx * emsx + abpy * emsy + abpz * emsz) / PI * 180.0;
	cout << abpems << " ";
      } else {
	cout << "-1000 ";
      }

      if (abpx != -1000 && abpy != -1000 && abpz != -1000 && p2x != -1000 && p2y != -1000 && p2z != -1000) {
	double abpp2 = acos(abpx * p2x + abpy * p2y + abpz * p2z) / PI * 180.0;
	cout << abpp2 << " ";
      } else {
	cout << "-1000 ";
      }

      if (emsx != -1000 && emsy != -1000 && emsz != -1000 && p2x != -1000 && p2y != -1000 && p2z != -1000) {
	double emsp2 = acos(emsx * p2x + emsy * p2y + emsz * p2z) / PI * 180.0;
	cout << emsp2 << endl;
      } else {
	cout << "-1000" << endl;
      }
    }
  }

  return 0;
}
