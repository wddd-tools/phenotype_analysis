#include <iostream>
#include <cstring>
#include <cstdlib>
#include <list>
#include <fstream>
#include <cmath>
#include "ddiv.h"
using namespace std;

int main(int argc, char* argv[])
{
  string gname = argv[1];
  string plngfile = argv[2];
  string axisfile = argv[3];
  string apfile = argv[4];
  string gpfile = argv[5];

  list<ddiv> divl;
  list<ddiv>::iterator p;

  ifstream plng;
  plng.open(plngfile.c_str());

  double apx, apy, apz;
  ifstream ap;
  ap.open(apfile.c_str());
  ap >> apx >> apy >> apz;
  ap.close();

  double gpx, gpy, gpz;
  ifstream gp;
  gp.open(gpfile.c_str(), ios::in);
  gp >> gpx >> gpy >> gpz;
  gp.close();

  int t, pid, cid;
  double x, y, z, sph, vol;
  string name, div;
  double abax = 0.0, abay = 0.0, abaz = 0.0;
  double abpx = 0.0, abpy = 0.0, abpz = 0.0;
  int fab = 0;
  int faba = 0, fabp = 0;

  int axisid;
  double ev1, ev2, ev3, evec1x, evec1y, evec1z, evec2x, evec2y, evec2z, evec3x, evec3y, evec3z;
  int divt = 0;

  while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div) {
    if (faba == 1 && fabp == 1) {
      break;
    }

    if (!strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "N")) {
      fab = 1;
    }

    if (!strcmp(name.c_str(), "ABal")) {
      abax = x;
      abay = y;
      abaz = z;
      faba = 1;
    } else if (!strcmp(name.c_str(), "ABar")) {
      abpx = x;
      abpy = y;
      abpz = z;
      fabp = 1;
    }

    if (!strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "D") && fab == 1) {
      if (divt == 0) {
	divt = t;
      }
      int abid = cid;
      ifstream axis;
      axis.open(axisfile.c_str());

      while (axis >> axisid >> ev1 >> ev2 >> ev3 >> evec1x >> evec1y >> evec1z >> evec2x >> evec2y >> evec2z >> evec3x >> evec3y >> evec3z) {
	if (axisid == abid) {
	  ddiv tmp_div;
	  tmp_div.setX(evec1x);
	  tmp_div.setY(evec1y);
	  tmp_div.setZ(evec1z);
	  divl.push_back(tmp_div);
	  break;
	}
      }
      axis.close();

    }
  }
  plng.close();

  divl.reverse();


  double dis = sqrt((abax - abpx) * (abax - abpx) + (abay - abpy) * (abay - abpy) + (abaz - abpz) * (abaz - abpz));
  double xxx = (abpx - abax) / dis;
  double yyy = (abpy - abay) / dis;
  double zzz = (abpz - abaz) / dis;

  double tmp_x = 0.0;
  double tmp_y = 0.0;
  double tmp_z = 0.0;
  for (p = divl.begin(); p != divl.end(); p++) {
    if (tmp_x == 0 && tmp_y == 0 && tmp_z == 0) {
      tmp_x = xxx;
      tmp_y = yyy;
      tmp_z = zzz;
    }

    double inn = tmp_x * p->getX() + tmp_y * p->getY() + tmp_z * p->getZ();
    if (inn > 0.0) {
      tmp_x = p->getX();
      tmp_y = p->getY();
      tmp_z = p->getZ();
    } else {
      tmp_x = - p->getX();
      tmp_y = - p->getY();
      tmp_z = - p->getZ();
    }

  }

  cout << gname << "\t";


  double tdvx, tdvy, tdvz, d;
  plng.open(plngfile.c_str(), ios::in);
  while (plng >> t >> pid >> cid >> x >> y >> z >> name>> sph >> vol >> div) {
    if (!strcmp(name.c_str(), "EMS") && divt == t) {
      tdvx = x - gpx;
      tdvy = y - gpy;
      tdvz = z - gpz;
      d = sqrt(tdvx * tdvx + tdvy * tdvy + tdvz * tdvz);
      tdvx = tdvx / d;
      tdvy = tdvy / d;
      tdvz = tdvz / d;
      break;
    } else if (!strcmp(name.c_str(), "E") && divt == t) {
      tdvx = x - gpx;
      tdvy = y - gpy;
      tdvz = z - gpz;
      d = sqrt(tdvx * tdvx + tdvy * tdvy + tdvz * tdvz);
      tdvx = tdvx / d;
      tdvy = tdvy / d;
      tdvz = tdvz / d;
      break;
    } else if (!strcmp(name.c_str(), "Ep") && divt == t) {
      tdvx = x - gpx;
      tdvy = y - gpy;
      tdvz = z - gpz;
      d = sqrt(tdvx * tdvx + tdvy * tdvy + tdvz * tdvz);
      tdvx = tdvx / d;
      tdvy = tdvy / d;
      tdvz = tdvz / d;
      break;
    } else if (!strcmp(name.c_str(), "EMS") && divt < t) {
      tdvx = x - gpx;
      tdvy = y - gpy;
      tdvz = z - gpz;
      d = sqrt(tdvx * tdvx + tdvy * tdvy + tdvz * tdvz);
      tdvx = tdvx / d;
      tdvy = tdvy / d;
      tdvz = tdvz / d;
      break;
    } 
  }
  plng.close();


  double tlrx, tlry, tlrz;
  tlrx = apy * tdvz - apz * tdvy;
  tlry = apz * tdvx - apx * tdvz;
  tlrz = apx * tdvy - apy * tdvx;

  double lrx, lry, lrz;
  lrx = tlrx / sqrt(tlrx * tlrx + tlry * tlry + tlrz * tlrz);
  lry = tlry / sqrt(tlrx * tlrx + tlry * tlry + tlrz * tlrz);
  lrz = tlrz / sqrt(tlrx * tlrx + tlry * tlry + tlrz * tlrz);

  double vx, vy;
  vx = apx / sqrt(apx * apx + apy * apy);
  vy = apy / sqrt(apx * apx + apy * apy);

  double tz = acos(vx);
  if (vy > 0)
    tz = - tz;

  double apx2, apy2, apz2, lrx2, lry2, lrz2;
  apx2 = apx * cos(tz) - apy * sin(tz);
  apy2 = apx * sin(tz) + apy * cos(tz);
  apz2 = apz;
  lrx2 = lrx * cos(tz) - lry * sin(tz);
  lry2 = lrx * sin(tz) + lry * cos(tz);
  lrz2 = lrz;

  double ty = acos(apx2);
  if (apz2 < 0)
    ty = - ty;

  double lrx3, lry3, lrz3;
  lrx3 = lrx2 * cos(ty) + lrz2 * sin(ty);
  lry3 = lry2;
  lrz3 = lrz2 * cos(ty) - lrx2 * sin(ty);

  double tx = acos(lrz3);
  if (lry3 < 0)
    tx = - tx;


  double x1, y1, z1, x2, y2, z2, x3, y3, z3;
  x1 = tmp_x * cos(tz) - tmp_y * sin(tz);
  y1 = tmp_x * sin(tz) + tmp_y * cos(tz);
  z1 = tmp_z;
  x2 = x1 * cos(ty) + z1 * sin(ty);
  y2 = y1;
  z2 = z1 * cos(ty) - x1 * sin(ty);
  x3 = x2;
  y3 = y2 * cos(tx) - z2 * sin(tx);
  z3 = y2 * sin(tx) + z2 * cos(tx);

  if (tmp_x != 0 && tmp_y != 0 && tmp_z != 0) {
    cout << x3 << "\t" << y3 << "\t" << z3 << endl;
  } else {
    cout << "-1000\t-1000\t-1000" << endl;
  }


  /*
  x1 = xxx * cos(tz) - yyy * sin(tz);
  y1 = xxx * sin(tz) + yyy * cos(tz);
  z1 = zzz;
  x2 = x1 * cos(ty) + z1 * sin(ty);
  y2 = y1;
  z2 = z1 * cos(ty) - x1 * sin(ty);
  x3 = x2;
  y3 = y2 * cos(tx) - z2 * sin(tx);
  z3 = y2 * sin(tx) + z2 * cos(tx);

  if (tmp_x != 0 && tmp_y != 0 && tmp_z != 0) {
    cout << x3 << "\t" << y3 << "\t" << z3 << endl;
  } else {
    cout << "-1000\t-1000\t-1000" << endl;
  }
  */

  return 0;
}
