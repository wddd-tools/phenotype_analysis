#include "ddiv.h"
using namespace std;

ddiv::ddiv()
{

}

ddiv::~ddiv()
{

}

void ddiv::setX(double c)
{
  x = c;
}

void ddiv::setY(double c)
{
  y = c;
}

void ddiv::setZ(double c)
{
  z = c;
}

double ddiv::getX()
{
  return x;
}

double ddiv::getY()
{
  return y;
}

double ddiv::getZ()
{
  return z;
}
