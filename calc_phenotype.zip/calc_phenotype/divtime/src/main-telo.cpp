// division timing ABa/ABp (metaphase)

#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
using namespace std;

int main(int argc, char* argv[])
{
  string gname = argv[1];
  string lngfile = argv[2];

  int t, pid, cid;
  double x, y, z, s, vol;
  string name, div;
  int fab = 0, fp1 = 0, faba = 0, fabp = 0, fems = 0, fp2 = 0, fabal = 0, fabar = 0, fabpl = 0, fabpr = 0, fe = 0, fms = 0, fc = 0, fp3 = 0;
  int tab = 0, tp1 = 0, taba = 0, tabp = 0, tems = 0, tp2 = 0, tabal = 0, tabar = 0, tabpl = 0, tabpr = 0, te = 0, tms = 0, tc =0, tp3 = 0;
  int nab = 0, np1 = 0, naba = 0, nabp = 0, nems = 0, np2 = 0;

  ifstream lng;
  lng.open(lngfile.c_str());
  if (!lng) {
    cerr << "cannot open lng file" << endl;
    exit(-1);
  } else {
    while (lng >> t >> pid >> cid >> x >> y >> z >> name >> s >> vol >> div) {

      if (!strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "D") && faba == 0) {
	taba = t;
      } else if (!strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "N")) {
	faba = 1;
      } else if (!strcmp(name.c_str(), "ABp") && !strcmp(div.c_str(), "D") && fabp == 0) {
	tabp = t;
      } else if (!strcmp(name.c_str(), "ABp") && !strcmp(div.c_str(), "N")) {
	fabp = 1;
      } else if (!strcmp(name.c_str(), "EMS") && !strcmp(div.c_str(), "D") && fems == 0) {
	tems = t;
      } else if (!strcmp(name.c_str(), "EMS") && !strcmp(div.c_str(), "N")) {
	fems = 1;
      } else if (!strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "D") && fp2 == 0) {
	tp2 = t;
      } else if (!strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "N")) {
	fp2 = 1;
      } else if (!strcmp(name.c_str(), "ABal") && !strcmp(div.c_str(), "D") && fabal == 0) {
	tabal = t;
      } else if (!strcmp(name.c_str(), "ABal") && !strcmp(div.c_str(), "N")) {
	fabal = 1;
      } else if (!strcmp(name.c_str(), "ABar") && !strcmp(div.c_str(), "D") && fabar == 0) {
	tabar = t;
      } else if (!strcmp(name.c_str(), "ABar") && !strcmp(div.c_str(), "N")) {
	fabar = 1;
      } else if (!strcmp(name.c_str(), "ABpl") && !strcmp(div.c_str(), "D") && fabpl == 0) {
	tabpl = t;
      } else if (!strcmp(name.c_str(), "ABpl") && !strcmp(div.c_str(), "N")) {
	fabpl = 1;
      } else if (!strcmp(name.c_str(), "ABpr") && !strcmp(div.c_str(), "D") && fabpr == 0) {
	tabpr = t;
      } else if (!strcmp(name.c_str(), "ABpr") && !strcmp(div.c_str(), "N")) {
	fabpr = 1;
      } else if (!strcmp(name.c_str(), "E") && !strcmp(div.c_str(), "D") && fe == 0) {
	te = t;
      } else if (!strcmp(name.c_str(), "E") && !strcmp(div.c_str(), "N")) {
	fe = 1;
      } else if (!strcmp(name.c_str(), "MS") && !strcmp(div.c_str(), "D") && fms == 0) {
	tms = t;
      } else if (!strcmp(name.c_str(), "MS") && !strcmp(div.c_str(), "N")) {
	fms = 1;
      } else if (!strcmp(name.c_str(), "C") && !strcmp(div.c_str(), "D") && fc == 0) {
	tc = t;
      } else if (!strcmp(name.c_str(), "C") && !strcmp(div.c_str(), "N")) {
	fc = 1;
      } else if (!strcmp(name.c_str(), "P3") && !strcmp(div.c_str(), "D") && fp3 == 0) {
	tp3 = t;
      } else if (!strcmp(name.c_str(), "P3") && !strcmp(div.c_str(), "N")) {
	fp3 = 1;
      }

      if (!strcmp(name.c_str(), "AB")) {
	nab = t;
      } else if (!strcmp(name.c_str(), "ABa")) {
	naba = t;
      } else if (!strcmp(name.c_str(), "ABp")) {
	nabp = t;
      } else if (!strcmp(name.c_str(), "P1")) {
	np1 = t;
      } else if (!strcmp(name.c_str(), "EMS")) {
	nems = t;
      } else if (!strcmp(name.c_str(), "P2")) {
	np2 = t;
      }
    }
  }

  int ttab, ttp1, ttaba, ttabp, ttems, ttp2;

  if (taba == 0 && tabp == 0 && faba == 1 && fabp == 1) {
    ttab = nab;
  } else if (taba > tabp) {
    ttab = taba;
  } else {
    ttab = tabp;
  }

  if (tems == 0 && tp2 == 0 && fems == 1 && fp2 == 1) {
    ttp1 = np1;
  } else if (tems > tp2) {
    ttp1 = tems;
  } else {
    ttp1 = tp2;
  }

  if (tabal == 0 && tabar == 0 && fabal == 1 && fabar == 1) {
    ttaba = naba;
  } else if (tabal > tabar) {
    ttaba = tabal;
  } else {
    ttaba = tabar;
  }

  if (tabpl == 0 && tabpr == 0 && fabpl == 1 && fabpr == 1) {
    ttabp = nabp;
  } else if (tabpl > tabpr) {
    ttabp = tabpl;
  } else {
    ttabp = tabpr;
  }

  if (te == 0 && tms == 0 && fe == 1 && fms == 1) {
    ttems = nems;
  } else if (te > tms) {
    ttems = te;
  } else {
    ttems = tms;
  }

  if (tc == 0 && tp3 == 0 && fc == 1 && fp3 == 1) {
    ttp2 = np2;
  } else if (tc > tp3) {
    ttp2 = tc;
  } else {
    ttp2 = tp3;
  }


  cout << gname << " ";


  // output!!!

  if (ttab != 0 && ttp1 != 0) {
    cout << ttp1 - ttab << " ";
  } else {
    cout << "-1000 ";
  }
  if (ttaba != 0 && ttabp != 0) {
    cout << ttabp - ttaba << " ";
  } else {
    cout << "-1000 ";
  }
  if (ttems != 0 && ttaba != 0) {
    cout << ttems - ttaba << " ";
  } else {
    cout << "-1000 ";
  }
  if (ttems != 0 && ttabp != 0) {
    cout << ttems - ttabp << " ";
  } else {
    cout << "-1000 ";
  }
  if (ttp2 != 0 && ttems != 0) {
    cout << ttp2 - ttems << endl;
  } else {
    cout << "-1000" << endl;
  }


  //  cout << gname << " " << tabp - taba << " " << tems - taba << " " << tems - tabp << " " << tp2 - tems << endl;


  return 0;
}
