// division timing ABa/ABp (metaphase)

#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
using namespace std;

int main(int argc, char* argv[])
{
  string gname = argv[1];
  string lngfile = argv[2];

  int t, pid, cid;
  double x, y, z, s, vol;
  string name, div;
  int fab = 0, fp1 = 0, faba = 0, fabp = 0, fems = 0, fp2 = 0;
  int tab = 0, tp1 = 0, taba = 0, tabp = 0, tems = 0, tp2 = 0;

  ifstream lng;
  lng.open(lngfile.c_str());
  if (!lng) {
    cerr << "cannot open lng file" << endl;
    exit(-1);
  } else {
    while (lng >> t >> pid >> cid >> x >> y >> z >> name >> s >> vol >> div) {
      if (!strcmp(name.c_str(), "AB") && !strcmp(div.c_str(), "D") && fab == 1) {
	tab = t;
	fab = 2;
      } else if (!strcmp(name.c_str(), "AB") && !strcmp(div.c_str(), "N")) {
	fab = 1;
      } else if (!strcmp(name.c_str(), "P1") && !strcmp(div.c_str(), "D") && fp1 == 1) {
	tp1 = t;
	fp1 = 2;
      } else if (!strcmp(name.c_str(), "P1") && !strcmp(div.c_str(), "N")) {
	fp1 = 1;
      } else if (!strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "D") && faba == 1) {
	taba = t;
	faba = 2;
      } else if (!strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "N")) {
	faba = 1;
      } else if (!strcmp(name.c_str(), "ABp") && !strcmp(div.c_str(), "D") && fabp == 1) {
	tabp = t;
	fabp = 2;
      } else if (!strcmp(name.c_str(), "ABp") && !strcmp(div.c_str(), "N")) {
	fabp = 1;
      } else if (!strcmp(name.c_str(), "EMS") && !strcmp(div.c_str(), "D") && fems == 1) {
	tems = t;
	fems = 2;
      } else if (!strcmp(name.c_str(), "EMS") && !strcmp(div.c_str(), "N")) {
	fems = 1;
      } else if (!strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "D") && fp2 == 1) {
	tp2 = t;
	fp2 = 2;
      } else if (!strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "N")) {
	fp2 = 1;
      }

    }
  }


  cout << gname << " ";
  if (tab != 0 && tp1 != 0) {
    cout << tp1 - tab << " ";
  } else {
    cout << "-1000 ";
  }

  if (taba != 0 && tabp != 0) {
    cout << tabp - taba << " ";
  } else {
    cout << "-1000 ";
  }

  if (tems != 0 && taba != 0) {
    cout << tems - taba << " ";
  } else {
    cout << "-1000 ";
  }

  if (tems != 0 && tabp != 0) {
    cout << tems - tabp << " ";
  } else {
    cout << "-1000 ";
  }

  if (tp2 != 0 && tems != 0) {
    cout << tp2 - tems << endl;
  } else {
    cout << "-1000" << endl;
  }



  //  cout << gname << " " << tabp - taba << " " << tems - taba << " " << tems - tabp << " " << tp2 - tems << endl;


  return 0;
}
