#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <list>
using namespace std;

int main(int argc, char* argv[])
{
  string gname = argv[1];
  string lngfile = argv[2];
  string cell1 = argv[3];
  string cell2 = argv[4];

  list<int> tt;
  int t, pid, cid;
  double x, y, z, sph, vol;
  string name, div;
  int nab = 0, np1 = 0;

  ifstream lng;
  lng.open(lngfile.c_str());
  if (!lng) {
    cerr << "cannot open lng file" << endl;
    exit(-1);
  } else {
    while (lng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div) {
      if (!strcmp(name.c_str(), cell1.c_str()) && !strcmp(div.c_str(), "N")) {
	if (np1 == 1) {
	  tt.push_back(t);
	}
	nab = 1;
      } else if (!strcmp(name.c_str(), cell2.c_str()) && !strcmp(div.c_str(), "N")) {
	if (nab == 1) {
	  tt.push_back(t);
	}
	np1 = 1;
      } else if (!strcmp(name.c_str(), cell1.c_str()) && !strcmp(div.c_str(), "D")) {
	nab = 0;
      } else if (!strcmp(name.c_str(), cell2.c_str()) && !strcmp(div.c_str(), "D")) {
	np1 = 0;
      } else if (!strcmp(cell1.c_str(), "AB")) {
	if (!strcmp(name.c_str(), "ABa")) {
	  nab = 0;
	} else if (!strcmp(name.c_str(), "ABp")) {
	  nab = 0;
	}
      } else if (!strcmp(cell1.c_str(), "P1")) {
	if (!strcmp(name.c_str(), "EMS")) {
	  nab = 0;
	} else if (!strcmp(name.c_str(), "P2")) {
	  nab = 0;
	}
      } else if (!strcmp(cell1.c_str(), "ABa")) {
	if (!strcmp(name.c_str(), "ABal")) {
	  nab = 0;
	} else if (!strcmp(name.c_str(), "ABar")) {
	  nab = 0;
	}
      } else if (!strcmp(cell1.c_str(), "ABp")) {
	if (!strcmp(name.c_str(), "ABpl")) {
	  nab = 0;
	} else if (!strcmp(name.c_str(), "ABpr")) {
	  nab = 0;
	}
      } else if (!strcmp(cell1.c_str(), "EMS")) {
	if (!strcmp(name.c_str(), "E")) {
	  nab = 0;
	} else if (!strcmp(name.c_str(), "MS")) {
	  nab = 0;
	}
      } else if (!strcmp(cell1.c_str(), "P2")) {
	if (!strcmp(name.c_str(), "C")) {
	  nab = 0;
	} else if (!strcmp(name.c_str(), "P3")) {
	  nab = 0;
	}
      } else if (!strcmp(cell2.c_str(), "AB")) {
	if (!strcmp(name.c_str(), "ABa")) {
	  np1 = 0;
	} else if (!strcmp(name.c_str(), "ABp")) {
	  np1 = 0;
	}
      } else if (!strcmp(cell2.c_str(), "P1")) {
	if (!strcmp(name.c_str(), "EMS")) {
	  np1 = 0;
	} else if (!strcmp(name.c_str(), "P2")) {
	  np1 = 0;
	}
      } else if (!strcmp(cell2.c_str(), "ABa")) {
	if (!strcmp(name.c_str(), "ABal")) {
	  np1 = 0;
	} else if (!strcmp(name.c_str(), "ABar")) {
	  np1 = 0;
	}
      } else if (!strcmp(cell2.c_str(), "ABp")) {
	if (!strcmp(name.c_str(), "ABpl")) {
	  np1 = 0;
	} else if (!strcmp(name.c_str(), "ABpr")) {
	  np1 = 0;
	}
      } else if (!strcmp(cell2.c_str(), "EMS")) {
	if (!strcmp(name.c_str(), "E")) {
	  np1 = 0;
	} else if (!strcmp(name.c_str(), "MS")) {
	  np1 = 0;
	}
      } else if (!strcmp(cell2.c_str(), "P2")) {
	if (!strcmp(name.c_str(), "C")) {
	  np1 = 0;
	} else if (!strcmp(name.c_str(), "P3")) {
	  np1 = 0;
	}
      }
    }
  }

  if (!strcmp(cell1.c_str(), "AB") && !strcmp(cell2.c_str(), "P1")) {
    cout << gname << " ";
  }


  if (tt.size() == 0) {
    cout << "-1000 ";
    if (!strcmp(cell1.c_str(), "EMS") && !strcmp(cell2.c_str(), "P2")) {
      cout << endl;
    }
    exit(0);
  }

  int ttt = 0;
  list<int>::iterator p;
  for (p = tt.begin(); p != tt.end(); p++) {
    ttt = ttt + (*p);
  }

  ttt = ttt / tt.size();
  //  cout << ttt << endl;

  double abx = 0.0, aby = 0.0, abz = 0.0;
  double p1x = 0.0, p1y = 0.0, p1z = 0.0;
  lng.close();

  ifstream lng2;
  lng2.open(lngfile.c_str());
  while (lng2 >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div) {
    if (t == ttt && !strcmp(name.c_str(), cell1.c_str())) {
      abx = x;
      aby = y;
      abz = z;
    } else if (t == ttt && !strcmp(name.c_str(), cell2.c_str())) {
      p1x = x;
      p1y = y;
      p1z = z;
    }
  }

  double xx = p1x - abx;
  double yy = p1y - aby;
  double zz = p1z - abz;

  double d = sqrt(xx * xx + yy * yy + zz * zz);

  //  cout << abx << " " << aby << " " << abz << " " << p1x << " " << p1y << " " << p1z << endl;
  if (abx == 0.0 | aby == 0.0 | abz == 0.0 | p1x == 0.0 | p1y == 0.0 | p1z == 0.0) {
    cout << "-1000 ";
    if (!strcmp(cell1.c_str(), "EMS") && !strcmp(cell2.c_str(), "P2")) {
      cout << endl;
    }
  } else {
    cout << d << " ";
    if (!strcmp(cell1.c_str(), "EMS") && !strcmp(cell2.c_str(), "P2")) {
      cout << endl;
    }
  }

  return 0;
}
