#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
using namespace std;

int main(int argc, char* argv[])
{
    string name1 = argv[1];
    string lngfile = argv[2];

    ifstream lng;
    lng.open(lngfile.c_str());
    int t, pid, cid, tp0 = -1, tab = -1, fp0 = 0, faba = 0, fabp = 0, ft = -1;
    double x, y, z, sp, vol;
    string name, div;

    while (lng >> t >> pid >> cid >> x >> y >> z >> name >> sp >> vol >> div) {
        if (!strcmp(name.c_str(), "P0") && !strcmp(div.c_str(), "D") && fp0 == 0) {
            tp0 = t;
            fp0 = 1;
        } else if (!strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "N") && faba == 0) {
            faba = 1;
            if (fabp == 1) {
                tab = t;
                break;
            }
        } else if (!strcmp(name.c_str(), "ABp") && !strcmp(div.c_str(), "N") && fabp == 0) {
            fabp = 1;
            if (faba == 1) {
                tab = t;
                break;
            }
        } else if (!strcmp(name.c_str(), "AB")) {
	  ft = t;
	}

    }

    int tt = -1;
    tt = tab - tp0;

    if (tp0 == 1) {
        cout << name1 << " -1000" << endl;
    } else if (tab == -1) {
        if (tp0 == -1) {
            cout << name1 << " -1000" << endl;
        } else {
            if (ft != -1)
              cout << name1 << " " << ft - tp0 << endl;
            else
              cout << name1 << " " << tp0 << endl;
        }
    } else if (tp0 == -1) {
        cout << name1 << " -1000" << endl;
    } else {
        cout << name1 << " " << tab - tp0 << endl;
    }

//    cout << name1 << "\t" << tt << endl;



    return 0;
}
