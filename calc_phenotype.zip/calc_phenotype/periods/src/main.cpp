#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
using namespace std;

int main(int argc, char* argv[])
{
    string name = argv[1];
    string input = argv[2];

    int t, pid, cid;
    double x, y, z, sp, vol;
    string cn, nd;
    int fp0 = 0, fab = 0, fp1 = 0, faba = 0, fabp = 0, fems = 0, fp2 = 0, fabal = 0, fabar = 0, fabpl = 0, fabpr = 0, fe = 0, fms = 0, fc = 0, fp3 = 0;
    int tp0 = 0, tab = 0, tp1 = 0, taba = 0, tabp = 0, tems = 0, tp2 = 0, tabal = 0, tabar = 0, tabpl = 0, tabpr = 0, te = 0, tms = 0, tc = 0, tp3 = 0;
    int cp0 = 0, cab = 0, cp1 = 0, caba = 0, cabp = 0, cems = 0, cp2 = 0;
    int chab = 0, chp1 = 0, chaba = 0, chabp = 0, chems = 0, chp2 = 0, chabal = 0, chabar = 0, chabpl = 0, chabpr = 0, che = 0, chms = 0, chc = 0, chp3 = 0;

    ifstream in;
    in.open(input.c_str());

    if (!in) {
        cerr << "cannot open.." << endl;
        exit(-1);
    } else {
        while (in >> t >> pid >> cid >> x >> y >> z >> cn >> sp >> vol >> nd) {
            if (!cn.compare("AB")) {
                chab = 1;
                if (!nd.compare("N")) {
                    if (fab == 0) {
                        tab = t;
                    }
                    cab++;
                    fab = 1;
                }
            } else if (!cn.compare("P1")) {
                chp1 = 1;
                if (!nd.compare("N")) {
                    if (fp1 == 0) {
                        tp1 = t;
                    }
                    cp1++;
                    fp1 = 1;
                }
            } else if (!cn.compare("ABa")) {
                chaba = 1;
                if (!nd.compare("N")) {
                    if (faba == 0) {
                        taba = t;
                    }
                    caba++;
                    faba = 1;
                }
            } else if (!cn.compare("ABp")) {
                chabp = 1;
                if (!nd.compare("N")) {
                    if (fabp == 0) {
                        tabp = t;
                    }
                    cabp++;
                    fabp = 1;
                }
            } else if (!cn.compare("EMS")) {
                chems = 1;
                if (!nd.compare("N")) {
                    if (fems == 0) {
                        tems = t;
                    }
                    cems++;
                    fems = 1;
                }
            } else if (!cn.compare("P2")) {
                chp2 = 1;
                if (!nd.compare("N")) {
                    if (fp2 == 0) {
                        tp2 = t;
                    }
                    cp2++;
                    fp2 = 1;
                }
            } else if (!cn.compare("ABal")) {
                chabal = 1;
                if (!nd.compare("N") & fabal == 0) {
                    tabal = t;
                    fabal = 1;
                }
            } else if (!cn.compare("ABar")) {
                chabar = 1;
                if (!nd.compare("N") & fabar == 0) {
                    tabar = t;
                    fabar = 1;
                }
            } else if (!cn.compare("ABpl")) {
                chabpl = 1;
                if (!nd.compare("N") & fabpl == 0) {
                    tabpl = t;
                    fabpl = 1;
                }
            } else if (!cn.compare("ABpr")) {
                chabpr = 1;
                if (!nd.compare("N") & fabpr == 0) {
                    tabpr = t;
                    fabpr = 1;
                }
            } else if (!cn.compare("E")) {
                che = 1;
                if (!nd.compare("N") & fe == 0) {
                    te = t;
                    fe = 1;
                }
            } else if (!cn.compare("MS")) {
                chms = 1;
                if (!nd.compare("N") & fms == 0) {
                    tms = t;
                    fms = 1;
                }
            } else if (!cn.compare("C")) {
                chc = 1;
                if (!nd.compare("N") & fc == 0) {
                    tc = t;
                    fc = 1;
                }
            } else if (!cn.compare("P3")) {
                chp3 = 1;
                if (!nd.compare("N") & fp3 == 0) {
                    tp3 = t;
                    fp3 = 1;
                }
            } else if (!cn.compare("P0")) {
		if (!nd.compare("N")) {
			cp0++;
		}
                if (!nd.compare("N") & fp0 == 0) {
                    if (fp0 == 0) {
                        tp0 = t;
                    }
                    fp0 = 1;
                }
            }
        }
    }

    int dp0 = -1000, dab = -1000, dp1 = -1000, daba = -1000, dabp = -1000, dems = -1000, dp2 = -1000;

    if (tab != 0 & tp1 != 0 & tp0 != 0) {
        if (cp0 != 0) {
            if (tab > tp1) {
                dp0 = tab - cp0;
            } else {
                dp0 = tp1 - cp0;
            }
        }
    }

    if (taba != 0 & tabp != 0 & tab != 0) {
        if (cab != 0) {
            if (taba > tabp) {
                dab = taba - tab - cab;
            } else {
                dab = tabp - tab - cab;
            }
        }
    }

    if (tems != 0 & tp2 != 0 & tp1 != 0) {
        if (cp1 != 0) {
            if (tems > tp2) {
                dp1 = tems - tp1 - cp1;
            } else {
                dp1 = tp2 - tp1 -cp1;
            }
        }
    }

    if (tabal != 0 & tabar != 0 & taba != 0) {
        if (caba != 0) {
            if (tabal > tabar) {
                daba = tabal - taba - caba;
            } else {
                daba = tabar - taba - caba;
            }
        }
    }

    if (tabpl != 0 & tabpr != 0 & tabp != 0) {
        if (cabp != 0) {
            if (tabpl > tabpr) {
                dabp = tabpl - tabp - cabp;
            } else {
                dabp = tabpr - tabp - cabp;
            }
        }
    }

    if (te != 0 & tms != 0 & tems != 0) {
        if (cems != 0) {
            if (te > tms) {
                dems = te - tems - cems;
            } else {
                dems = tms - tems - cems;
            }
        }
    }

    if (tc != 0 & tp3 != 0 & tp2 != 0) {
        if (cp2 != 0) {
            if (tc > tp3) {
                dp2 = tc - tp2 - cp2;
            } else {
                dp2 = tp3 - tp2 -cp2;
            }
        }
    }

    if (chab != 1 | chp1 != 1) {
        cp0 = -1000;
    }
    if (chaba != 1 | chabp != 1) {
        cab = -1000;
    }
    if (chems != 1 | chp2 != 1) {
        cp1 = -1000;
    }
    if (chabal != 1 | chabar != 1) {
        caba = -1000;
    }
    if (chabpl != 1 | chabpr != 1) {
        cabp = -1000;
    }
    if (che != 1 | chms != 1) {
        cems = -1000;
    }
    if (chp3 != 1 | chc != 1) {
        cp2 = -1000;
    }


    cout << name << " " << cab << " " << cp1 << " " << caba << " " << cabp << " " << cems << " " << cp2 << " " << dp0 << " " << dab << " " << dp1 << " " << daba << " " << dabp << " " << dems << " " << dp2 << endl;


    return 0;
}
