#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
  string gname = argv[1];
  string plngfile = argv[2];
  string clngfile = argv[3];
  string cellx = argv[4];
  string celly = argv[5];
  string cellz = argv[6];
  string gposfile = argv[7];
  string apfile = argv[8];

  ifstream plng;
  plng.open(plngfile.c_str(), ios::in);

  int t2, pid2, cid2;
  int t, id, pid, cid, et, p0t, abt = 0, p1t = 0, tid = 0, fab = 0, fp1 = 0, fems = 0;
  double x, y, z, x2, y2, z2, sph, vol;
  string name, div, name2;
  while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div) {
    if (!strcmp(name.c_str(), "EMS")) {
      fems = 1;
    }
  }
  plng.close();

  plng.open(plngfile.c_str(), ios::in);
  while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div) {
    if (fab == 1 && fp1 == 1)
      break;

    if (!strcmp(name.c_str(), cellx.c_str())) {
      p0t = t;
    }

    if (!strcmp(name.c_str(), celly.c_str()) && !strcmp(div.c_str(), "D")) {
      abt = t;
    } else if (!strcmp(name.c_str(), cellz.c_str()) && !strcmp(div.c_str(), "D")) {
      p1t = t;
    } else if (!strcmp(name.c_str(), celly.c_str()) && !strcmp(div.c_str(), "N")) {
      fab = 1;
    } else if (!strcmp(name.c_str(), cellz.c_str()) && !strcmp(div.c_str(), "N")) {
      fp1 = 1;
    }
  }
  plng.close();

  if (fab == 0 | fp1 == 0) {
    cout << gname << " -1000 -1000 -1000 -1000" << endl;
    exit(-1); 
  }

  if (abt < p1t)
    et = p1t;
  else
    et = abt;

  tid = et;

//  cerr << fems << endl;


  double x3, y3, z3;
  double xx01, yy01, zz01, xx02, yy02, zz02;

  double gx, gy, gz;
  gx = gy = gz = 0.0;
  double apx, apy, apz;
  apx = apy = apz = 0.0;
  if (fems == 0) {
    if (!strcmp(cellx.c_str(), "P0")) {
      ifstream gpos;
      ifstream ap;
      gpos.open(gposfile.c_str(), ios::in);
      if (gpos) {
        gpos >> gx >> gy >> gz;
        ap.open(apfile.c_str(), ios::in);
        if (!ap) {
          cout << gname << " -1000 -1000 -1000 -1000" << endl;
          exit(-1);
        }

        ap >> apx >> apy >> apz;
        if (tid == 0) {
          plng.open(plngfile.c_str(), ios::in);
          while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div) {
            if (!strcmp(name.c_str(), "P0")) {
              x3 = x;
              y3 = y;
              z3 = z;
            }
          }
          plng.close();

          double x4, y4, z4;
          double dis;
          x4 = x3 - gx;
          y4 = y3 - gy;
          z4 = z3 - gz;
          dis = sqrt((x3 - gx) * (x3 - gx) + (y3 - gy) * (y3 - gy) + (z3 - gz) * (z3 - gz));

          double vecx, vecy, vecz;
          vecx = x4 / dis;
          vecy = y4 / dis;
          vecz = z4 / dis;

          double cos_theta = apx * vecx + apy * vecy + apz * vecz;
          double theta = acos(cos_theta);

          double antpos_x = dis * cos(theta);

          cout << gname << " " << antpos_x << " -1000 -1000 " << dis << endl;
          exit(-1);

        } else {
          plng.open(plngfile.c_str(), ios::in);
          while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div) {
            if (tid == t && !strcmp(name.c_str(), "AB")) {
              xx01 = x;
              yy01 = y;
              zz01 = z;
            } else if (tid == t && !strcmp(name.c_str(), "P1")) {
              xx02 = x;
              yy02 = y;
              zz02 = z;
            }
          }
          plng.close();

          x3 = (xx01 + xx02) / 2.0;
          y3 = (yy01 + yy02) / 2.0;
          z3 = (zz01 + zz02) / 2.0;

          double x4, y4, z4;
          double dis;
          x4 = x3 - gx;
          y4 = y3 - gy;
          z4 = z3 - gz;
          dis = sqrt((x3 - gx) * (x3 - gx) + (y3 - gy) * (y3 - gy) + (z3 - gz) * (z3 - gz));

          double vecx, vecy, vecz;
          vecx = x4 / dis;
          vecy = y4 / dis;
          vecz = z4 / dis;

          double cos_theta = apx * vecx + apy * vecy + apz * vecz;
          double theta = acos(cos_theta);

          double antpos_x = dis * cos(theta);

          cout << gname << " " << antpos_x << " -1000 -1000 " << dis << endl;
          exit(-1);

        }
      } else {
        cout << gname << " -1000 -1000 -1000 -1000" << endl;
      }

    } else if (!strcmp(cellx.c_str(), "AB")) {
      ifstream gpos;
      ifstream ap;
      gpos.open(gposfile.c_str(), ios::in);
      if (gpos) {
        gpos >> gx >> gy >> gz;
        ap.open(apfile.c_str(), ios::in);
        if (!ap) {
          cout << gname << " -1000 -1000 -1000 -1000" << endl;
          exit(-1);
        }

        ap >> apx >> apy >> apz;
        if (tid == 0) {
          plng.open(plngfile.c_str(), ios::in);
          while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div) {
            if (!strcmp(name.c_str(), "AB")) {
              x3 = x;
              y3 = y;
              z3 = z;
            }
          }
          plng.close();

          double x4, y4, z4;
          double dis;
          x4 = x3 - gx;
          y4 = y3 - gy;
          z4 = z3 - gz;
          dis = sqrt((x3 - gx) * (x3 - gx) + (y3 - gy) * (y3 - gy) + (z3 - gz) * (z3 - gz));

          double vecx, vecy, vecz;
          vecx = x4 / dis;
          vecy = y4 / dis;
          vecz = z4 / dis;

          double cos_theta = apx * vecx + apy * vecy + apz * vecz;
          double theta = acos(cos_theta);

          double antpos_x = dis * cos(theta);

          cout << gname << " " << antpos_x << " -1000 -1000 " << dis << endl;
          exit(-1);

        } else {
          plng.open(plngfile.c_str(), ios::in);
          while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div) {
            if (tid == t && !strcmp(name.c_str(), "ABa")) {
              xx01 = x;
              yy01 = y;
              zz01 = z;
            } else if (tid == t && !strcmp(name.c_str(), "ABp")) {
              xx02 = x;
              yy02 = y;
              zz02 = z;
            }
          }
          plng.close();

          x3 = (xx01 + xx02) / 2.0;
          y3 = (yy01 + yy02) / 2.0;
          z3 = (zz01 + zz02) / 2.0;

          double x4, y4, z4;
          double dis;
          x4 = x3 - gx;
          y4 = y3 - gy;
          z4 = z3 - gz;
          dis = sqrt((x3 - gx) * (x3 - gx) + (y3 - gy) * (y3 - gy) + (z3 - gz) * (z3 - gz));

          double vecx, vecy, vecz;
          vecx = x4 / dis;
          vecy = y4 / dis;
          vecz = z4 / dis;

          double cos_theta = apx * vecx + apy * vecy + apz * vecz;
          double theta = acos(cos_theta);

          double antpos_x = dis * cos(theta);

          cout << gname << " " << antpos_x << " -1000 -1000 " << dis << endl;
          exit(-1);

        }
      } else {
        cout << gname << " -1000 -1000 -1000 -1000" << endl;
      }


    } else {
      cout << gname << " -1000 -1000 -1000 -1000" << endl;
    }

    return 0;
  }


  //  cerr << tid << endl;

  ifstream clng;

  ifstream lng2;
  int cnt = 0;

  if (tid == 0) {
    plng.open(plngfile.c_str(), ios::in);
    clng.open(clngfile.c_str(), ios::in);
    while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div, clng >> t2 >> pid2 >> cid2 >> x2 >> y2 >> z2 >> name2) {
      if (!strcmp(name.c_str(), cellx.c_str())) {
	x3 = x2;
	y3 = y2;
	z3 = z2;
      }
    }
    plng.close();
    clng.close();
    cout << gname << " " << x3 << " " << y3 << " " << z3 << " ";
  } else {
    plng.open(plngfile.c_str(), ios::in);
    clng.open(clngfile.c_str(), ios::in);

    while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div, clng >> t2 >> pid2 >> cid2 >> x2 >> y2 >> z2 >> name2) {

      if (tid == t && (!strcmp(name.c_str(), celly.c_str()) | !strcmp(name.c_str(), cellz.c_str()))) {
	if (cnt == 0) {
	  xx01 = x2;
	  yy01 = y2;
	  zz01 = z2;
	  cnt++;
	} else if (cnt == 1) {
	  xx02 = x2;
	  yy02 = y2;
	  zz02 = z2;
	  cnt++;
	} else {
	  exit(-1);
	}
      }
    }
    plng.close();
    clng.close();

    x3 = (xx01 + xx02) / 2.0;
    y3 = (yy01 + yy02) / 2.0;
    z3 = (zz01 + zz02) / 2.0;
    cout << gname << " " << x3 << " " << y3 << " " << z3 << " ";
  }

  double dis = sqrt(x3 * x3 + y3 * y3 + z3 * z3);
  cout << dis << endl;

  return 0;
}
