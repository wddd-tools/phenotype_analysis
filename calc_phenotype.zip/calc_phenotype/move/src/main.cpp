#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
  string name1 = argv[1];
  string plngfile = argv[2];
  string clngfile = argv[3];
  string cell1 = argv[4];
  string cell2 = argv[5];
  string cell3 = argv[6];

  int t, pid, cid;
  double x, y, z, sp, vol;
  string name, div;
  double tmp_x, tmp_y, tmp_z;
  int sflag = 0;
  double d = 0.0;
  int ff = 0, fff = 0;

  int t2, pid2, cid2;
  double x2, y2, z2;
  string name2;

  ifstream plng;
  plng.open(plngfile.c_str(), ios::in);
  ifstream clng;
  clng.open(clngfile.c_str(), ios::in);
  while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sp >> vol >> div, clng >> t2 >> pid2 >> cid2 >> x2 >> y2 >> z2 >> name2) {
    if (!strcmp(name.c_str(), cell1.c_str()) && !strcmp(div.c_str(), "N") && sflag == 0) {
      tmp_x = x2;
      tmp_y = y2;
      tmp_z = z2;
      sflag = 1;
      ff = 1;
    } else if (!strcmp(name.c_str(), cell1.c_str()) && !strcmp(div.c_str(), "N") && sflag == 1) {
      double tmp_d = sqrt((x2 - tmp_x) * (x2 - tmp_x) + (y2 - tmp_y) * (y2 - tmp_y) + (z2 - tmp_z) * (z2 - tmp_z));
      d = d + tmp_d;
      tmp_x = x2;
      tmp_y = y2;
      tmp_z = z2;
      ff = 1;
    } else if (!strcmp(name.c_str(), cell1.c_str()) && !strcmp(div.c_str(), "D") && ff == 1) {
      fff = 1;
    } else if (!strcmp(name.c_str(), cell2.c_str())) {
      fff = 1;
    } else if (!strcmp(name.c_str(), cell3.c_str())) {
      fff = 1;
    }
  }
  plng.close();


  if (fff == 1) {
    if (d != 0) {
      cout << name1 << " " << d << endl;
    } else {    // kaku ga maruku naranai phenotype
      cout << name1 << " -1000" << endl; 
    }
  } else {
    cout << name1 << " -1000" << endl;
  }
  //    cout << name1 << "\t" << d << endl;

    return 0;
}
