#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
  string gname = argv[1];
  string nlngconvfile = argv[2];

  int t, pid, cid;
  double x, y, z, s, vol;
  string name, div;

  double sab = -1000, sp1 = -1000, saba = -1000, sabp = -1000, sems = -1000, sp2 = -1000;
  double vab = -1000, vp1 = -1000, vaba = -1000, vabp = -1000, vems = -1000, vp2 = -1000;

  ifstream lng;
  lng.open(nlngconvfile.c_str());
  if (!lng) {
    cerr << "cannot open nlngconvfile" << endl;
    exit(-1);
  } else {
    while (lng >> t >> pid >> cid >> x >> y >> z >> name >> s >> vol >> div) {
      if (!strcmp(name.c_str(), "AB")) {
	if (s > sab) {
	  sab = s;
	  vab = vol * 0.1015 * 0.1015 * 0.1015;
	}
      }
      if (!strcmp(name.c_str(), "P1")) {
	if (s > sp1) {
	  sp1 = s;
	  vp1 = vol * 0.1015 * 0.1015 * 0.1015;
	}
      }
      if (!strcmp(name.c_str(), "ABa")) {
	if (s > saba) {
	  saba = s;
	  vaba = vol * 0.1015 * 0.1015 * 0.1015;
	}
      }
      if (!strcmp(name.c_str(), "ABp")) {
	if (s > sabp) {
	  sabp = s;
	  vabp = vol * 0.1015 * 0.1015 * 0.1015;
	}
      }
      if (!strcmp(name.c_str(), "EMS")) {
	if (s > sems) {
	  sems = s;
	  vems = vol * 0.1015 * 0.1015 * 0.1015;
	}
      }
      if (!strcmp(name.c_str(), "P2")) {
	if (s > sp2) {
	  sp2 = s;
	  vp2 = vol * 0.1015 * 0.1015 * 0.1015;
	}
      }
    }
  }

  cout << gname << " " << sab << " " << sp1 << " " << saba << " " << sabp << " " << sems << " " << sp2 << " " << vab << " " << vp1 << " " << vaba << " " << vabp << " " << vems << " " << vp2 << " " << vab / vp1 << " ";

  if (vaba != -1000 && vab != -1000) {
    cout << vaba / vab << " ";
  } else {
    cout << "-1000 ";
  }

  if (vabp != -1000 && vab != -1000) {
    cout << vabp / vab << " ";
  } else {
    cout << "-1000 ";
  }

  if (vaba != -1000 && vabp != -1000) {
    cout << vaba / vabp << " ";
  } else {
    cout << "-1000 ";
  }

  if (vems != -1000 && vp1 != -1000) {
    cout << vems / vp1 << " ";
  } else {
    cout << "-1000 ";
  }

  if (vp2 != -1000 && vp1 != -1000) {
    cout << vp2 / vp1 << " ";
  } else {
    cout << "-1000 ";
  }

  if (vems != -1000 && vp2 != -1000) {
    cout << vems / vp2 << endl;
  } else {
    cout << "-1000" << endl;
  }

  return 0;
}
