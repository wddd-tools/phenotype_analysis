#define PI 3.14159265

#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <list>
#include <fstream>
using namespace std;

int main(int argc, char* argv[])
{
  string gname = argv[1];
  string lngfile = argv[2];

  list<int> tt;
  tt.clear();
  int t, pid, cid;
  double x, y, z, sph, vol;
  string name, div;
  int naba = 0, nabp = 0, nems = 0, np2 = 0;
  ifstream lng;
  lng.open(lngfile.c_str());
  if (!lng) {
//    cerr << "cannot open lng file" << endl;
    cout << gname << " -1000 -1000 -1000 -1000 -1000 -1000 -1000 -1000 -1000 -1000 -1000 -1000" << endl;
    exit(-1);
  } else {
    while (lng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div) {
      if (!strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "N")) {
	if (nabp == 1 && nems == 1 && np2 == 1) {
	  tt.push_back(t);
	}
	naba = 1;
      } else if (!strcmp(name.c_str(), "ABp") && !strcmp(div.c_str(), "N")) {
	if (naba == 1 && nems == 1 && np2 == 1) {
	  tt.push_back(t);
	}
	nabp = 1;
      } else if (!strcmp(name.c_str(), "EMS") && !strcmp(div.c_str(), "N")) {
	if (naba == 1 && nabp == 1 && np2 == 1) {
	  tt.push_back(t);
	}
	nems = 1;
      } else if (!strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "N")) {
	if (naba == 1 && nabp == 1 && nems == 1) {
	  tt.push_back(t);
	}
	np2 = 1;
      } else if (!strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "D")) {
	naba = 0;
      } else if (!strcmp(name.c_str(), "ABp") && !strcmp(div.c_str(), "D")) {
	nabp = 0;
      } else if (!strcmp(name.c_str(), "EMS") && !strcmp(div.c_str(), "D")) {
	nems = 0;
      } else if (!strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "D")) {
	np2 = 0;
      } else if (!strcmp(name.c_str(), "ABal")) {
	naba = 0;
      } else if (!strcmp(name.c_str(), "ABar")) {
	naba = 0;
      } else if (!strcmp(name.c_str(), "ABpl")) {
	nabp = 0;
      } else if (!strcmp(name.c_str(), "ABpr")) {
	nabp = 0;
      } else if (!strcmp(name.c_str(), "E")) {
	nems = 0;
      } else if (!strcmp(name.c_str(), "MS")) {
	nems = 0;
      } else if (!strcmp(name.c_str(), "C")) {
	np2 = 0;
      } else if (!strcmp(name.c_str(), "P3")) {
	np2 = 0;
      }
    }
  }

  if (tt.size() == 0) {
    cout << gname << " -1000 -1000 -1000 -1000 -1000 -1000 -1000 -1000 -1000 -1000 -1000 -1000" << endl;
    exit(0);
  }

  int ttt = 0;
  list<int>::iterator p;
  for (p = tt.begin(); p != tt.end(); p++) {
    ttt = ttt + (*p);
  }

  ttt = ttt / tt.size();

  lng.close();

  double abax = 0.0, abay = 0.0, abaz = 0.0;
  double abpx = 0.0, abpy = 0.0, abpz = 0.0;
  double emsx = 0.0, emsy = 0.0, emsz = 0.0;
  double p2x = 0.0, p2y = 0.0, p2z = 0.0;

  ifstream lng2;
  lng2.open(lngfile.c_str());
  if (!lng2) {
    cerr << "cannot open lng file" << endl;
    exit(-1);
  } else {
    while (lng2 >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div) {
      if (t == ttt) {
	if (!strcmp(name.c_str(), "ABa")) {
	  abax = x;
	  abay = y;
	  abaz = z;
	} else if (!strcmp(name.c_str(), "ABp")) {
	  abpx = x;
	  abpy = y;
	  abpz = z;
	} else if (!strcmp(name.c_str(), "EMS")) {
	  emsx = x;
	  emsy = y;
	  emsz = z;
	} else if (!strcmp(name.c_str(), "P2")) {
	  p2x = x;
	  p2y = y;
	  p2z = z;
	}
      }
    }
  }

  double x1, y1, z1;
  double x2, y2, z2;
  double x3, y3, z3;
  double x4, y4, z4;
  double x5, y5, z5;
  double x6, y6, z6;
  double d = 0.0;

  x1 = abpx - abax;
  y1 = abpy - abay;
  z1 = abpz - abaz;
  d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
  x1 = x1 / d;
  y1 = y1 / d;
  z1 = z1 / d;

  x2 = emsx - abax;
  y2 = emsy - abay;
  z2 = emsz - abaz;
  d = sqrt(x2 * x2 + y2 * y2 + z2 * z2);
  x2 = x2 / d;
  y2 = y2 / d;
  z2 = z2 / d;

  x3 = abpx - p2x;
  y3 = abpy - p2y;
  z3 = abpz - p2z;
  d = sqrt(x3 * x3 + y3 * y3 + z3 * z3);
  x3 = x3 / d;
  y3 = y3 / d;
  z3 = z3 / d;

  x4 = emsx - p2x;
  y4 = emsy - p2y;
  z4 = emsz - p2z;
  d = sqrt(x4 * x4 + y4 * y4 + z4 * z4);
  x4 = x4 / d;
  y4 = y4 / d;
  z4 = z4 / d;

  x5 = p2x - abax;
  y5 = p2y - abay;
  z5 = p2z - abaz;
  d = sqrt(x5 * x5 + y5 * y5 + z5 * z5);
  x5 = x5 / d;
  y5 = y5 / d;
  z5 = z5 / d;

  x6 = emsx - abpx;
  y6 = emsy - abpy;
  z6 = emsz - abpz;
  d = sqrt(x6 * x6 + y6 * y6 + z6 * z6);
  x6 = x6 / d;
  y6 = y6 / d;
  z6 = z6 / d;

  double a1 = acos(x1 * x5 + y1 * y5 + z1 * z5) / PI * 180.0;
  double a2 = acos(x2 * x5 + y2 * y5 + z2 * z5) / PI * 180.0;
  double a3 = acos(x1 * x2 + y1 * y2 + z1 * z2) / PI * 180.0;
  double a4 = acos(- x1 * x6 - y1 * y6 - z1 * z6) / PI * 180.0;
  double a5 = acos(- x3 * x6 - y3 * y6 - z3 * z6) / PI * 180.0;
  double a6 = acos(x1 * x3 + y1 * y3 + z1 * z3) / PI * 180.0;
  double a7 = acos(- x3 * x5 - y3 * y5 - z3 * z5) / PI * 180.0;
  double a8 = acos(- x4 * x5 - y4 * y5 - z4 * z5) / PI * 180.0;
  double a9 = acos(x3 * x4 + y3 * y4 + z3 * z4) / PI * 180.0;
  double a10 = acos(x2 * x6 + y2 * y6 + z2 * z6) / PI * 180.0;
  double a11 = acos(x4 * x6 + y4 * y6 + z4 * z6) / PI * 180.0;
  double a12 = acos(x2 * x4 + y2 * y4 + z2 * z4) / PI * 180.0;

  cout << gname << " " << a1 << " " << a2 << " " << a3 << " " << a4 << " " << a5 << " " << a6 << " " << a7 << " " << a8 << " " << a9 << " " << a10 << " " << a11 << " " << a12 << endl;

  return 0;
}
