#include <iostream>
#include <fstream>
#include <cstring>
#include <list>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
    string name1 = argv[1];
    string lngfile = argv[2];

    ifstream lng;
    lng.open(lngfile.c_str());
    list<int> tt;
    int abf = 0, p1f = 0;
    int t, pid, cid;
    double x, y, z, sp, vol;
    string name, div;
    while (lng >> t >> pid >> cid >> x >> y >> z >> name >> sp >> vol >> div) {
        if (!strcmp(name.c_str(), "AB") && !strcmp(div.c_str(), "N")) {
            abf = 1;
            if (p1f == 1) {
                int t1 = t;
                tt.push_back(t1);
                p1f = 0;
                abf = 0;
            }
        } else if (!strcmp(name.c_str(), "P1") && !strcmp(div.c_str(), "N")) {
            p1f = 1;
            if (abf == 1) {
                int t2 = t;
                tt.push_back(t2);
                abf = 0;
                p1f = 0;
            }
        }
    }

//    list<int>::iterator p;
//    for (p = tt.begin(); p != tt.end(); p++) {
//        cout << (*p) << " ";
//    }
//    cout << endl;

    list<double> dd;
    list<int>::iterator p;
    ifstream lng2;
    lng2.open(lngfile.c_str());
    int flag = 0;
    while (lng2 >> t >> pid >> cid >> x >> y >> z >> name >> sp >> vol >> div) {
        for (p = tt.begin(); p != tt.end(); p++) {
            if ((*p) == t) {
                flag = 1;
            }
        }

        if (flag == 1) {
            double x1 = x;
            double y1 = y;
            double z1 = z;
            lng2 >> t >> pid >> cid >> x >> y >> z >> name >> sp >> vol >> div;
            double x2 = x;
            double y2 = y;
            double z2 = z;

            double dis = sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) + (z1 - z2) * (z1 - z2));
            dd.push_back(dis);
        }

        flag = 0;
    }

    double td = 0.0;
    list<double>::iterator r;
    for (r = dd.begin(); r != dd.end(); r++) {
        td = td + (*r);
    }

    if (dd.size() != 0) {
      td = td / (double) dd.size();
      cout << name1 << " " << td << endl;
    } else {
      cout << name1 << " -1000" << endl;
    }

    //    td = td / (double) dd.size();

    //    cout << name1 << "\t" << td << endl;

    return 0;
}
