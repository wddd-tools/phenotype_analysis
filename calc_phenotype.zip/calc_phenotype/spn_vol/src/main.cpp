#include <iostream>
#include <cstring>
#include <fstream>
#include <cstdlib>
using namespace std;

int main(int argc, char* argv[])
{
  string name1 = argv[1];
  string lngfile = argv[2];
  string cell = argv[3];

  ifstream lng;
  lng.open(lngfile.c_str(), ios::in);
  if (!lng) {
    cout << "not found" << endl;
    exit(-1);
  }

  int t, pid, cid;
  double x, y, z, sp, vol;
  string name, div;

  int flag = 0;
  double tvol = -1000.0;
  while (lng >> t >> pid >> cid >> x >> y >> z >> name >> sp >> vol >> div) {
    if (!strcmp(name.c_str(), cell.c_str()) && !strcmp(div.c_str(), "D") && flag == 1) {
      tvol = vol;
      flag = 2;
    } else if (!strcmp(name.c_str(), cell.c_str()) && !strcmp(div.c_str(), "N")) {
      tvol = vol;
      flag = 1;
    }
  }

  if (flag == 2) {
    cout << name1 << " " << tvol * 0.1015 * 0.1015 * 0.1015 << endl;
  } else {
    cout << name1 << " " << "-1000" << endl;
  }

  return 0;
}
