#define PI 3.14159265358979

#include <iostream>
#include <fstream>
#include <cstring>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
  string infile = argv[1];
  ifstream in;
  in.open(infile.c_str());

  string gname;
  double x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  double y1, y2, y3, y4, y5, y6, y7, y8, y9, y10, y11, y12;
  double z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12;
  double d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12;
  while (in >> gname >> x12 >> y12 >> z12 >> d12 >> x1 >> y1 >> z1 >> d1 >> x2 >> y2 >> z2 >> d2 >> x3 >> y3 >> z3 >> d3 >> x4 >> y4 >> z4 >> d4 >> x5 >> y5 >> z5 >> d5 >> x6 >> y6 >> z6 >> d6 >> x7 >> y7 >> z7 >> d7 >> x8 >> y8 >> z8 >> d8 >> x9 >> y9 >> z9 >> d9 >> x10 >> y10 >> z10 >> d10 >> x11 >> y11 >> z11 >> d11) {
    if (x8 == -1000 | x9 == -1000 | x10 == -1000 | x11 == -1000) {
      cout << gname << "\t-1000\t-1000" << endl;
      continue;
    }

    // 8, 9, 10, 11
    // ABa -> ABp
    double x12 = x9 - x8;
    double y12 = y9 - y8;
    double z12 = z9 - z8;
    double x13 = x12 / sqrt(x12 * x12 + y12 * y12 + z12 * z12);
    double y13 = y12 / sqrt(x12 * x12 + y12 * y12 + z12 * z12);
    double z13 = z12 / sqrt(x12 * x12 + y12 * y12 + z12 * z12);

    // ABp -> P2
    double x14 = x11 - x9;
    double y14 = y11 - y9;
    double z14 = z11 - z9;
    double x15 = x14 / sqrt(x14 * x14 + y14 * y14 + z14 * z14);
    double y15 = y14 / sqrt(x14 * x14 + y14 * y14 + z14 * z14);
    double z15 = z14 / sqrt(x14 * x14 + y14 * y14 + z14 * z14);

    // ABa -> EMS
    double x16 = x10 - x8;
    double y16 = y10 - y8;
    double z16 = z10 - z8;
    double x17 = x16 / sqrt(x16 * x16 + y16 * y16 + z16 * z16);
    double y17 = y16 / sqrt(x16 * x16 + y16 * y16 + z16 * z16);
    double z17 = z16 / sqrt(x16 * x16 + y16 * y16 + z16 * z16);

    // EMS -> P2
    double x18 = x11 - x10;
    double y18 = y11 - y10;
    double z18 = z11 - z10;
    double x19 = x18 / sqrt(x18 * x18 + y18 * y18 + z18 * z18);
    double y19 = y18 / sqrt(x18 * x18 + y18 * y18 + z18 * z18);
    double z19 = z18 / sqrt(x18 * x18 + y18 * y18 + z18 * z18);

    // First (1)
    // ABa-ABp-P2 housen
    double x20 = y13 * z15 - z13 * y15;
    double y20 = z13 * x15 - x13 * z15;
    double z20 = x13 * y15 - y13 * x15;

    double x24 = x20 / sqrt(x20 * x20 + y20 * y20 + z20 * z20);
    double y24 = y20 / sqrt(x20 * x20 + y20 * y20 + z20 * z20);
    double z24 = z20 / sqrt(x20 * x20 + y20 * y20 + z20 * z20);

    // ABa-EMS-P2 housen
    double x21 = y17 * z19 - z17 * y19;
    double y21 = z17 * x19 - x17 * z19;
    double z21 = x17 * y19 - y17 * x19;

    double x25 = x21 / sqrt(x21 * x21 + y21 * y21 + z21 * z21);
    double y25 = y21 / sqrt(x21 * x21 + y21 * y21 + z21 * z21);
    double z25 = z21 / sqrt(x21 * x21 + y21 * y21 + z21 * z21);

    double theta1 = acos(x24 * x25 + y24 * y25 + z24 * z25) / PI * 180.0;
    //    cerr << theta1 << endl;

    //    cerr << x24 << "\t" << y24 << "\t" << z24 << "\t" << x25 << "\t" << y25 << "\t" << z25 << endl;
    double gaisekix01 = y24 * z25 - z24 * y25;
    double gaisekiy01 = z24 * x25 - x24 * z25;
    double gaisekiz01 = x24 * y25 - y24 * x25;

    //    cerr << gaisekix << "\t" << gaisekiy << "\t" << gaisekiz << endl;

    cout << gname << "\t";

    if (gaisekix01 < 0.0) {
      cout << 180.0 - theta1 << "\t";
    } else {
      cout << - (180.0 - theta1) << "\t";
    }


    //    if (theta1 > 180.0) {
    //      theta1 = 360.0 - theta1;
    //    }


    // Second (2)
    // ABa-ABp-EMS housen
    double x22 = y13 * z17 - z13 * y17;
    double y22 = z13 * x17 - x13 * z17;
    double z22 = x13 * y17 - y13 * x17;

    double x26 = x22 / sqrt(x22 * x22 + y22 * y22 + z22 * z22);
    double y26 = y22 / sqrt(x22 * x22 + y22 * y22 + z22 * z22);
    double z26 = z22 / sqrt(x22 * x22 + y22 * y22 + z22 * z22);

    // ABp-EMS-P2 housen
    double x23 = y15 * z19 - z15 * y19;
    double y23 = z15 * x19 - x15 * z19;
    double z23 = x15 * y19 - y15 * x19;

    double x27 = x23 / sqrt(x23 * x23 + y23 * y23 + z23 * z23);
    double y27 = y23 / sqrt(x23 * x23 + y23 * y23 + z23 * z23);
    double z27 = z23 / sqrt(x23 * x23 + y23 * y23 + z23 * z23);

    double theta2 = acos(x26 * x27 + y26 * y27 + z26 * z27) / PI * 180.0;
    //    cerr << theta2 << endl;

    //    cerr << x26 << "\t" << y26 << "\t" << z26 << "\t" << x27 << "\t" << y27 << "\t" << z27 << endl;

    //    if (theta2 > 180.0) {
    //      theta2 = 360.0 - theta2;
    //    }

    //    cout << gname << "\t" << 180.0 - theta1 << "\t" << 180.0 - theta2 << endl;

    double gaisekix02 = y26 * z27 - z26 * y27;
    double gaisekiy02 = z26 * x27 - x26 * z27;
    double gaisekiz02 = x26 * y27 - y26 * x27;

    if (gaisekiy02 < 0.0) {
      cout << 180 - theta2 << endl;
    } else {
      cout << - (180 - theta2) << endl;
    }

  } 

  return 0;
}
