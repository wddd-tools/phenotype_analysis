#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include "eigenVec.h"
#include "ccImg.h"
#include "ccConv.h"
#include "imageIO.h"
using namespace std;

int main(int argc, char* argv[])
{
    string name1 = argv[1];
    string lngfile = argv[2];
    string roifile = argv[3];
    string cell = argv[4];

    ifstream lng;
    lng.open(lngfile.c_str());
    if (!lng) {
      cout << name1 << " -1000 -1000 -1000" << endl;
      exit(-1);
    }

    int t, pid, cid;
    double x, y, z, sp, vol;
    string name, div;

    list<int> tt;
    int p1f = 0, abf = 0, p0n = 0;
    int t1 = -1;
    int nab = 0, np1 = 0;
    int ff = 0;
    int cid1 = 0;

    while (lng >> t >> pid >> cid >> x >> y >> z >> name >> sp >> vol >> div) {
      //        if (!strcmp(name.c_str(), "P0") && !strcmp(div.c_str(), "D")) {
      //            t1 = t;
      //	    break;
      //        }
      if (!strcmp(name.c_str(), cell.c_str()) && !strcmp(div.c_str(), "D") && ff == 1) {
	t1 = t;
	cid1 = cid;
	break;
      } else if (!strcmp(name.c_str(), cell.c_str()) && !strcmp(div.c_str(), "N")) {
	ff = 1;
      }
    }

    if (t1 == -1) {
      cout << name1 << " -1000 -1000 -1000" << endl;
      exit(-1);
    }

//    cerr << t1 << endl;

    tt.push_back(t1);
//    tt.unique();


//    last_p0n = last_p0n + 8;

//    cerr << last_p0n << endl;

    eigenVec eiv;
    ccImg ci;
    ccConv ccc;
    imageIO imgIO;
    list<zimage> zimgl;
    int tmp_t = 0;

    ifstream roi;
    roi.open(roifile.c_str());
    string f;
    int sx, sy, sz, on = 0;
    string crackcode;
    zimage *tmp_zimg;

    list<xyz> xyzl;

    while (roi >> f) {
        if (!strcmp(f.c_str(), "G")) {
            roi >> t >> pid >> cid >> x >> y >> z;

            if (zimgl.size() != 0 && tmp_t != t) {
                xyz xyz0;
                xyz xyz1;
                xyz xyz2;

                eiv.out2(xyz0, xyz1, xyz2, zimgl);
//                cerr << zimgl.size() << endl;
                zimgl.clear();

                // processing
//                cout << t - 1 << "\t";
                cout << name1 << "\t";
                ccc.rotate(xyz0, xyz1, xyz2, xyzl);
                xyzl.clear();
            }


            list<int>::iterator u;
            on = 0;
            for (u = tt.begin(); u != tt.end(); u++) {
                if ((*u) == t && cid == cid1) {
                    on = 1;
//                    cerr << "on " << t << endl;
                }
            }

        } else if (!strcmp(f.c_str(), "R")) {
            roi >> sx >> sy >> sz >> t >> crackcode;
            if (on == 1) {
                image tmp_img;
                tmp_t = t;
                tmp_img.setSize(600, 600);
                ci.convert(tmp_img, sx, sy, crackcode);
                ccc.convert(xyzl, sx, sy, sz, crackcode);

                tmp_zimg = new zimage();
                tmp_zimg->set(sz, tmp_img);
                zimgl.push_back(*tmp_zimg);
                delete tmp_zimg;
            }
        }
    }

    if (zimgl.size() != 0) {
      xyz xyz0;
      xyz xyz1;
      xyz xyz2;

      eiv.out2(xyz0, xyz1, xyz2, zimgl);
      zimgl.clear();

                // processing
//                cout << t - 1 << "\t";
      cout << name1 << "\t";
      ccc.rotate(xyz0, xyz1, xyz2, xyzl);
      xyzl.clear();
    }

/*
    xyz xyz0;
    xyz xyz1;
    xyz xyz2;

    eiv.out2(xyz0, xyz1, xyz2, zimgl);
    zimgl.clear();

    // processing
    ccc.rotate(xyz0, xyz1, xyz2, xyzl);
*/
    return 0;
}
