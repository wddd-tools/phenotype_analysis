#include "eigenVec.h"
using namespace std;

eigenVec::eigenVec()
{

}

eigenVec::~eigenVec()
{

}

void eigenVec::out(list<zimage> zimgl)
{
    int orgx = 0, orgy = 0, orgz = 0;
    int count = 0;
    int total = 0;
//    int x[600], y[600], z[600];

//    for (int i = 0; i < 600; i++) {
//        x[i] = 0;
//        y[i] = 0;
//        z[i] = 0;
//    }

    list<zimage>::iterator r;
    for (r = zimgl.begin(); r != zimgl.end(); r++) {
        for (int i = 0; i < (*r).getImg().getX(); i++) {
            for (int j = 0; j < (*r).getImg().getY(); j++) {
                if ((*r).getImg().getPixel(i, j) == MININTENSITY) {
                    orgx = orgx + i;
                    orgy = orgy + j;
                    orgz = orgz + (*r).getZ();
//                    x[i]++;
//                    y[j]++;
//                    z[(*r).getZ()]++;
                    total++;
                }
            }
        }
    }

    double gx, gy, gz;
    gx = (double) orgx * 0.1015 / (double) total;
    gy = (double) orgy * 0.1015 / (double) total;
    gz = (double) orgz * 0.5016 / (double) total;

    double ixx = 0.0, ixy = 0.0, izx = 0.0, iyy = 0.0, iyz = 0.0, izz = 0.0;

    for (r = zimgl.begin(); r != zimgl.end(); r++) {
        for (int i = 0; i < (*r).getImg().getX(); i++) {
            for (int j = 0; j < (*r).getImg().getY(); j++) {
                if ((*r).getImg().getPixel(i, j) == MININTENSITY) {

                    ixx = ixx + (0.1015 * i - gx) * (0.1015 * i - gx);
                    ixy = ixy + (0.1015 * i - gx) * (0.1015 * j - gy);
                    iyy = iyy + (0.1015 * j - gy) * (0.1015 * j - gy);
                    iyz = iyz + (0.1015 * j - gy) * (0.5016 * (*r).getZ() - gz);
                    izz = izz + (0.5016 * (*r).getZ() - gz) * (0.5016 * (*r).getZ() - gz);
                    izx = izx + (0.5016 * (*r).getZ() - gz) * (0.1015 * i -gx);

                }
            }
        }
    }

//    total = total * 21 * 21 * 100;

    ixx = ixx / (double) total;
    ixy = ixy / (double) total;
    iyy = iyy / (double) total;
    iyz = iyz / (double) total;
    izz = izz / (double) total;
    izx = izx / (double) total;


    int ndim = 3;
    double a[NDIM][NDIM], ev[NDIM], ev1[NDIM], evec[NDIM][NDIM];
    ev_jacobi evj;

    a[1][1] = ixx;
    a[1][2] = ixy;
    a[1][3] = izx;
    a[2][1] = ixy;
    a[2][2] = iyy;
    a[2][3] = iyz;
    a[3][1] = izx;
    a[3][2] = iyz;
    a[3][3] = izz;

    evj.set_matrix(ndim, a, 1, 1);
    evj.get_eigenvalue(ev);
    exact_eigenvalue(ndim, ev1);

//    cout << "       (1) numerical        (2) exact       (3) (1)-(2)/|(2)|" << endl;
//    for (int i = 1; i <= ndim; ++i)
//        cout << "value: " << ev[i] << " " << ev1[i] << " " << (ev[i]-ev1[i])/fabs(ev1[i]) << endl;

    evj.get_eigenvector(evec);

    check_eigenvector(ndim, a, ev, evec);

    evj.sort_eigenpair(0);
    evj.get_eigenvalue(ev);

    evj.get_eigenvector(evec);



    // set an eigen value corresponding to each eigen vector
    // eigen value ev[], eigen vector evec[][]

    double tmp;
    if (ev[1] < ev[2]) {
        tmp = ev[2];
        ev[2] = ev[1];
        ev[1] = tmp;
    }
    if (ev[1] < ev[3]) {
        tmp = ev[3];
        ev[3] = ev[1];
        ev[1] = tmp;
    }
    if (ev[2] < ev[3]) {
        tmp = ev[3];
        ev[3] = ev[2];
        ev[2] = tmp;
    }

    cout << ev[1] << endl;
//    cout << ev[1] << " " << ev[2] << " " << ev[3] << endl;

    for (int j = 1; j <= ndim; j++) {
        for (int i = 1; i <= ndim; i++) {
            double x1, x2, x3, y1, y2, y3, z1, z2, z3;
            x1 = ixx * evec[i][1] + ixy * evec[i][2] + izx * evec[i][3];
            x2 = ixy * evec[i][1] + iyy * evec[i][2] + iyz * evec[i][3];
            x3 = izx * evec[i][1] + iyz * evec[i][2] + izz * evec[i][3];
            y1 = ev[j] * evec[i][1];
            y2 = ev[j] * evec[i][2];
            y3 = ev[j] * evec[i][3];
            if (fabs(x1 - y1) < 0.001 && fabs(x2 - y2) < 0.001 && fabs(x3 - y3) < 0.001) {
//                cout << evec[i][1] << " " << evec[i][2] << " " << evec[i][3] << endl;
            }
        }
    }


    check_eigenvector(ndim, a, ev, evec);
}


void eigenVec::out2(xyz &xyz0, xyz &xyz1, xyz &xyz2, list<zimage> zimgl)
{
    int orgx = 0, orgy = 0, orgz = 0;
    int count = 0;
    int total = 0;
//    int x[600], y[600], z[600];

//    for (int i = 0; i < 600; i++) {
//        x[i] = 0;
//        y[i] = 0;
//        z[i] = 0;
//    }

    list<zimage>::iterator r;
    for (r = zimgl.begin(); r != zimgl.end(); r++) {
        for (int i = 0; i < (*r).getImg().getX(); i++) {
            for (int j = 0; j < (*r).getImg().getY(); j++) {
                if ((*r).getImg().getPixel(i, j) == MININTENSITY) {
                    orgx = orgx + i;
                    orgy = orgy + j;
                    orgz = orgz + (*r).getZ();
//                    x[i]++;
//                    y[j]++;
//                    z[(*r).getZ()]++;
                    total++;
                }
            }
        }
    }

    double gx, gy, gz;
    gx = (double) orgx * 0.1015 / (double) total;
    gy = (double) orgy * 0.1015 / (double) total;
    gz = (double) orgz * 0.5016 / (double) total;

    double ixx = 0.0, ixy = 0.0, izx = 0.0, iyy = 0.0, iyz = 0.0, izz = 0.0;

    for (r = zimgl.begin(); r != zimgl.end(); r++) {
        for (int i = 0; i < (*r).getImg().getX(); i++) {
            for (int j = 0; j < (*r).getImg().getY(); j++) {
                if ((*r).getImg().getPixel(i, j) == MININTENSITY) {

                    ixx = ixx + (0.1015 * i - gx) * (0.1015 * i - gx);
                    ixy = ixy + (0.1015 * i - gx) * (0.1015 * j - gy);
                    iyy = iyy + (0.1015 * j - gy) * (0.1015 * j - gy);
                    iyz = iyz + (0.1015 * j - gy) * (0.5016 * (*r).getZ() - gz);
                    izz = izz + (0.5016 * (*r).getZ() - gz) * (0.5016 * (*r).getZ() - gz);
                    izx = izx + (0.5016 * (*r).getZ() - gz) * (0.1015 * i -gx);

                }
            }
        }
    }

//    total = total * 21 * 21 * 100;

    ixx = ixx / (double) total;
    ixy = ixy / (double) total;
    iyy = iyy / (double) total;
    iyz = iyz / (double) total;
    izz = izz / (double) total;
    izx = izx / (double) total;



    int ndim = 3;
    double a[NDIM][NDIM], ev[NDIM], ev1[NDIM], evec[NDIM][NDIM];
    ev_jacobi evj;

    a[1][1] = ixx;
    a[1][2] = ixy;
    a[1][3] = izx;
    a[2][1] = ixy;
    a[2][2] = iyy;
    a[2][3] = iyz;
    a[3][1] = izx;
    a[3][2] = iyz;
    a[3][3] = izz;

    evj.set_matrix(ndim, a, 1, 1);
    evj.get_eigenvalue(ev);
    exact_eigenvalue(ndim, ev1);

    evj.get_eigenvector(evec);

    check_eigenvector(ndim, a, ev, evec);

    evj.sort_eigenpair(0);
    evj.get_eigenvalue(ev);

    evj.get_eigenvector(evec);



    // set an eigen value corresponding to each eigen vector
    // eigen value ev[], eigen vector evec[][]

    double tmp;
    if (ev[1] < ev[2]) {
        tmp = ev[2];
        ev[2] = ev[1];
        ev[1] = tmp;
    }
    if (ev[1] < ev[3]) {
        tmp = ev[3];
        ev[3] = ev[1];
        ev[1] = tmp;
    }
    if (ev[2] < ev[3]) {
        tmp = ev[3];
        ev[3] = ev[2];
        ev[2] = tmp;
    }

//    cout << ev[1] << endl;
//    cout << ev[1] << " " << ev[2] << " " << ev[3] << endl;

    for (int j = 1; j <= ndim; j++) {
        for (int i = 1; i <= ndim; i++) {
            double x1, x2, x3, y1, y2, y3, z1, z2, z3;
            x1 = ixx * evec[i][1] + ixy * evec[i][2] + izx * evec[i][3];
            x2 = ixy * evec[i][1] + iyy * evec[i][2] + iyz * evec[i][3];
            x3 = izx * evec[i][1] + iyz * evec[i][2] + izz * evec[i][3];
            y1 = ev[j] * evec[i][1];
            y2 = ev[j] * evec[i][2];
            y3 = ev[j] * evec[i][3];
            if (fabs(x1 - y1) < 0.001 && fabs(x2 - y2) < 0.001 && fabs(x3 - y3) < 0.001) {
                if (j == 1) {
                    xyz0.set(evec[i][1], evec[i][2], evec[i][3]);
                } else if (j == 2) {
                    xyz1.set(evec[i][1], evec[i][2], evec[i][3]);
                } else if (j == 3) {
                    xyz2.set(evec[i][1], evec[i][2], evec[i][3]);
                }
//                cout << evec[i][1] << " " << evec[i][2] << " " << evec[i][3] << endl;
            }
        }
    }


    check_eigenvector(ndim, a, ev, evec);
}


void eigenVec::exact_eigenvalue(int ndim, double ev1[])
{
    double dt = M_PI / (2 * ndim + 1);
    for (int i = 1; i <= ndim; ++i)
        ev1[i] = 0.5 / (1.0 - cos((2 * i - 1) * dt));
}

void eigenVec::check_eigenvector(int ndim, double a[][NDIM], double ev[], double evec[][NDIM])
{
    for (int k = 1; k <= ndim; ++k) {
        double v[NDIM];
        for (int i = 1; i <= ndim; ++i) {
            double s = ev[k] * evec[k][i];
            for (int j = 1; j <= ndim; j++)
                s -= a[i][j] * evec[k][j];
            v[i] = s;
        }
        double vnorm = 0.0;
        for (int i = 1; i <= ndim; ++i)
            vnorm = v[i] * v[i];
        vnorm = sqrt(vnorm);
    }
}
