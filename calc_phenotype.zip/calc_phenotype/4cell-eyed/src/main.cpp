#include <iostream>
#include <fstream>
#include <cstring>
#include <list>
#include <cmath>
#include <cstdlib>
using namespace std;

int main(int argc, char* argv[])
{
    string name1 = argv[1];
    string lngfile = argv[2];
    string opfile = argv[3];

    list<double> abal;
    list<double> abpl;
    list<double> emsl;
    list<double> p2l;

    int ttt[4][360];
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 360; j++)
            ttt[i][j] = 0;  
            

    ifstream op;
    op.open(opfile.c_str());
    if (!op) {
      cout << name1 << " -1000 -1000" << endl;
      exit(0);
    }

    double opx, opy, opz;
    op >> opx >> opy >> opz;

    ifstream lng;
    lng.open(lngfile.c_str());
    int t, pid, cid;
    double x, y, z, sp, vol;
    string name, div;
    while (lng >> t >> pid >> cid >> x >> y >> z >> name >> sp >> vol >> div) {
        if (!strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "N")) {
            ttt[0][t] = 1;
        } else if (!strcmp(name.c_str(), "ABp") && !strcmp(div.c_str(), "N")) {
            ttt[1][t] = 1;
        } else if (!strcmp(name.c_str(), "EMS") && !strcmp(div.c_str(), "N")) {
            ttt[2][t] = 1;
        } else if (!strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "N")) {
            ttt[3][t] = 1;
        }
    }

    list<int> tt;
    list<int>::iterator p;

    for (int j = 0; j < 360; j++) {
        if (ttt[0][j] == 1 && ttt[1][j] == 1 && ttt[2][j] == 1 && ttt[3][j] == 1) {
            tt.push_back(j);
        }
    }

    ifstream lng2;
    double abax = 0.0, abay = 0.0, abaz = 0.0;
    double abpx = 0.0, abpy = 0.0, abpz = 0.0;
    double emsx = 0.0, emsy = 0.0, emsz = 0.0;
    double p2x = 0.0, p2y = 0.0, p2z = 0.0;
    lng2.open(lngfile.c_str());
    while (lng2 >> t >> pid >> cid >> x >> y >> z >> name >> sp >> vol >> div) {
        for (p = tt.begin(); p != tt.end(); p++) {
            if (t == (*p)) {
                if (!strcmp(name.c_str(), "ABa")) {
                    abax = abax + x;
                    abay = abay + y;
                    abaz = abaz + z;
                } else if (!strcmp(name.c_str(), "ABp")) {
                    abpx = abpx + x;
                    abpy = abpy + y;
                    abpz = abpz + z;
                } else if (!strcmp(name.c_str(), "EMS")) {
                    emsx = emsx + x;
                    emsy = emsy + y;
                    emsz = emsz + z;
                } else if (!strcmp(name.c_str(), "P2")) {
                    p2x = p2x + x;
                    p2y = p2y + y;
                    p2z = p2z + z;
                }
            }
        }
    }

    if (tt.size() == 0) {
      cout << name1 << " -1000 -1000" << endl;
        exit(1);
    }

    abax = abax / (double) tt.size();
    abay = abay / (double) tt.size();
    abaz = abaz / (double) tt.size();
    abpx = abpx / (double) tt.size();
    abpy = abpy / (double) tt.size();
    abpz = abpz / (double) tt.size();
    emsx = emsx / (double) tt.size();
    emsy = emsy / (double) tt.size();
    emsz = emsz / (double) tt.size();
    p2x = p2x / (double) tt.size();
    p2y = p2y / (double) tt.size();
    p2z = p2z / (double) tt.size();

    double dab = 0.0, dp1 = 0.0;

    if (abax != 0 && abay != 0 && abaz != 0 && abpx != 0 && abpy != 0 && abpz != 0) {
      dab = sqrt((abax - abpx) * (abax - abpx) + (abay - abpy) * (abay - abpy) + (abaz - abpz) * (abaz - abpz));
    } else {
      dab = -1000;
    }

    if (emsx != 0 && emsy != 0 && emsz != 0 && p2x != 0 && p2y != 0 && p2z != 0) {
      dp1 = sqrt((emsx - p2x) * (emsx - p2x) + (emsy - p2y) * (emsy - p2y) + (emsz - p2z) * (emsz - p2z));
    } else {
      dp1 = -1000;
    }

    cout << name1 << " " << dab << " " << dp1 << endl;


    return 0;
}
