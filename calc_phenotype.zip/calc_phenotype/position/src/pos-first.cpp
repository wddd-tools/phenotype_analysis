#include <iostream>
#include <cstring>
#include <fstream>
#include <cstdlib>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
  string gname = argv[1];
  string plngfile = argv[2];
  string clngfile = argv[3];


  double p0x = 0.0, p0y = 0.0, p0z = 0.0;
  double abx = 0.0, aby = 0.0, abz = 0.0;
  double p1x = 0.0, p1y = 0.0, p1z = 0.0;
  double abax = 0.0, abay = 0.0, abaz = 0.0;
  double abpx = 0.0, abpy = 0.0, abpz = 0.0;
  double emsx = 0.0, emsy = 0.0, emsz = 0.0;
  double p2x = 0.0, p2y = 0.0, p2z = 0.0;
  double abalx = 0.0, abaly = 0.0, abalz = 0.0;
  double abarx = 0.0, abary = 0.0, abarz = 0.0;
  double abplx = 0.0, abply = 0.0, abplz = 0.0;
  double abprx = 0.0, abpry = 0.0, abprz = 0.0;
  double ex = 0.0, ey = 0.0, ez = 0.0;
  double msx = 0.0, msy = 0.0, msz = 0.0;
  double cx = 0.0, cy = 0.0, cz = 0.0;
  double p3x = 0.0, p3y = 0.0, p3z = 0.0;
  int fp0 = 0, fab = 0, fp1 = 0.0, faba = 0, fabp = 0, fems = 0, fp2 = 0, fabal = 0, fabar = 0, fabpl = 0, fabpr = 0, fe = 0, fms = 0, fc = 0, fp3 = 0;


  int t, pid, cid;
  int t2, pid2, cid2;
  double x, y, z, x2, y2, z2, sph, vol;
  string name, div, name2;

  ifstream plng;
  plng.open(plngfile.c_str(), ios::in);
  ifstream clng;
  clng.open(clngfile.c_str(), ios::in);
  while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div, clng >> t2 >> pid2 >> cid2 >> x2 >> y2 >> z2 >> name2) {
    if (!strcmp(name.c_str(), "P0") && !strcmp(div.c_str(), "N") && fp0 == 0) {
      fp0 = 1;
      p0x = x2;
      p0y = y2;
      p0z = z2;
    } else if (!strcmp(name.c_str(), "AB") && !strcmp(div.c_str(), "N") && fab == 0) {
      fab = 1;
      abx = x2;
      aby = y2;
      abz = z2;
    } else if (!strcmp(name.c_str(), "P1") && !strcmp(div.c_str(), "N") && fp1 == 0) {
      fp1 = 1;
      p1x = x2;
      p1y = y2;
      p1z = z2;
    } else if (!strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "N") && faba == 0) {
      faba = 1;
      abax = x2;
      abay = y2;
      abaz = z2;
    } else if (!strcmp(name.c_str(), "ABp") && !strcmp(div.c_str(), "N") && fabp == 0) {
      fabp = 1;
      abpx = x2;
      abpy = y2;
      abpz = z2;
    } else if (!strcmp(name.c_str(), "EMS") && !strcmp(div.c_str(), "N") && fems == 0) {
      fems = 1;
      emsx = x2;
      emsy = y2;
      emsz = z2;
    } else if (!strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "N") && fp2 == 0) {
      fp2 = 1;
      p2x = x2;
      p2y = y2;
      p2z = z2;
    } else if (!strcmp(name.c_str(), "ABal") && !strcmp(div.c_str(), "N") && fabal == 0) {
      fabal = 1;
      abalx = x2;
      abaly = y2;
      abalz = z2;
    } else if (!strcmp(name.c_str(), "ABar") && !strcmp(div.c_str(), "N") && fabar == 0) {
      fabar = 1;
      abarx = x2;
      abary = y2;
      abarz = z2;
    } else if (!strcmp(name.c_str(), "ABpl") && !strcmp(div.c_str(), "N") && fabpl == 0) {
      fabpl = 1;
      abplx = x2;
      abply = y2;
      abplz = z2;
    } else if (!strcmp(name.c_str(), "ABpr") && !strcmp(div.c_str(), "N") && fabpr == 0) {
      fabpr = 1;
      abprx = x2;
      abpry = y2;
      abprz = z2;
    } else if (!strcmp(name.c_str(), "E") && !strcmp(div.c_str(), "N") && fe == 0) {
      fe = 1;
      ex = x2;
      ey = y2;
      ez = z2;
    } else if (!strcmp(name.c_str(), "MS") && !strcmp(div.c_str(), "N") && fms == 0) {
      fms = 1;
      msx = x2;
      msy = y2;
      msz = z2;
    } else if (!strcmp(name.c_str(), "C") && !strcmp(div.c_str(), "N") && fc == 0) {
      fc = 1;
      cx = x2;
      cy = y2;
      cz = z2;
    } else if (!strcmp(name.c_str(), "P3") && !strcmp(div.c_str(), "N") && fp3 == 0) {
      fp3 = 1;
      p3x = x2;
      p3y = y2;
      p3z = z2;
    }
  }

  cout << gname << " ";

  if (abx != 0 && aby != 0 && abz != 0) {
    cout << abx << " " << aby << " " << abz << " " << sqrt(abx * abx + aby * aby + abz * abz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (p1x != 0 && p1y != 0 && p1z != 0) {
    cout << p1x << " " << p1y << " " << p1z << " " << sqrt(p1x * p1x + p1y * p1y + p1z * p1z) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (abax != 0 && abay != 0 && abaz != 0) {
    cout << abax << " " << abay << " " << abaz << " " << sqrt(abax * abax + abay * abay + abaz * abaz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (abpx != 0 && abpy != 0 && abpz != 0) {
    cout << abpx << " " << abpy << " " << abpz << " " << sqrt(abpx * abpx + abpy * abpy + abpz * abpz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (emsx != 0 && emsy != 0 && emsz != 0) {
    cout << emsx << " " << emsy << " " << emsz << " " << sqrt(emsx * emsx + emsy * emsy + emsz * emsz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (p2x != 0 && p2y != 0 && p2z != 0) {
    cout << p2x << " " << p2y << " " << p2z << " " << sqrt(p2x * p2x + p2y * p2y + p2z * p2z) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (abalx != 0 && abaly != 0 && abalz != 0) {
    cout << abalx << " " << abaly << " " << abalz << " " << sqrt(abalx * abalx + abaly * abaly + abalz * abalz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (abarx != 0 && abary != 0 && abarz != 0) {
    cout << abarx << " " << abary << " " << abarz << " " << sqrt(abarx * abarx + abary * abary + abarz * abarz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (abplx != 0 && abply != 0 && abplz != 0) {
    cout << abplx << " " << abply << " " << abplz << " " << sqrt(abplx * abplx + abply * abply + abplz * abplz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (abprx != 0 && abpry != 0 && abprz != 0) {
    cout << abprx << " " << abpry << " " << abprz << " " << sqrt(abprx * abprx + abpry * abpry + abprz * abprz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (ex != 0 && ey != 0 && ez != 0) {
    cout << ex << " " << ey << " " << ez << " " << sqrt(ex * ex + ey * ey + ez * ez) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (msx != 0 && msy != 0 && msz != 0) {
    cout << msx << " " << msy << " " << msz << " " << sqrt(msx * msx + msy * msy + msz * msz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (cx != 0 && cy != 0 && cz != 0) {
    cout << cx << " " << cy << " " << cz << " " << sqrt(cx * cx + cy * cy + cz * cz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (p3x != 0 && p3y != 0 && p3z != 0) {
    cout << p3x << " " << p3y << " " << p3z << " " << sqrt(p3x * p3x + p3y * p3y + p3z * p3z) << endl;
  } else {
    cout << "-1000 -1000 -1000 -1000" << endl;
  }


  return 0;
}
