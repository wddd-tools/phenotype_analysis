#include <iostream>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
  string wtfile = argv[1];
  string rnaifile = argv[2];

  double mp0x, mabx, mp1x, mabax, mabpx, memsx, mp2x;
  double mp0y, maby, mp1y, mabay, mabpy, memsy, mp2y;
  double mp0z, mabz, mp1z, mabaz, mabpz, memsz, mp2z;
  double mp0d, mabd, mp1d, mabad, mabpd, memsd, mp2d;

  double sp0x, sabx, sp1x, sabax, sabpx, semsx, sp2x;
  double sp0y, saby, sp1y, sabay, sabpy, semsy, sp2y;
  double sp0z, sabz, sp1z, sabaz, sabpz, semsz, sp2z;
  double sp0d, sabd, sp1d, sabad, sabpd, semsd, sp2d;

  ifstream wt;
  wt.open(wtfile.c_str());
  if (!wt) {
    cerr << "cannot open wt file... " << endl;
    exit(-1);
  } else {
    wt >> mp0x >> mp0y >> mp0z >> mp0d >> mabx >> maby >> mabz >> mabd >> mp1x >> mp1y >> mp1z >> mp1d >> mabax >> mabay >> mabaz >> mabad >> mabpx >> mabpy >> mabpz >> mabpd >> memsx >> memsy >> memsz >> memsd >> mp2x >> mp2y >> mp2z >> mp2d;
    wt >> sp0x >> sp0y >> sp0z >> sp0d >> sabx >> saby >> sabz >> sabd >> sp1x >> sp1y >> sp1z >> sp1d >> sabax >> sabay >> sabaz >> sabad >> sabpx >> sabpy >> sabpz >> sabpd >> semsx >> semsy >> semsz >> semsd >> sp2x >> sp2y >> sp2z >> sp2d;
  }

  string gname;
  double p0x, abx, p1x, abax, abpx, emsx, p2x;
  double p0y, aby, p1y, abay, abpy, emsy, p2y;
  double p0z, abz, p1z, abaz, abpz, emsz, p2z;
  double p0d, abd, p1d, abad, abpd, emsd, p2d;

  ifstream rnai;
  rnai.open(rnaifile.c_str());
  if (!rnai) {
    cerr << "cannot open rnai file... " << endl;
    exit(-1);
  }

  while (rnai >> gname >> p0x >> p0y >> p0z >> p0d >> abx >> aby >> abz >> abd >> p1x >> p1y >> p1z >> p1d >> abax >> abay >> abaz >> abad >> abpx >> abpy >> abpz >> abpd >> emsx >> emsy >> emsz >> emsd >> p2x >> p2y >> p2z >> p2d) {
    cout << gname << "\t";

    if (p0x != -1000 && p0y != -1000 && p0z != -1000 && p0d != -1000) {
      cout << sqrt((p0x - mp0x) * (p0x - mp0x) + (p0y - mp0y) * (p0y - mp0y) + (p0z - mp0z) * (p0z - mp0z)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abx != -1000 && aby != -1000 && abz != -1000 && abd != -1000) {
      cout << sqrt((abx - mabx) * (abx - mabx) + (aby - maby) * (aby - maby) + (abz - mabz) * (abz - mabz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (p1x != -1000 && p1y != -1000 && p1z != -1000 && p1d != -1000) {
      cout << sqrt((p1x - mp1x) * (p1x - mp1x) + (p1y - mp1y) * (p1y - mp1y) + (p1z - mp1z) * (p1z - mp1z)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abax != -1000 && abay != -1000 && abaz != -1000 && abad != -1000) {
      cout << sqrt((abax - mabax) * (abax - mabax) + (abay - mabay) * (abay - mabay) + (abaz - mabaz) * (abaz - mabaz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abpx != -1000 && abpy != -1000 && abpz != -1000 && abpd != -1000) {
      cout << sqrt((abpx - mabpx) * (abpx - mabpx) + (abpy - mabpy) * (abpy - mabpy) + (abpz - mabpz) * (abpz - mabpz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (emsx != -1000 && emsy != -1000 && emsz != -1000 && emsd != -1000) {
      cout << sqrt((emsx - memsx) * (emsx - memsx) + (emsy - memsy) * (emsy - memsy) + (emsz - memsz) * (emsz - memsz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (p2x != -1000 && p2y != -1000 && p2z != -1000 && p2d != -1000) {
      cout << sqrt((p2x - mp2x) * (p2x - mp2x) + (p2y - mp2y) * (p2y - mp2y) + (p2z - mp2z) * (p2z - mp2z)) << endl;
    } else {
      cout << "-1000" << endl;
    }
  }

  return 0;
}
