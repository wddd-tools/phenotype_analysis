#include <iostream>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
  string wtfile = argv[1];
  string rnaifile = argv[2];

  double mabx, mp1x, mabax, mabpx, memsx, mp2x;
  double maby, mp1y, mabay, mabpy, memsy, mp2y;
  double mabz, mp1z, mabaz, mabpz, memsz, mp2z;
  double mabd, mp1d, mabad, mabpd, memsd, mp2d;
  double mabalx, mabarx, mabplx, mabprx, mmsx, mex, mcx, mp3x;
  double mabaly, mabary, mabply, mabpry, mmsy, mey, mcy, mp3y;
  double mabalz, mabarz, mabplz, mabprz, mmsz, mez, mcz, mp3z;
  double mabald, mabard, mabpld, mabprd, mmsd, med, mcd, mp3d;

  double sabx, sp1x, sabax, sabpx, semsx, sp2x;
  double saby, sp1y, sabay, sabpy, semsy, sp2y;
  double sabz, sp1z, sabaz, sabpz, semsz, sp2z;
  double sabd, sp1d, sabad, sabpd, semsd, sp2d;
  double sabalx, sabarx, sabplx, sabprx, smsx, sex, scx, sp3x;
  double sabaly, sabary, sabply, sabpry, smsy, sey, scy, sp3y;
  double sabalz, sabarz, sabplz, sabprz, smsz, sez, scz, sp3z;
  double sabald, sabard, sabpld, sabprd, smsd, sed, scd, sp3d;

  ifstream wt;
  wt.open(wtfile.c_str());
  if (!wt) {
    cerr << "cannot open wt file... " << endl;
    exit(-1);
  } else {
    wt >> mabx >> maby >> mabz >> mabd >> mp1x >> mp1y >> mp1z >> mp1d >> mabax >> mabay >> mabaz >> mabad >> mabpx >> mabpy >> mabpz >> mabpd >> memsx >> memsy >> memsz >> memsd >> mp2x >> mp2y >> mp2z >> mp2d >> mabalx >> mabaly >> mabalz >> mabald >> mabarx >> mabary >> mabarz >> mabard >> mabplx >> mabply >> mabplz >> mabpld >> mabprx >> mabpry >> mabprz >> mabprd >> mex >> mey >> mez >> med >> mmsx >> mmsy >> mmsz >> mmsd >> mcx >> mcy >> mcz >> mcd >> mp3x >> mp3y >> mp3z >> mp3d;
    wt >> sabx >> saby >> sabz >> sabd >> sp1x >> sp1y >> sp1z >> sp1d >> sabax >> sabay >> sabaz >> sabad >> sabpx >> sabpy >> sabpz >> sabpd >> semsx >> semsy >> semsz >> semsd >> sp2x >> sp2y >> sp2z >> sp2d >> sabalx >> sabaly >> sabalz >> sabald >> sabarx >> sabary >> sabarz >> sabard >> sabplx >> sabply >> sabplz >> sabpld >> sabprx >> sabpry >> sabprz >> sabprd >> sex >> sey >> sez >> sed >> smsx >> smsy >> smsz >> smsd >> scx >> scy >> scz >> scd >> sp3x >> sp3y >> sp3z >> sp3d;
  }

  string gname;
  double abx, p1x, abax, abpx, emsx, p2x;
  double abalx, abarx, abplx, abprx, ex, msx, cx, p3x;
  double aby, p1y, abay, abpy, emsy, p2y;
  double abaly, abary, abply, abpry, ey, msy, cy, p3y;
  double abz, p1z, abaz, abpz, emsz, p2z;
  double abalz, abarz, abplz, abprz, ez, msz, cz, p3z;
  double abd, p1d, abad, abpd, emsd, p2d;
  double abald, abard, abpld, abprd, ed, msd, cd, p3d;

  ifstream rnai;
  rnai.open(rnaifile.c_str());
  if (!rnai) {
    cerr << "cannot open rnai file... " << endl;
    exit(-1);
  }

  while (rnai >> gname >> abx >> aby >> abz >> abd >> p1x >> p1y >> p1z >> p1d >> abax >> abay >> abaz >> abad >> abpx >> abpy >> abpz >> abpd >> emsx >> emsy >> emsz >> emsd >> p2x >> p2y >> p2z >> p2d >> abalx >> abaly >> abalz >> abald >> abarx >> abary >> abarz >> abard >> abplx >> abply >> abplz >> abpld >> abprx >> abpry >> abprz >> abprd >> ex >> ey >> ez >> ed >> msx >> msy >> msz >> msd >> cx >> cy >> cz >> cd >> p3x >> p3y >> p3z >> p3d) {
    cout << gname << "\t";

    if (abx != -1000 && aby != -1000 && abz != -1000 && abd != -1000) {
      cout << sqrt((abx - mabx) * (abx - mabx) + (aby - maby) * (aby - maby) + (abz - mabz) * (abz - mabz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (p1x != -1000 && p1y != -1000 && p1z != -1000 && p1d != -1000) {
      cout << sqrt((p1x - mp1x) * (p1x - mp1x) + (p1y - mp1y) * (p1y - mp1y) + (p1z - mp1z) * (p1z - mp1z)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abax != -1000 && abay != -1000 && abaz != -1000 && abad != -1000) {
      cout << sqrt((abax - mabax) * (abax - mabax) + (abay - mabay) * (abay - mabay) + (abaz - mabaz) * (abaz - mabaz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abpx != -1000 && abpy != -1000 && abpz != -1000 && abpd != -1000) {
      cout << sqrt((abpx - mabpx) * (abpx - mabpx) + (abpy - mabpy) * (abpy - mabpy) + (abpz - mabpz) * (abpz - mabpz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (emsx != -1000 && emsy != -1000 && emsz != -1000 && emsd != -1000) {
      cout << sqrt((emsx - memsx) * (emsx - memsx) + (emsy - memsy) * (emsy - memsy) + (emsz - memsz) * (emsz - memsz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (p2x != -1000 && p2y != -1000 && p2z != -1000 && p2d != -1000) {
      cout << sqrt((p2x - mp2x) * (p2x - mp2x) + (p2y - mp2y) * (p2y - mp2y) + (p2z - mp2z) * (p2z - mp2z)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abalx != -1000 && abaly != -1000 && abalz != -1000 && abald != -1000) {
      cout << sqrt((abalx - mabalx) * (abalx - mabalx) + (abaly - mabaly) * (abaly - mabaly) + (abalz - mabalz) * (abalz - mabalz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abarx != -1000 && abary != -1000 && abarz != -1000 && abard != -1000) {
      cout << sqrt((abarx - mabarx) * (abarx - mabarx) + (abary - mabary) * (abary - mabary) + (abarz - mabarz) * (abarz - mabarz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abplx != -1000 && abply != -1000 && abplz != -1000 && abpld != -1000) {
      cout << sqrt((abplx - mabplx) * (abplx - mabplx) + (abply - mabply) * (abply - mabply) + (abplz - mabplz) * (abplz - mabplz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abprx != -1000 && abpry != -1000 && abprz != -1000 && abprd != -1000) {
      cout << sqrt((abprx - mabprx) * (abprx - mabprx) + (abpry - mabpry) * (abpry - mabpry) + (abprz - mabprz) * (abprz - mabprz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (ex != -1000 && ey != -1000 && ez != -1000 && ed != -1000) {
      cout << sqrt((ex - mex) * (ex - mex) + (ey - mey) * (ey - mey) + (ez - mez) * (ez - mez)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (msx != -1000 && msy != -1000 && msz != -1000 && msd != -1000) {
      cout << sqrt((msx - mmsx) * (msx - mmsx) + (msy - mmsy) * (msy - mmsy) + (msz - mmsz) * (msz - mmsz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (cx != -1000 && cy != -1000 && cz != -1000 && cd != -1000) {
      cout << sqrt((cx - mcx) * (cx - mcx) + (cy - mcy) * (cy - mcy) + (cz - mcz) * (cz - mcz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (p3x != -1000 && p3y != -1000 && p3z != -1000 && p3d != -1000) {
      cout << sqrt((p3x - mp3x) * (p3x - mp3x) + (p3y - mp3y) * (p3y - mp3y) + (p3z - mp3z) * (p3z - mp3z)) << endl;
    } else {
      cout << "-1000" << endl;
    }

  }

  return 0;
}
