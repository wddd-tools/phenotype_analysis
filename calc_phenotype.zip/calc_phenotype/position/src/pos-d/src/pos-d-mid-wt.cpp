#include <iostream>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
  string wtfile = argv[1];
  string rnaifile = argv[2];

  double mabx, mp1x, mabax, mabpx, memsx, mp2x;
  double maby, mp1y, mabay, mabpy, memsy, mp2y;
  double mabz, mp1z, mabaz, mabpz, memsz, mp2z;
  double mabd, mp1d, mabad, mabpd, memsd, mp2d;
  double mtwoabx, mtwop1x, mfabax, mfabpx, mfemsx, mfp2x;
  double mtwoaby, mtwop1y, mfabay, mfabpy, mfemsy, mfp2y;
  double mtwoabz, mtwop1z, mfabaz, mfabpz, mfemsz, mfp2z;
  double mtwoabd, mtwop1d, mfabad, mfabpd, mfemsd, mfp2d;

  double sabx, sp1x, sabax, sabpx, semsx, sp2x;
  double saby, sp1y, sabay, sabpy, semsy, sp2y;
  double sabz, sp1z, sabaz, sabpz, semsz, sp2z;
  double sabd, sp1d, sabad, sabpd, semsd, sp2d;
  double stwoabx, stwop1x, sfabax, sfabpx, sfemsx, sfp2x;
  double stwoaby, stwop1y, sfabay, sfabpy, sfemsy, sfp2y;
  double stwoabz, stwop1z, sfabaz, sfabpz, sfemsz, sfp2z;
  double stwoabd, stwop1d, sfabad, sfabpd, sfemsd, sfp2d;

  ifstream wt;
  wt.open(wtfile.c_str());
  if (!wt) {
    cerr << "cannot open wt file... " << endl;
    exit(-1);
  } else {
    wt >> mabx >> maby >> mabz >> mabd >> mp1x >> mp1y >> mp1z >> mp1d >> mabax >> mabay >> mabaz >> mabad >> mabpx >> mabpy >> mabpz >> mabpd >> memsx >> memsy >> memsz >> memsd >> mp2x >> mp2y >> mp2z >> mp2d >> mtwoabx >> mtwoaby >> mtwoabz >> mtwoabd >> mtwop1x >> mtwop1y >> mtwop1z >> mtwop1d >> mfabax >> mfabay >> mfabaz >> mfabad >> mfabpx >> mfabpy >> mfabpz >> mfabpd >> mfemsx >> mfemsy >> mfemsz >> mfemsd >> mfp2x >> mfp2y >> mfp2z >> mfp2d;
    wt >> sabx >> saby >> sabz >> sabd >> sp1x >> sp1y >> sp1z >> sp1d >> sabax >> sabay >> sabaz >> sabad >> sabpx >> sabpy >> sabpz >> sabpd >> semsx >> semsy >> semsz >> semsd >> sp2x >> sp2y >> sp2z >> sp2d >> stwoabx >> stwoaby >> stwoabz >> stwoabd >> stwop1x >> stwop1y >> stwop1z >> stwop1d >> sfabax >> sfabay >> sfabaz >> sfabad >> sfabpx >> sfabpy >> sfabpz >> sfabpd >> sfemsx >> sfemsy >> sfemsz >> sfemsd >> sfp2x >> sfp2y >> sfp2z >> sfp2d;
  }

  string gname;
  double abx, p1x, abax, abpx, emsx, p2x;
  double aby, p1y, abay, abpy, emsy, p2y;
  double abz, p1z, abaz, abpz, emsz, p2z;
  double abd, p1d, abad, abpd, emsd, p2d;
  double tabx, tp1x, fabax, fabpx, femsx, fp2x;
  double taby, tp1y, fabay, fabpy, femsy, fp2y;
  double tabz, tp1z, fabaz, fabpz, femsz, fp2z;
  double tabd, tp1d, fabad, fabpd, femsd, fp2d;


  ifstream rnai;
  rnai.open(rnaifile.c_str());
  if (!rnai) {
    cerr << "cannot open rnai file... " << endl;
    exit(-1);
  }

  while (rnai >> gname >> abx >> aby >> abz >> abd >> p1x >> p1y >> p1z >> p1d >> abax >> abay >> abaz >> abad >> abpx >> abpy >> abpz >> abpd >> emsx >> emsy >> emsz >> emsd >> p2x >> p2y >> p2z >> p2d >> tabx >> taby >> tabz >> tabd >> tp1x >> tp1y >> tp1z >> tp1d >> fabax >> fabay >> fabaz >> fabad >> fabpx >> fabpy >> fabpz >> fabpd >> femsx >> femsy >> femsz >> femsd >> fp2x >> fp2y >> fp2z >> fp2d) {
    cout << gname << "\t";

    if (abx != -1000 && aby != -1000 && abz != -1000 && abd != -1000) {
      cout << sqrt((abx - mabx) * (abx - mabx) + (aby - maby) * (aby - maby) + (abz - mabz) * (abz - mabz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (p1x != -1000 && p1y != -1000 && p1z != -1000 && p1d != -1000) {
      cout << sqrt((p1x - mp1x) * (p1x - mp1x) + (p1y - mp1y) * (p1y - mp1y) + (p1z - mp1z) * (p1z - mp1z)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abax != -1000 && abay != -1000 && abaz != -1000 && abad != -1000) {
      cout << sqrt((abax - mabax) * (abax - mabax) + (abay - mabay) * (abay - mabay) + (abaz - mabaz) * (abaz - mabaz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abpx != -1000 && abpy != -1000 && abpz != -1000 && abpd != -1000) {
      cout << sqrt((abpx - mabpx) * (abpx - mabpx) + (abpy - mabpy) * (abpy - mabpy) + (abpz - mabpz) * (abpz - mabpz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (emsx != -1000 && emsy != -1000 && emsz != -1000 && emsd != -1000) {
      cout << sqrt((emsx - memsx) * (emsx - memsx) + (emsy - memsy) * (emsy - memsy) + (emsz - memsz) * (emsz - memsz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (p2x != -1000 && p2y != -1000 && p2z != -1000 && p2d != -1000) {
      cout << sqrt((p2x - mp2x) * (p2x - mp2x) + (p2y - mp2y) * (p2y - mp2y) + (p2z - mp2z) * (p2z - mp2z)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (tabx != -1000 && taby != -1000 && tabz != -1000 && tabd != -1000) {
      cout << sqrt((tabx - mtwoabx) * (tabx - mtwoabx) + (taby - mtwoaby) * (taby - mtwoaby) + (tabz - mtwoabz) * (tabz - mtwoabz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (tp1x != -1000 && tp1y != -1000 && tp1z != -1000 && tp1d != -1000) {
      cout << sqrt((tp1x - mtwop1x) * (tp1x - mtwop1x) + (tp1y - mtwop1y) * (tp1y - mtwop1y) + (tp1z - mtwop1z) * (tp1z - mtwop1z)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (fabax != -1000 && fabay != -1000 && fabaz != -1000 && fabad != -1000) {
      cout << sqrt((fabax - mfabax) * (fabax - mfabax) + (fabay - mfabay) * (fabay - mfabay) + (fabaz - mfabaz) * (fabaz - mfabaz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (fabpx != -1000 && fabpy != -1000 && fabpz != -1000 && fabpd != -1000) {
      cout << sqrt((fabpx - mfabpx) * (fabpx - mfabpx) + (fabpy - mfabpy) * (fabpy - mfabpy) + (fabpz - mfabpz) * (fabpz - mfabpz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (femsx != -1000 && femsy != -1000 && femsz != -1000 && femsd != -1000) {
      cout << sqrt((femsx - mfemsx) * (femsx - mfemsx) + (femsy - mfemsy) * (femsy - femsy) + (femsz - mfemsz) * (femsz - mfemsz)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (fp2x != -1000 && fp2y != -1000 && fp2z != -1000 && fp2d != -1000) {
      cout << sqrt((fp2x - mfp2x) * (fp2x - mfp2x) + (fp2y - mfp2y) * (fp2y - mfp2y) + (fp2z - mfp2z) * (fp2z - mfp2z)) << endl;
    } else {
      cout << "-1000" << endl;
    }

  }

  return 0;
}
