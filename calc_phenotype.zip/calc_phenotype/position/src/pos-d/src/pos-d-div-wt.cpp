#include <iostream>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
  string wtfile = argv[1];
  string rnaifile = argv[2];

  double mp1x_ab, mp1y_ab, mp1z_ab, mp1d_ab;

  double memsx_aba, memsy_aba, memsd_aba;
  double mp2x_aba, mp2y_aba, mp2z_aba, mp2d_aba;
  double memsx_abp, memsy_abp, memsd_abp;
  double mp2x_abp, mp2y_abp, mp2z_abp, mp2d_abp;

  double mabalx_ems, mabaly_ems, mabalz_ems, mabald_ems;
  double mabarx_ems, mabary_ems, mabarz_ems, mabard_ems;
  double mabplx_ems, mabply_ems, mabplz_ems, mabpld_ems;
  double mabprx_ems, mabpry_ems, mabprz_ems, mabprd_ems;
  double mp2x_ems, mp2y_ems, mp2z_ems, mp2d_ems;

  double mabalx_p2, mabaly_p2, mabalz_p2, mabald_p2;
  double mabarx_p2, mabary_p2, mabarz_p2, mabard_p2;
  double mabplx_p2, mabply_p2, mabplz_p2, mabpld_p2;
  double mabprx_p2, mabpry_p2, mabprz_p2, mabprd_p2;
  double mmsx_p2, mmsy_p2, mmsz_p2, mmsd_p2;
  double mex_p2, mey_p2, med_p2;

  ifstream wt;
  wt.open(wtfile.c_str(), ios::in);
  if (!wt) {
    cerr << "cannot open wt file..." << endl;
    exit(-1);
  } else {
    wt >> mp1x_ab >> mp1y_ab >> mp1z_ab >> mp1d_ab >> memsx_aba >> memsy_aba >> memsd_aba >> mp2x_aba >> mp2y_aba >> mp2z_aba >> mp2d_aba >> memsx_abp >> memsy_abp >> memsd_abp >> mp2x_abp >> mp2y_abp >> mp2z_abp >> mp2d_abp >> mabalx_ems >> mabaly_ems >> mabalz_ems >> mabald_ems >> mabarx_ems >> mabary_ems >> mabarz_ems >> mabard_ems >> mabplx_ems >> mabply_ems >> mabplz_ems >> mabpld_ems >> mabprx_ems >> mabpry_ems >> mabprz_ems >> mabprd_ems >> mp2x_ems >> mp2y_ems >> mp2z_ems >> mp2d_ems >> mabalx_p2 >> mabaly_p2 >> mabalz_p2 >> mabald_p2 >> mabarx_p2 >> mabary_p2 >> mabarz_p2 >> mabard_p2 >> mabplx_p2 >> mabply_p2 >> mabplz_p2 >> mabpld_p2 >> mabprx_p2 >> mabpry_p2 >> mabprz_p2 >> mabprd_p2 >> mmsx_p2 >> mmsy_p2 >> mmsz_p2 >> mmsd_p2 >> mex_p2 >> mey_p2 >> med_p2;
  }

  string gname;
  double p1x_ab, p1y_ab, p1z_ab, p1d_ab;
  double emsx_aba, emsy_aba, emsd_aba;
  double p2x_aba, p2y_aba, p2z_aba, p2d_aba;
  double emsx_abp, emsy_abp, emsd_abp;
  double p2x_abp, p2y_abp, p2z_abp, p2d_abp;
  double abalx_ems, abaly_ems, abalz_ems, abald_ems;
  double abarx_ems, abary_ems, abarz_ems, abard_ems;
  double abplx_ems, abply_ems, abplz_ems, abpld_ems;
  double abprx_ems, abpry_ems, abprz_ems, abprd_ems;
  double p2x_ems, p2y_ems, p2z_ems, p2d_ems;
  double abalx_p2, abaly_p2, abalz_p2, abald_p2;
  double abarx_p2, abary_p2, abarz_p2, abard_p2;
  double abplx_p2, abply_p2, abplz_p2, abpld_p2;
  double abprx_p2, abpry_p2, abprz_p2, abprd_p2;
  double msx_p2, msy_p2, msz_p2, msd_p2;
  double ex_p2, ey_p2, ed_p2;

  ifstream rnai;
  rnai.open(rnaifile.c_str(), ios::in);
  if (!rnai) {
    cerr << "cannot open rnai file ..." << endl;
    exit(-1);
  }

  while (rnai >> gname >> p1x_ab >> p1y_ab >> p1z_ab >> p1d_ab >> emsx_aba >> emsy_aba >> emsd_aba >> p2x_aba >> p2y_aba >> p2z_aba >> p2d_aba >> emsx_abp >> emsy_abp >> emsd_abp >> p2x_abp >> p2y_abp >> p2z_abp >> p2d_abp >> abalx_ems >> abaly_ems >> abalz_ems >> abald_ems >> abarx_ems >> abary_ems >> abarz_ems >> abard_ems >> abplx_ems >> abply_ems >> abplz_ems >> abpld_ems >> abprx_ems >> abpry_ems >> abprz_ems >> abprd_ems >> p2x_ems >> p2y_ems >> p2z_ems >> p2d_ems >> abalx_p2 >> abaly_p2 >> abalz_p2 >> abald_p2 >> abarx_p2 >> abary_p2 >> abarz_p2 >> abard_p2 >> abplx_p2 >> abply_p2 >> abplz_p2 >> abpld_p2 >> abprx_p2 >> abpry_p2 >> abprz_p2 >> abprd_p2 >> msx_p2 >> msy_p2 >> msz_p2 >> msd_p2 >> ex_p2 >> ey_p2 >> ed_p2) {
    cout << gname << "\t";

    if (p1x_ab != -1000 && p1y_ab != -1000 && p1z_ab != -1000) {
      cout << sqrt((p1x_ab - mp1x_ab) * (p1x_ab - mp1x_ab) + (p1y_ab - mp1y_ab) * (p1y_ab - mp1y_ab) + (p1z_ab - mp1z_ab) * (p1z_ab - mp1z_ab)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (emsx_aba != -1000 && emsy_aba != -1000) {
      cout << sqrt((emsx_aba - memsx_aba) * (emsx_aba - memsx_aba) + (emsy_aba - memsy_aba) * (emsy_aba - memsy_aba)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (p2x_aba != -1000 && p2y_aba != -1000 && p2z_aba != -1000) {
      cout << sqrt((p2x_aba - mp2x_aba) * (p2x_aba - mp2x_aba) + (p2y_aba - mp2y_aba) * (p2y_aba - mp2y_aba) + (p2z_aba - mp2z_aba) * (p2z_aba - mp2z_aba)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (emsx_abp != -1000 && emsy_abp != -1000) {
      cout << sqrt((emsx_abp - memsx_abp) * (emsx_abp - memsx_abp) + (emsy_abp - memsy_abp) * (emsy_abp - memsy_abp)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (p2x_abp != -1000 && p2y_abp != -1000 && p2z_abp != -1000) {
      cout << sqrt((p2x_abp - mp2x_abp) * (p2x_abp - mp2x_abp) + (p2y_abp - mp2y_abp) * (p2y_abp - mp2y_abp) + (p2z_abp - mp2z_abp) * (p2z_abp - mp2z_abp)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abalx_ems != -1000 && abaly_ems != -1000 && abalz_ems != -1000) {
      cout << sqrt((abalx_ems - mabalx_ems) * (abalx_ems - mabalx_ems) + (abaly_ems - mabaly_ems) * (abaly_ems - mabaly_ems) + (abalz_ems - mabalz_ems) * (abalz_ems - mabalz_ems)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abarx_ems != -1000 && abary_ems != -1000 && abarz_ems != -1000) {
      cout << sqrt((abarx_ems - mabarx_ems) * (abarx_ems - mabarx_ems) + (abary_ems - mabary_ems) * (abary_ems - mabary_ems) + (abarz_ems - mabarz_ems) * (abarz_ems - mabarz_ems)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abplx_ems != -1000 && abply_ems != -1000 && abplz_ems != -1000) {
      cout << sqrt((abplx_ems - mabplx_ems) * (abplx_ems - mabplx_ems) + (abply_ems - mabply_ems) * (abply_ems - mabply_ems) + (abplz_ems - mabplz_ems) * (abplz_ems - mabplz_ems)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abprx_ems != -1000 && abpry_ems != -1000 && abprz_ems != -1000) {
      cout << sqrt((abprx_ems - mabprx_ems) * (abprx_ems - mabprx_ems) + (abpry_ems - mabpry_ems) * (abpry_ems - mabpry_ems) + (abprz_ems - mabprz_ems) * (abprz_ems - mabprz_ems)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (p2x_ems != -1000 && p2y_ems != -1000 && p2z_ems != -1000) {
      cout << sqrt((p2x_ems - mp2x_ems) * (p2x_ems - mp2x_ems) + (p2y_ems - mp2y_ems) * (p2y_ems - mp2y_ems) + (p2z_ems - mp2z_ems) * (p2z_ems - mp2z_ems)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abalx_p2 != -1000 && abaly_p2 != -1000 && abalz_p2 != -1000) {
      cout << sqrt((abalx_p2 - mabalx_p2) * (abalx_p2 - mabalx_p2) + (abaly_p2 - mabaly_p2) * (abaly_p2 - mabaly_p2) + (abalz_p2 - mabalz_p2) * (abalz_p2 - mabalz_p2)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abarx_p2 != -1000 && abary_p2 != -1000 && abarz_p2 != -1000) {
      cout << sqrt((abarx_p2 - mabarx_p2) * (abarx_p2 - mabarx_p2) + (abary_p2 - mabary_p2) * (abary_p2 - mabary_p2) + (abarz_p2 - mabarz_p2) * (abarz_p2 - mabarz_p2)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abplx_p2 != -1000 && abply_p2 != -1000 && abplz_p2 != -1000) {
      cout << sqrt((abplx_p2 - mabplx_p2) * (abplx_p2 - mabplx_p2) + (abply_p2 - mabply_p2) * (abply_p2 - mabply_p2) + (abplz_p2 - mabplz_p2) * (abplz_p2 - mabplz_p2)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (abprx_p2 != -1000 && abpry_p2 != -1000 && abprz_p2 != -1000) {
      cout << sqrt((abprx_p2 - mabprx_p2) * (abprx_p2 - mabprx_p2) + (abpry_p2 - mabpry_p2) * (abpry_p2 - mabpry_p2) + (abprz_p2 - mabprz_p2) * (abprz_p2 - mabprz_p2)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (msx_p2 != -1000 && msy_p2 != -1000 && msz_p2 != -1000) {
      cout << sqrt((msx_p2 - mmsx_p2) * (msx_p2 - mmsx_p2) + (msy_p2 - mmsy_p2) * (msy_p2 - mmsy_p2) + (msz_p2 - mmsz_p2) * (msz_p2 - mmsz_p2)) << "\t";
    } else {
      cout << "-1000\t";
    }

    if (ex_p2 != -1000 && ey_p2 != -1000) {
      cout << sqrt((ex_p2 - mex_p2) * (ex_p2 - mex_p2) + (ey_p2 - mey_p2) * (ey_p2 - mey_p2)) << endl;
    } else {
      cout << "-1000" << endl;
    }
  }

  return 0;
}
