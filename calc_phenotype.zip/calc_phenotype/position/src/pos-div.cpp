#include <iostream>
#include <cstring>
#include <fstream>
#include <cmath>
#include <cstdlib>
using namespace std;

int main(int argc, char* argv[])
{
  string gname = argv[1];
  string plngfile = argv[2];
  string clngfile = argv[3];

  double p1x_ab = -1000.0, p1y_ab = -1000.0, p1z_ab = -1000;

  double emsx_aba = -1000.0, emsy_aba = -1000.0, emsz_aba = -1000.0;
  double p2x_aba = -1000.0, p2y_aba = -1000.0, p2z_aba = -1000.0;

  double emsx_abp = -1000.0, emsy_abp = -1000.0, emsz_abp = -1000.0;
  double p2x_abp = -1000.0, p2y_abp = -1000.0, p2z_abp = -1000.0;

  double abalx_ems = -1000.0, abaly_ems = -1000.0, abalz_ems = -1000.0;
  double abarx_ems = -1000.0, abary_ems = -1000.0, abarz_ems = -1000.0;
  double abplx_ems = -1000.0, abply_ems = -1000.0, abplz_ems = -1000.0;
  double abprx_ems = -1000.0, abpry_ems = -1000.0, abprz_ems = -1000.0;
  double p2x_ems = -1000.0, p2y_ems = -1000.0, p2z_ems = -1000.0;

  double abalx_p2 = -1000.0, abaly_p2 = -1000.0, abalz_p2 = -1000.0;
  double abarx_p2 = -1000.0, abary_p2 = -1000.0, abarz_p2 = -1000.0;
  double abplx_p2 = -1000.0, abply_p2 = -1000.0, abplz_p2 = -1000.0;
  double abprx_p2 = -1000.0, abpry_p2 = -1000.0, abprz_p2 = -1000.0;
  double msx_p2 = -1000.0, msy_p2 = -1000.0, msz_p2 = -1000.0;
  double ex_p2 = -1000.0, ey_p2 = -1000.0, ez_p2 = -1000.0;

  double msx_abal = -1000.0, msy_abal = -1000.0, msz_abal = -1000.0;
  double ex_abal = -1000.0, ey_abal = -1000.0, ez_abal = -1000.0;
  double cx_abal = -1000.0, cy_abal = -1000.0, cz_abal = -1000.0;
  double p3x_abal = -1000.0, p3y_abal = -1000.0, p3z_abal = -1000.0;

  double msx_abar = -1000.0, msy_abar = -1000.0, msz_abar = -1000.0;
  double ex_abar = -1000.0, ey_abar = -1000.0, ez_abar = -1000.0;
  double cx_abar = -1000.0, cy_abar = -1000.0, cz_abar = -1000.0;
  double p3x_abar = -1000.0, p3y_abar = -1000.0, p3z_abar = -1000.0;

  double msx_abpl = -1000.0, msy_abpl = -1000.0, msz_abpl = -1000.0;
  double ex_abpl = -1000.0, ey_abpl = -1000.0, ez_abpl = -1000.0;
  double cx_abpl = -1000.0, cy_abpl = -1000.0, cz_abpl = -1000.0;
  double p3x_abpl = -1000.0, p3y_abpl = -1000.0, p3z_abpl = -1000.0;

  double msx_abpr = -1000.0, msy_abpr = -1000.0, msz_abpr = -1000.0;
  double ex_abpr = -1000.0, ey_abpr = -1000.0, ez_abpr = -1000.0;
  double cx_abpr = -1000.0, cy_abpr = -1000.0, cz_abpr = -1000.0;
  double p3x_abpr = -1000.0, p3y_abpr = -1000.0, p3z_abpr = -1000.0;

  double abalax_ms = -1000.0, abalay_ms = -1000.0, abalaz_ms = -1000.0;
  double abalpx_ms = -1000.0, abalpy_ms = -1000.0, abalpz_ms = -1000.0;
  double abarax_ms = -1000.0, abaray_ms = -1000.0, abaraz_ms = -1000.0;
  double abarpx_ms = -1000.0, abarpy_ms = -1000.0, abarpz_ms = -1000.0;
  double abplax_ms = -1000.0, abplay_ms = -1000.0, abplaz_ms = -1000.0;
  double abplpx_ms = -1000.0, abplpy_ms = -1000.0, abplpz_ms = -1000.0;
  double abprax_ms = -1000.0, abpray_ms = -1000.0, abpraz_ms = -1000.0;
  double abprpx_ms = -1000.0, abprpy_ms = -1000.0, abprpz_ms = -1000.0;
  double ex_ms = -1000.0, ey_ms = -1000.0, ez_ms = -1000.0;
  double cx_ms = -1000.0, cy_ms = -1000.0, cz_ms = -1000.0;
  double p3x_ms = -1000.0, p3y_ms = -1000.0, p3z_ms = -1000.0;

  double abalax_e = -1000.0, abalay_e = -1000.0, abalaz_e = -1000.0;
  double abalpx_e = -1000.0, abalpy_e = -1000.0, abalpz_e = -1000.0;
  double abarax_e = -1000.0, abaray_e = -1000.0, abaraz_e = -1000.0;
  double abarpx_e = -1000.0, abarpy_e = -1000.0, abarpz_e = -1000.0;
  double abplax_e = -1000.0, abplay_e = -1000.0, abplaz_e = -1000.0;
  double abplpx_e = -1000.0, abplpy_e = -1000.0, abplpz_e = -1000.0;
  double abprax_e = -1000.0, abpray_e = -1000.0, abpraz_e = -1000.0;
  double abprpx_e = -1000.0, abprpy_e = -1000.0, abprpz_e = -1000.0;
  double cx_e = -1000.0, cy_e = -1000.0, cz_e = -1000.0;
  double p3x_e = -1000.0, p3y_e = -1000.0, p3z_e = -1000.0;

  double abalax_c = -1000.0, abalay_c = -1000.0, abalaz_c = -1000.0;
  double abalpx_c = -1000.0, abalpy_c = -1000.0, abalpz_c = -1000.0;
  double abarax_c = -1000.0, abaray_c = -1000.0, abaraz_c = -1000.0;
  double abarpx_c = -1000.0, abarpy_c = -1000.0, abarpz_c = -1000.0;
  double abplax_c = -1000.0, abplay_c = -1000.0, abplaz_c = -1000.0;
  double abplpx_c = -1000.0, abplpy_c = -1000.0, abplpz_c = -1000.0;
  double abprax_c = -1000.0, abpray_c = -1000.0, abpraz_c = -1000.0;
  double abprpx_c = -1000.0, abprpy_c = -1000.0, abprpz_c = -1000.0;
  double msax_c = -1000.0, msay_c = -1000.0, msaz_c = -1000.0;
  double mspx_c = -1000.0, mspy_c = -1000.0, mspz_c = -1000.0;
  double eax_c = -1000.0, eay_c = -1000.0, eaz_c = -1000.0;
  double epx_c = -1000.0, epy_c = -1000.0, epz_c = -1000.0;
  double p3x_c = -1000.0, p3y_c = -1000.0, p3z_c = -1000.0;

  ifstream plng;
  plng.open(plngfile.c_str(), ios::in);

  int t, pid, cid;
  double x, y, z, sph, vol;
  string name, div;

  int fab = 0, faba = 0, fabp = 0, fems = 0, fp2 = 0;
  int fabal = 0, fabar = 0, fabpl = 0, fabpr = 0, fms = 0, fe = 0, fc = 0;
  int tab = 0, taba = 0, tabp = 0, tems = 0, tp2 = 0;
  int tabal = 0, tabar = 0, tabpl = 0, tabpr = 0, tms = 0, te = 0, tc = 0;


  while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div) {
    if (!strcmp(name.c_str(), "AB") && !strcmp(div.c_str(), "N")) {
      fab = 1;
    } else if (!strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "N")) {
      faba = 1;
    } else if (!strcmp(name.c_str(), "ABp") && !strcmp(div.c_str(), "N")) {
      fabp = 1;
    } else if (!strcmp(name.c_str(), "EMS") && !strcmp(div.c_str(), "N")) {
      fems = 1;
    } else if (!strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "N")) {
      fp2 = 1;
    }

    if (!strcmp(name.c_str(), "AB") && !strcmp(div.c_str(), "D") && fab == 1) {
      tab = t;
      fab = 2;
    } else if (!strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "D") && faba == 1) {
      taba = t;
      faba = 2;
    } else if (!strcmp(name.c_str(), "ABp") && !strcmp(div.c_str(), "D") && fabp == 1) {
      tabp = t;
      fabp = 2;
    } else if (!strcmp(name.c_str(), "EMS") && !strcmp(div.c_str(), "D") && fems == 1) {
      tems = t;
      fems = 2;
    } else if (!strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "D") && fp2 == 1) {
      tp2 = t;
      fp2 = 2;
    }
  }
  plng.close();


  int ts, pid2, cid2;
  double x2, y2, z2;
  string name2;

  plng.open(plngfile.c_str(), ios::in);

  ifstream clng;
  clng.open(clngfile.c_str(), ios::in);
  while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div, clng >> ts >> pid2 >> cid2 >> x2 >> y2 >> z2 >> name2) {
    if (!strcmp(name.c_str(), "P1") && !strcmp(div.c_str(), "N") && t == tab) {
      p1x_ab = x2;
      p1y_ab = y2;
      p1z_ab = z2;
    }
    if (!strcmp(name.c_str(), "EMS") && !strcmp(div.c_str(), "N") && t == taba) {
      emsx_aba = x2;
      emsy_aba = y2;
      emsz_aba = z2;
    }
    if (!strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "N") && t == taba) {
      p2x_aba = x2;
      p2y_aba = y2;
      p2z_aba = z2;
    }
    if (!strcmp(name.c_str(), "EMS") && !strcmp(div.c_str(), "N") && t == tabp) {
      emsx_abp = x2;
      emsy_abp = y2;
      emsz_abp = z2;
    }
    if (!strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "N") && t == tabp) {
      p2x_abp = x2;
      p2y_abp = y2;
      p2z_abp = z2;
    }
    if (!strcmp(name.c_str(), "ABal") && !strcmp(div.c_str(), "N") && t == tems) {
      abalx_ems = x2;
      abaly_ems = y2;
      abalz_ems = z2;
    }
    if (!strcmp(name.c_str(), "ABar") && !strcmp(div.c_str(), "N") && t == tems) {
      abarx_ems = x2;
      abary_ems = y2;
      abarz_ems = z2;
    }
    if (!strcmp(name.c_str(), "ABpl") && !strcmp(div.c_str(), "N") && t == tems) {
      abplx_ems = x2;
      abply_ems = y2;
      abplz_ems = z2;
    }
    if (!strcmp(name.c_str(), "ABpr") && !strcmp(div.c_str(), "N") && t == tems) {
      abprx_ems = x2;
      abpry_ems = y2;
      abprz_ems = z2;
    }
    if (!strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "N") && t == tems) {
      p2x_ems = x2;
      p2y_ems = y2;
      p2z_ems = z2;
    }
    if (!strcmp(name.c_str(), "ABal") && !strcmp(div.c_str(), "N") && t == tp2) {
      abalx_p2 = x2;
      abaly_p2 = y2;
      abalz_p2 = z2;
    }
    if (!strcmp(name.c_str(), "ABar") && !strcmp(div.c_str(), "N") && t == tp2) {
      abarx_p2 = x2;
      abary_p2 = y2;
      abarz_p2 = z2;
    }
    if (!strcmp(name.c_str(), "ABpl") && !strcmp(div.c_str(), "N") && t == tp2) {
      abplx_p2 = x2;
      abply_p2 = y2;
      abplz_p2 = z2;
    }
    if (!strcmp(name.c_str(), "ABpr") && !strcmp(div.c_str(), "N") && t == tp2) {
      abprx_p2 = x2;
      abpry_p2 = y2;
      abprz_p2 = z2;
    }
    if (!strcmp(name.c_str(), "MS") && !strcmp(div.c_str(), "N") && t == tp2) {
      msx_p2 = x2;
      msy_p2 = y2;
      msz_p2 = z2;
    }
    if (!strcmp(name.c_str(), "E") && !strcmp(div.c_str(), "N") && t == tp2) {
      ex_p2 = x2;
      ey_p2 = y2;
      ez_p2 = z2;
    }

  }

  cout << gname << " ";

  if (p1x_ab != -1000 && p1y_ab != -1000 && p1z_ab != -1000)
    cout << p1x_ab << " " << p1y_ab << " " << p1z_ab << " " << sqrt(p1x_ab * p1x_ab + p1y_ab * p1y_ab + p1z_ab * p1z_ab) << " ";
  else
    cout << "-1000 -1000 -1000 -1000" << " ";

  if (emsx_aba != -1000 && emsy_aba != -1000)
    cout << emsx_aba << " " << emsy_aba << " " << sqrt(emsx_aba * emsx_aba + emsy_aba * emsy_aba + emsz_aba * emsz_aba) << " ";
  else
    cout << "-1000 -1000 -1000" << " ";    

  if (p2x_aba != -1000 && p2y_aba != -1000 && p2z_aba != -1000)
    cout << p2x_aba << " " << p2y_aba << " " << p2z_aba << " " << sqrt(p2x_aba * p2x_aba + p2y_aba * p2y_aba + p2z_aba * p2z_aba) << " ";
  else
    cout << "-1000 -1000 -1000 -1000" << " ";        

  if (emsx_abp != -1000 && emsy_abp != -1000)
    cout << emsx_abp << " " << emsy_abp << " " << sqrt(emsx_abp * emsx_abp + emsy_abp * emsy_abp + emsz_abp * emsz_abp) << " ";
  else
    cout << "-1000 -1000 -1000" << " ";        

  if (p2x_abp != -1000 && p2y_abp != -1000 && p2z_abp != -1000)    
    cout << p2x_abp << " " << p2y_abp << " " << p2z_abp << " " << sqrt(p2x_abp * p2x_abp + p2y_abp * p2y_abp + p2z_abp * p2z_abp) << " ";
  else
    cout << "-1000 -1000 -1000 -1000" << " ";        

  if (abalx_ems != -1000 && abaly_ems != -1000 && abalz_ems != -1000)
    cout << abalx_ems << " " << abaly_ems << " " << abalz_ems << " " << sqrt(abalx_ems * abalx_ems + abaly_ems * abaly_ems + abalz_ems * abalz_ems) << " ";
  else
    cout << "-1000 -1000 -1000 -1000" << " ";        

  if (abarx_ems != -1000 && abary_ems != -1000 && abarz_ems != -1000)
    cout << abarx_ems << " " << abary_ems << " " << abarz_ems << " " << sqrt(abarx_ems * abarx_ems + abary_ems * abary_ems + abarz_ems * abarz_ems) << " ";
  else
    cout << "-1000 -1000 -1000 -1000" << " ";        

  if (abplx_ems != -1000 && abply_ems != -1000 && abplz_ems != -1000)
    cout << abplx_ems << " " << abply_ems << " " << abplz_ems << " " << sqrt(abplx_ems * abplx_ems + abply_ems * abply_ems + abplz_ems * abplz_ems) << " ";
  else
    cout << "-1000 -1000 -1000 -1000" << " ";        

  if (abprx_ems != -1000 && abpry_ems != -1000 && abprz_ems != -1000)
    cout << abprx_ems << " " << abpry_ems << " " << abprz_ems << " " << sqrt(abprx_ems * abprx_ems + abpry_ems * abpry_ems + abprz_ems * abprz_ems) << " ";
  else
    cout << "-1000 -1000 -1000 -1000" << " ";        

  if (p2x_ems != -1000 && p2y_ems != -1000 && p2z_ems != -1000)
    cout << p2x_ems << " " << p2y_ems << " " << p2z_ems << " " << sqrt(p2x_ems * p2x_ems + p2y_ems * p2y_ems + p2z_ems * p2z_ems) << " ";
  else
    cout << "-1000 -1000 -1000 -1000" << " ";        

  if (abalx_p2 != -1000 && abaly_p2 != -1000 && abalz_p2 != -1000)
    cout << abalx_p2 << " " << abaly_p2 << " " << abalz_p2 << " " << sqrt(abalx_p2 * abalx_p2 + abaly_p2 * abaly_p2 + abalz_p2 * abalz_p2) << " ";
  else
    cout << "-1000 -1000 -1000 -1000" << " ";        

  if (abarx_p2 != -1000 && abary_p2 != -1000 && abarz_p2 != -1000)
    cout << abarx_p2 << " " << abary_p2 << " " << abarz_p2 << " " << sqrt(abarx_p2 * abarx_p2 + abary_p2 * abary_p2 + abarz_p2 * abarz_p2) << " ";
  else
    cout << "-1000 -1000 -1000 -1000" << " ";        

  if (abplx_p2 != -1000 && abply_p2 != -1000 && abplz_p2 != -1000)
    cout << abplx_p2 << " " << abply_p2 << " " << abplz_p2 << " " << sqrt(abplx_p2 * abplx_p2 + abply_p2 * abply_p2 + abplz_p2 * abplz_p2) << " ";
  else
    cout << "-1000 -1000 -1000 -1000" << " ";        

  if (abprx_p2 != -1000 && abpry_p2 != -1000 && abprz_p2 != -1000)
    cout << abprx_p2 << " " << abpry_p2 << " " << abprz_p2 << " " << sqrt(abprx_p2 * abprx_p2 + abpry_p2 * abpry_p2 + abprz_p2 * abprz_p2) << " ";
  else
    cout << "-1000 -1000 -1000 -1000" << " ";

  if (msx_p2 != -1000 && msy_p2 != -1000 && msz_p2 != -1000)
    cout << msx_p2 << " " << msy_p2 << " " << msz_p2 << " " << sqrt(msx_p2 * msx_p2 + msy_p2 * msy_p2 + msz_p2 * msz_p2) << " ";
  else
    cout << "-1000 -1000 -1000 -1000" << " ";    

  if (ex_p2 != -1000 && ey_p2 != -1000)
    cout << ex_p2 << " " << ey_p2 << " " << sqrt(ex_p2 * ex_p2 + ey_p2 * ey_p2 + ez_p2 * ez_p2) << endl;
  else
    cout << "-1000 -1000 -1000" << endl;

  return 0;
}
