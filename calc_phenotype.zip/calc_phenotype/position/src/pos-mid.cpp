#include <iostream>
#include <cstring>
#include <fstream>
#include <cstdlib>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
  string gname = argv[1];
  string plngfile = argv[2];
  string clngfile = argv[3];


  double abx = 0.0, aby = 0.0, abz = 0.0;
  double p1x = 0.0, p1y = 0.0, p1z = 0.0;
  double twoabx = 0.0, twoaby = 0.0, twoabz = 0.0;
  double twop1x = 0.0, twop1y = 0.0, twop1z = 0.0;

  double abax = 0.0, abay = 0.0, abaz = 0.0;
  double abpx = 0.0, abpy = 0.0, abpz = 0.0;
  double emsx = 0.0, emsy = 0.0, emsz = 0.0;
  double p2x = 0.0, p2y = 0.0, p2z = 0.0;
  double fourabax = 0.0, fourabay = 0.0, fourabaz = 0.0;
  double fourabpx = 0.0, fourabpy = 0.0, fourabpz = 0.0;
  double fouremsx = 0.0, fouremsy = 0.0, fouremsz = 0.0;
  double fourp2x = 0.0, fourp2y = 0.0, fourp2z = 0.0;

  int fp0 = 0, fab = 0, fp1 = 0.0, faba = 0, fabp = 0, fems = 0, fp2 = 0;

  int ab[360];
  int p1[360];
  int aba[360];
  int abp[360];
  int ems[360];
  int p2[360];
  for (int i = 0; i < 360; i++) {
    ab[i] = 0;
    p1[i] = 0;
    aba[i] = 0;
    abp[i] = 0;
    ems[i] = 0;
    p2[i] = 0;
  }

  int t, pid, cid;
  int ts, pid2, cid2;
  double x, y, z, x2, y2, z2, sph, vol;
  string name, div, name2;

  ifstream plng;
  plng.open(plngfile.c_str(), ios::in);

  while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div) {
    if (!strcmp(name.c_str(), "AB") && !strcmp(div.c_str(), "N")) {
      ab[t] = 1;
    } else if (!strcmp(name.c_str(), "P1") && !strcmp(div.c_str(), "N")) {
      p1[t] = 1;
    } else if (!strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "N")) {
      aba[t] = 1;
    } else if (!strcmp(name.c_str(), "ABp") && !strcmp(div.c_str(), "N")) {
      abp[t] = 1;
    } else if (!strcmp(name.c_str(), "EMS") && !strcmp(div.c_str(), "N")) {
      ems[t] = 1;
    } else if (!strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "N")) {
      p2[t] = 1;
    }
  }
  plng.close();

  int tab = 0, tp1 = 0, taba = 0, tabp = 0, tems = 0, tp2 = 0, t2 = 0, t4 = 0;
  int cab = 0, cp1 = 0, caba = 0, cabp = 0, cems = 0, cp2 = 0, c2 = 0, c4 = 0;

  for (int i = 0; i < 180; i++) {
    if (ab[i] == 1) {
      tab = tab + i;
      cab++;
    }

    if (p1[i] == 1) {
      tp1 = tp1 + i;
      cp1++;
    }

    if (ab[i] == 1 && p1[i] == 1) {
      t2 = t2 + i;
      c2++;
    }

    if (aba[i] == 1) {
      taba = taba + i;
      caba++;
    }

    if (abp[i] == 1) {
      tabp = tabp + i;
      cabp++;
    }

    if (ems[i] == 1) {
      tems = tems + i;
      cems++;
    }

    if (p2[i] == 1) {
      tp2 = tp2 + i;
      cp2++;
    }

    if (aba[i] == 1&& abp[i] == 1 && ems[i] == 1 && p2[i] == 1) {
      t4 = t4 + i;
      c4++;
    }
  }

  int ttab = 0;
  if (cab != 0 && tab / cab != 0) {
    ttab = tab / cab;
  }
  int ttp1 = 0;
  if (cp1 != 0 && tp1 / cp1 != 0) {
    ttp1 = tp1 / cp1;
  }
  int tt2 = 0;
  if (c2 != 0 && t2 / c2 != 0) {
    tt2 = t2 / c2;
  }
  int ttaba = 0;
  if (caba != 0 && taba / caba != 0) {
    ttaba = taba / caba;
  }
  int ttabp = 0;
  if (cabp != 0 && tabp / cabp != 0) {
    ttabp = tabp / cabp;
  }
  int ttems = 0;
  if (cems != 0 && tems / cems != 0) {
    ttems = tems / cems;
  }
  int ttp2 = 0;
  if (cp2 != 0 && tp2 / cp2 != 0) {
    ttp2 = tp2 / cp2;
  }
  int tt4 = 0;
  if (c4 != 0 && t4 / c4 != 0) {
    tt4 = t4 / c4;
  }


  plng.open(plngfile.c_str(), ios::in);
  ifstream clng;
  clng.open(clngfile.c_str(), ios::in);
  while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div, clng >> ts >> pid2 >> cid2 >> x2 >> y2 >> z2 >> name2) {
    if (!strcmp(name.c_str(), "AB") && t == ttab) {
      abx = x2;
      aby = y2;
      abz = z2;
    }
    if (!strcmp(name.c_str(), "P1") && ttp1) {
      p1x = x2;
      p1y = y2;
      p1z = z2;
    }
    if (!strcmp(name.c_str(), "AB") && t == tt2) {
      twoabx = x2;
      twoaby = y2;
      twoabz = z2;
    }
    if (!strcmp(name.c_str(), "P1") && t == tt2) {
      twop1x = x2;
      twop1y = y2;
      twop1z = z2;
    }
    if (!strcmp(name.c_str(), "ABa") && t == ttaba) {
      abax = x2;
      abay = y2;
      abaz = z2;
    }
    if (!strcmp(name.c_str(), "ABp") && t == ttabp) {
      abpx = x2;
      abpy = y2;
      abpz = z2;
    }
    if (!strcmp(name.c_str(), "EMS") && t == ttems) {
      emsx = x2;
      emsy = y2;
      emsz = z2;
    }
    if (!strcmp(name.c_str(), "P2") && t == ttp2) {
      p2x = x2;
      p2y = y2;
      p2z = z2;
    }
    if (!strcmp(name.c_str(), "ABa") && t == tt4) {
      fourabax = x2;
      fourabay = y2;
      fourabaz = z2;
    }
    if (!strcmp(name.c_str(), "ABp") && t == tt4) {
      fourabpx = x2;
      fourabpy = y2;
      fourabpz = z2;
    }
    if (!strcmp(name.c_str(), "EMS") && t == tt4) {
      fouremsx = x2;
      fouremsy = y2;
      fouremsz = z2;
    }
    if (!strcmp(name.c_str(), "P2") && t == tt4) {
      fourp2x = x2;
      fourp2y = y2;
      fourp2z = z2;
    }
  }

  cout << gname << " ";

  if (abx != 0 && aby != 0 && abz != 0) {
    cout << abx << " " << aby << " " << abz << " " << sqrt(abx * abx + aby * aby + abz * abz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (p1x != 0 && p1y != 0 && p1z != 0) {
    cout << p1x << " " << p1y << " " << p1z << " " << sqrt(p1x * p1x + p1y * p1y + p1z * p1z) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (abax != 0 && abay != 0 && abaz != 0) {
    cout << abax << " " << abay << " " << abaz << " " << sqrt(abax * abax + abay * abay + abaz * abaz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (abpx != 0 && abpy != 0 && abpz != 0) {
    cout << abpx << " " << abpy << " " << abpz << " " << sqrt(abpx * abpx + abpy * abpy + abpz * abpz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (emsx != 0 && emsy != 0 && emsz != 0) {
    cout << emsx << " " << emsy << " " << emsz << " " << sqrt(emsx * emsx + emsy * emsy + emsz * emsz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (p2x != 0 && p2y != 0 && p2z != 0) {
    cout << p2x << " " << p2y << " " << p2z << " " << sqrt(p2x * p2x + p2y * p2y + p2z * p2z) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (twoabx != 0 && twoaby != 0 && twoabz != 0) {
    cout << twoabx << " " << twoaby << " " << twoabz << " " << sqrt(twoabx * twoabx + twoaby * twoaby + twoabz * twoabz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (twop1x != 0 && twop1y != 0 && twop1z != 0) {
    cout << twop1x << " " << twop1y << " " << twop1z << " " << sqrt(twop1x * twop1x + twop1y * twop1y + twop1z * twop1z) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (fourabax != 0 && fourabay != 0 && fourabaz != 0) {
    cout << fourabax << " " << fourabay << " " << fourabaz << " " << sqrt(fourabax * fourabax + fourabay * fourabay + fourabaz * fourabaz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (fourabpx != 0 && fourabpy != 0 && fourabpz != 0) {
    cout << fourabpx << " " << fourabpy << " " << fourabpz << " " << sqrt(fourabpx * fourabpx + fourabpy * fourabpy + fourabpz * fourabpz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (fouremsx != 0 && fouremsy != 0 && fouremsz != 0) {
    cout << fouremsx << " " << fouremsy << " " << fouremsz << " " << sqrt(fouremsx * fouremsx + fouremsy * fouremsy + fouremsz * fouremsz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (fourp2x != 0 && fourp2y != 0 && fourp2z != 0) {
    cout << fourp2x << " " << fourp2y << " " << fourp2z << " " << sqrt(fourp2x * fourp2x + fourp2y * fourp2y + fourp2z * fourp2z) << endl;
  } else {
    cout << "-1000 -1000 -1000 -1000" << endl;
  }


  return 0;
}
