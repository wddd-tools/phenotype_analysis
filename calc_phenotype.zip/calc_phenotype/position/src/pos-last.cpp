#include <iostream>
#include <cstring>
#include <fstream>
#include <cstdlib>
#include <cmath>
using namespace std;

int main(int argc, char* argv[])
{
  string gname = argv[1];
  string plngfile = argv[2];
  string clngfile = argv[3];


  double p0x = 0.0, p0y = 0.0, p0z = 0.0;
  double abx = 0.0, aby = 0.0, abz = 0.0;
  double p1x = 0.0, p1y = 0.0, p1z = 0.0;
  double abax = 0.0, abay = 0.0, abaz = 0.0;
  double abpx = 0.0, abpy = 0.0, abpz = 0.0;
  double emsx = 0.0, emsy = 0.0, emsz = 0.0;
  double p2x = 0.0, p2y = 0.0, p2z = 0.0;
  int fp0 = 0, fab = 0, fp1 = 0.0, faba = 0, fabp = 0, fems = 0, fp2 = 0;

  int t, pid, cid;
  int t2, pid2, cid2;
  double x, y, z, x2, y2, z2, sph, vol;
  string name, div, name2;

  ifstream plng;
  plng.open(plngfile.c_str(), ios::in);
  ifstream clng;
  clng.open(clngfile.c_str(), ios::in);
  while (plng >> t >> pid >> cid >> x >> y >> z >> name >> sph >> vol >> div, clng >> t2 >> pid2 >> cid2 >> x2 >> y2 >> z2 >> name2) {
    if (!strcmp(name.c_str(), "P0") && !strcmp(div.c_str(), "N")) {
      p0x = x2;
      p0y = y2;
      p0z = z2;
    } else if (!strcmp(name.c_str(), "AB") && !strcmp(div.c_str(), "N")) {
      abx = x2;
      aby = y2;
      abz = z2;
    } else if (!strcmp(name.c_str(), "P1") && !strcmp(div.c_str(), "N")) {
      p1x = x2;
      p1y = y2;
      p1z = z2;
    } else if (!strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "N")) {
      abax = x2;
      abay = y2;
      abaz = z2;
    } else if (!strcmp(name.c_str(), "ABp") && !strcmp(div.c_str(), "N")) {
      abpx = x2;
      abpy = y2;
      abpz = z2;
    } else if (!strcmp(name.c_str(), "EMS") && !strcmp(div.c_str(), "N")) {
      emsx = x2;
      emsy = y2;
      emsz = z2;
    } else if (!strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "N")) {
      p2x = x2;
      p2y = y2;
      p2z = z2;
    } else if (!strcmp(name.c_str(), "AB") && !strcmp(div.c_str(), "D") && abx != 0 && aby != 0 && abz != 0) {
      fab = 1;
    } else if (!strcmp(name.c_str(), "P1") && !strcmp(div.c_str(), "D") && p1x != 0 && p1y != 0 && p1z != 0) {
      fp1 = 1;
    } else if (!strcmp(name.c_str(), "ABa") && !strcmp(div.c_str(), "D") && abax != 0 && abay != 0 && abaz != 0) {
      faba = 1;
    } else if (!strcmp(name.c_str(), "ABp") && !strcmp(div.c_str(), "D") && abpx != 0 && abpy != 0 && abpz != 0) {
      fabp = 1;
    } else if (!strcmp(name.c_str(), "EMS") && !strcmp(div.c_str(), "D") && emsx != 0 && emsy != 0 && emsz != 0) {
      fems = 1;
    } else if (!strcmp(name.c_str(), "P2") && !strcmp(div.c_str(), "D") && p2x != 0 && p2y != 0 && p2z != 0) {
      fp2 = 1;
    }


    if (!strcmp(name.c_str(), "AB")) {
      fp0 = 1;
    } else if (!strcmp(name.c_str(), "P1")) {
      fp0 = 1;
    } else if (!strcmp(name.c_str(), "ABa")) {
      fab = 1;
    } else if (!strcmp(name.c_str(), "ABp")) {
      fab = 1;
    } else if (!strcmp(name.c_str(), "EMS")) {
      fp1 = 1;
    } else if (!strcmp(name.c_str(), "P2")) {
      fp1 = 1;
    } else if (!strcmp(name.c_str(), "ABal")) {
      faba = 1;
    } else if (!strcmp(name.c_str(), "ABar")) {
      faba = 1;
    } else if (!strcmp(name.c_str(), "ABpl")) {
      fabp = 1;
    } else if (!strcmp(name.c_str(), "ABpr")) {
      fabp = 1;
    } else if (!strcmp(name.c_str(), "E")) {
      fems = 1;
    } else if (!strcmp(name.c_str(), "MS")) {
      fems = 1;
    } else if (!strcmp(name.c_str(), "C")) {
      fp2 = 1;
    } else if (!strcmp(name.c_str(), "P3")) {
      fp2 = 1;
    }

  }

  cout << gname << " ";

  if (p0x != 0 && p0y != 0 && p0z != 0) {
    cout << p0x << " " << p0y << " " << p0z << " " << sqrt(p0x * p0x + p0y * p0y + p0z * p0z) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (abx != 0 && aby != 0 && abz != 0) {
    cout << abx << " " << aby << " " << abz << " " << sqrt(abx * abx + aby * aby + abz * abz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (p1x != 0 && p1y != 0 && p1z != 0) {
    cout << p1x << " " << p1y << " " << p1z << " " << sqrt(p1x * p1x + p1y * p1y + p1z * p1z) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (abax != 0 && abay != 0 && abaz != 0) {
    cout << abax << " " << abay << " " << abaz << " " << sqrt(abax * abax + abay * abay + abaz * abaz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (abpx != 0 && abpy != 0 && abpz != 0) {
    cout << abpx << " " << abpy << " " << abpz << " " << sqrt(abpx * abpx + abpy * abpy + abpz * abpz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (emsx != 0 && emsy != 0 && emsz != 0) {
    cout << emsx << " " << emsy << " " << emsz << " " << sqrt(emsx * emsx + emsy * emsy + emsz * emsz) << " ";
  } else {
    cout << "-1000 -1000 -1000 -1000 ";
  }

  if (p2x != 0 && p2y != 0 && p2z != 0) {
    cout << p2x << " " << p2y << " " << p2z << " " << sqrt(p2x * p2x + p2y * p2y + p2z * p2z) << endl;
  } else {
    cout << "-1000 -1000 -1000 -1000" << endl;
  }

  return 0;
}
