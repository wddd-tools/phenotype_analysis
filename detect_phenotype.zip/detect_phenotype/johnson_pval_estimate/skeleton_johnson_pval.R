library(jtrans)
x <- scan("wt_char.txt", skip=0, nlines=1)
y <- jtrans(x)
meanval <- mean(y$transformed)
sdval <- sd(y$transformed)
z <- scan("rnai_char.txt", skip=0, nlines=1)
w <- predict(y, z)
for (i in 1:length(w)) {
  cat(min(pnorm(w[i], meanval, sdval), 1 - pnorm(w[i], meanval, sdval)) * 2.0)
}
