x <- scan("wt_char.txt", skip=0, nlines=1)
y <- scan("rnai_gene_char.txt", skip=0, nlines=1)
n1 <- length(x)
n2 <- length(y)
xy <- c(x, y)
r <- rank(xy)
m <- r[1:n1]
n <- r[n1+1:n2]
if (length(y) > 1)
t.test(m, n)
